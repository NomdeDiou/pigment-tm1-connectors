"""Doubles de test en mémoire de Pigment et TM1 (comportement fidèle au contrat utilisé)."""
from __future__ import annotations

import copy
import io
from contextlib import contextmanager

import pandas as pd


class FakeTM1:
    def __init__(self, cubes: dict[str, list[str]], leaves: dict[str, list[str]], sandboxes=True):
        self.dims = cubes
        self.leaves = leaves
        self.data: dict[str, dict[tuple, float]] = {c: {} for c in cubes}
        self.sb: dict[str, dict[str, dict[tuple, float]]] = {}
        self.sandboxes_ok = sandboxes
        self.corrupt_next_write = False      # simule une écriture partielle/silencieuse
        self.fail_next_write = False
        self.published = []

    # contexte
    def __enter__(self): return self
    def __exit__(self, *a): return False

    def _store(self, cube, sandbox):
        return self.sb[sandbox][cube] if sandbox else self.data[cube]

    def cube_dimensions(self, cube): return list(self.dims[cube])
    def leaf_elements(self, d): return list(self.leaves[d])
    def sandboxes_enabled(self): return self.sandboxes_ok

    def _in_scope(self, cube, key, members):
        return all(key[i] in members[d] for i, d in enumerate(self.dims[cube]) if d in members)

    def read(self, cube, members, sandbox=None, mdx=None):
        rows = [(*k, v) for k, v in self._store(cube, sandbox).items()
                if v != 0 and self._in_scope(cube, k, members)]
        return pd.DataFrame(rows, columns=self.dims[cube] + ["Value"])

    def clear(self, cube, members, sandbox=None):
        st = self._store(cube, sandbox)
        for k in [k for k in st if self._in_scope(cube, k, members)]:
            del st[k]

    def write(self, cube, df, dimensions, sandbox=None):
        if self.fail_next_write:
            self.fail_next_write = False
            raise RuntimeError("TM1 write failed")
        st = self._store(cube, sandbox)
        rows = list(df[dimensions + ["Value"]].itertuples(index=False))
        if self.corrupt_next_write:
            self.corrupt_next_write = False
            rows = rows[:-1]                     # une cellule perdue
        for r in rows:
            st[tuple(r[:-1])] = float(r[-1])

    @contextmanager
    def sandbox(self, name):
        self.sb[name] = copy.deepcopy(self.data)
        try:
            yield name
        finally:
            self.sb.pop(name, None)

    def publish(self, name):
        self.data = copy.deepcopy(self.sb[name])
        self.published.append(name)


class FakePigment:
    """Vues = DataFrames (format Pigment). Une config d'import alimente une vue (sémantique replace)."""

    def __init__(self, delimiter=";"):
        self.views: dict[str, pd.DataFrame] = {}
        self.import_targets: dict[str, str] = {}
        self.delimiter = delimiter
        self.pushed: list[str] = []
        self.drop_rows_on_import = 0

    def export_view_df(self, view_id):
        text = self.views[view_id].to_csv(index=False, sep=self.delimiter)
        return pd.read_csv(io.StringIO(text), sep=self.delimiter, dtype=str, keep_default_na=False), text

    def push_csv(self, configuration_id, csv_text):
        self.pushed.append(csv_text)
        df = pd.read_csv(io.StringIO(csv_text), dtype=str, keep_default_na=False)
        if self.drop_rows_on_import:
            df = df.iloc[: -self.drop_rows_on_import]
            self.drop_rows_on_import = 0
        self.views[self.import_targets[configuration_id]] = df
        return f"imp-{len(self.pushed)}"

    def wait_import(self, import_id):
        return {"status": "Completed", "importId": import_id}
