"""Tests de bout en bout du moteur avec doubles en mémoire.

    python -m unittest discover -s tests -v      (ou : pytest)
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from connector.audit import AuditLog  # noqa: E402
from connector.config import AppConf, load_config  # noqa: E402
from connector.engine import Engine, RunOptions  # noqa: E402
from connector.errors import (ConfigError, GovernanceError, LoadError, LockError,  # noqa: E402
                              ReconciliationError, ValidationError)
from connector.lock import FlowLock  # noqa: E402
from tests.fakes import FakePigment, FakeTM1  # noqa: E402

ENTITIES = ["FR01", "DE01", "US01"]
ACCOUNTS = ["6000", "6100", "7000"]
PERIODS = [f"2027-{m:02d}" for m in range(1, 4)]
VERSIONS = ["Actual", "Budget 2027"]


def base_conf(tmp: str, env="dev", **flow_overrides) -> dict:
    p2t = {
        "name": "budget", "owner": "cdg", "direction": "pigment_to_tm1",
        "source": {"view_id": "V_BUDGET"},
        "target": {"cube": "Budget", "slice": {"Version": ["Budget 2027"], "Period": PERIODS}},
        "mapping": {"columns": {"Entity": "Entity", "Account": "Account", "Month": "Period", "Version": "Version"},
                    "value_column": "Amount", "static_members": {"Measure": "Amount"},
                    "member_maps": {"Period": {"Jan 27": "2027-01", "Feb 27": "2027-02", "Mar 27": "2027-03"}}},
        "governance": {"protected_members": {"Version": ["Actual"]}, "min_rows": 1,
                       "max_total_change_pct": 25, "require_approval": True},
        "reconciliation": {"control_dimensions": ["Entity"]},
    }
    t2p = {
        "name": "actuals", "owner": "compta", "direction": "tm1_to_pigment",
        "source": {"cube": "Budget", "slice": {"Version": ["Actual"], "Period": PERIODS}},
        "target": {"import_configuration_id": "CFG1", "verification_view_id": "V_ACT"},
        "mapping": p2t["mapping"],
        "governance": {"min_rows": 1, "max_total_change_pct": None, "require_approval": True},
    }
    for k, v in flow_overrides.items():
        p2t[k] = v
    return {"runtime": {"environment": env, "work_dir": f"{tmp}/runs", "audit_log": f"{tmp}/audit.jsonl",
                        "lock_dir": f"{tmp}/locks", "audit_hmac_key_env": "TEST_HMAC"},
            "flows": [p2t, t2p]}


def pigment_budget(scale=1.0, extra_rows=None) -> pd.DataFrame:
    months = {"2027-01": "Jan 27", "2027-02": "Feb 27", "2027-03": "Mar 27"}
    rows = [{"Entity": e, "Account": a, "Month": months[p], "Version": "Budget 2027",
             "Amount": f"{(i + 1) * 1000.5 * scale:.2f}"}
            for i, (e, a, p) in enumerate((e, a, p) for e in ENTITIES for a in ACCOUNTS for p in PERIODS)]
    return pd.DataFrame(rows + (extra_rows or []))


def make_tm1(sandboxes=True) -> FakeTM1:
    t = FakeTM1({"Budget": ["Entity", "Account", "Period", "Version", "Measure"]},
                {"Entity": ENTITIES, "Account": ACCOUNTS, "Period": PERIODS, "Version": VERSIONS,
                 "Measure": ["Amount"]}, sandboxes=sandboxes)
    # existant : budget (à remplacer) + réel (ne doit jamais bouger)
    for i, (e, a, p) in enumerate((e, a, p) for e in ENTITIES for a in ACCOUNTS for p in PERIODS):
        t.data["Budget"][(e, a, p, "Budget 2027", "Amount")] = (i + 1) * 1000.5
        t.data["Budget"][(e, a, p, "Actual", "Amount")] = (i + 1) * 10.0
    t.data["Budget"][("FR01", "6000", "2027-01", "Budget 2027", "Amount")] = 1.0   # sera écrasé
    return t


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        os.environ["TEST_HMAC"] = "cle-hmac-de-test-0123456789"
        self.tm1 = make_tm1()
        self.pg = FakePigment()
        self.pg.views["V_BUDGET"] = pigment_budget()
        self.pg.import_targets["CFG1"] = "V_ACT"
        self.pg.views["V_ACT"] = pd.DataFrame(columns=["Entity", "Account", "Month", "Version", "Amount"])

    def engine(self, conf: dict | None = None):
        c = AppConf.model_validate(conf or base_conf(self.tmp))
        return Engine(c, "testhash", pigment=self.pg, tm1_factory=lambda: self.tm1)

    def actuals(self):
        return {k: v for k, v in self.tm1.data["Budget"].items() if k[3] == "Actual"}


class TestPigmentToTM1(Base):
    def test_dry_run_writes_nothing(self):
        before = dict(self.tm1.data["Budget"])
        r = self.engine().run("budget", RunOptions(dry_run=True))
        self.assertEqual(r["status"], "dry_run_ok")
        self.assertEqual(r["preview"]["cells_changed"], 1)
        self.assertEqual(self.tm1.data["Budget"], before)

    def test_success_sandbox_reconciled(self):
        actual_before = self.actuals()
        r = self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertEqual(r["status"], "success")
        self.assertEqual(r["write_mode"], "sandbox")
        self.assertTrue(r["reconciliation"]["ok"])
        self.assertEqual(r["reconciliation"]["expected_fingerprint"], r["reconciliation"]["actual_fingerprint"])
        self.assertEqual(self.tm1.data["Budget"][("FR01", "6000", "2027-01", "Budget 2027", "Amount")], 1000.5)
        self.assertEqual(self.actuals(), actual_before, "le réel ne doit jamais être touché")

    def test_replace_slice_clears_obsolete_cells(self):
        self.tm1.data["Budget"][("US01", "7000", "2027-03", "Budget 2027", "Amount")] = 5.0
        self.pg.views["V_BUDGET"] = pigment_budget().iloc[:-1]       # cellule supprimée côté Pigment
        r = self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertTrue(r["reconciliation"]["ok"])
        self.assertNotIn(("US01", "7000", "2027-03", "Budget 2027", "Amount"), self.tm1.data["Budget"])

    def test_case_and_space_insensitive_elements(self):
        df = pigment_budget()
        df.loc[0, "Entity"] = "fr 01"
        self.pg.views["V_BUDGET"] = df
        self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertIn(("FR01", "6000", "2027-01", "Budget 2027", "Amount"), self.tm1.data["Budget"])

    def test_unknown_element_blocks_everything(self):
        self.pg.views["V_BUDGET"] = pigment_budget(extra_rows=[
            {"Entity": "XX99", "Account": "6000", "Month": "Jan 27", "Version": "Budget 2027", "Amount": "1"}])
        before = dict(self.tm1.data["Budget"])
        with self.assertRaises(ValidationError) as cm:
            self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertTrue(any("XX99" in i for i in cm.exception.issues))
        self.assertEqual(self.tm1.data["Budget"], before)

    def test_protected_member_blocks(self):
        self.pg.views["V_BUDGET"] = pigment_budget(extra_rows=[
            {"Entity": "FR01", "Account": "6000", "Month": "Jan 27", "Version": "Actual", "Amount": "1"}])
        with self.assertRaises(ValidationError) as cm:
            self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertTrue(any("protégés" in i for i in cm.exception.issues))

    def test_non_numeric_and_duplicates_block(self):
        df = pigment_budget()
        df.loc[1, "Amount"] = "abc"
        self.pg.views["V_BUDGET"] = df
        with self.assertRaises(ValidationError):
            self.engine().run("budget", RunOptions(approved_by="boss"))
        self.pg.views["V_BUDGET"] = pd.concat([pigment_budget(), pigment_budget().iloc[:1]])
        with self.assertRaises(ValidationError) as cm:
            self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertTrue(any("doublon" in i for i in cm.exception.issues))

    def test_empty_source_cannot_wipe_target(self):
        self.pg.views["V_BUDGET"] = pigment_budget().iloc[0:0]
        with self.assertRaises(ValidationError):
            self.engine().run("budget", RunOptions(approved_by="boss"))

    def test_change_threshold_blocks(self):
        self.pg.views["V_BUDGET"] = pigment_budget(scale=2.0)
        with self.assertRaises(GovernanceError):
            self.engine().run("budget", RunOptions(approved_by="boss"))

    def test_approval_required(self):
        with self.assertRaises(GovernanceError):
            self.engine().run("budget", RunOptions())

    def test_prod_requires_ticket_and_four_eyes(self):
        eng = self.engine(base_conf(self.tmp, env="prod"))
        with self.assertRaises(GovernanceError):
            eng.run("budget", RunOptions(approved_by="boss", operator="alice"))
        with self.assertRaises(GovernanceError):
            eng.run("budget", RunOptions(approved_by="alice", operator="alice", ticket="CHG-1"))
        r = eng.run("budget", RunOptions(approved_by="boss", operator="alice", ticket="CHG-1"))
        self.assertEqual(r["status"], "success")

    def test_sandbox_corruption_never_published(self):
        before = dict(self.tm1.data["Budget"])
        self.tm1.corrupt_next_write = True
        with self.assertRaises(ReconciliationError):
            self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertEqual(self.tm1.data["Budget"], before)
        self.assertEqual(self.tm1.published, [])

    def test_snapshot_mode_restores_on_corruption(self):
        self.tm1.sandboxes_ok = False
        before = dict(self.tm1.data["Budget"])
        self.tm1.corrupt_next_write = True
        with self.assertRaises(ReconciliationError) as cm:
            self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertIn("restauré", str(cm.exception))
        self.assertEqual(self.tm1.data["Budget"], before)

    def test_snapshot_mode_restores_on_write_failure(self):
        self.tm1.sandboxes_ok = False
        before = dict(self.tm1.data["Budget"])
        self.tm1.fail_next_write = True
        with self.assertRaises(LoadError):
            self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertEqual(self.tm1.data["Budget"], before)

    def test_mapping_must_cover_cube(self):
        self.tm1.dims["Budget"].append("Currency")
        with self.assertRaises(ConfigError):
            self.engine().run("budget", RunOptions(dry_run=True))

    def test_evidence_written(self):
        r = self.engine().run("budget", RunOptions(approved_by="boss"))
        d = Path(self.tmp) / "runs" / "budget" / r["run_id"]
        for f in ("source_pigment.csv", "source_canonical.csv", "target_before.csv", "report.json"):
            self.assertTrue((d / f).exists(), f)
        self.assertEqual(json.loads((d / "report.json").read_text())["status"], "success")


class TestTM1ToPigment(Base):
    def test_success_and_mapping_inverse(self):
        r = self.engine().run("actuals", RunOptions(approved_by="boss"))
        self.assertEqual(r["status"], "success")
        self.assertTrue(r["reconciliation"]["ok"])
        v = self.pg.views["V_ACT"]
        self.assertEqual(len(v), 27)
        self.assertEqual(set(v["Month"]), {"Jan 27", "Feb 27", "Mar 27"})
        self.assertEqual(set(v["Version"]), {"Actual"})

    def test_partial_import_detected_and_compensated(self):
        self.engine().run("actuals", RunOptions(approved_by="boss"))
        good = self.pg.views["V_ACT"].copy()
        self.tm1.data["Budget"][("FR01", "6000", "2027-01", "Actual", "Amount")] = 99.0
        self.pg.drop_rows_on_import = 2
        with self.assertRaises(ReconciliationError):
            self.engine().run("actuals", RunOptions(approved_by="boss"))
        pd.testing.assert_frame_equal(self.pg.views["V_ACT"].reset_index(drop=True),
                                      good.reset_index(drop=True), check_dtype=False)

    def test_dry_run_does_not_import(self):
        self.engine().run("actuals", RunOptions(dry_run=True))
        self.assertEqual(self.pg.pushed, [])


class TestAuditAndLock(Base):
    def test_audit_chain_and_tamper_detection(self):
        self.engine().run("budget", RunOptions(approved_by="boss"))
        with self.assertRaises(GovernanceError):
            self.engine().run("budget", RunOptions())
        log = AuditLog(Path(self.tmp) / "audit.jsonl", os.environ["TEST_HMAC"])
        ok, n, _ = log.verify()
        self.assertTrue(ok)
        self.assertGreaterEqual(n, 5)
        events = [json.loads(l)["event"] for l in log.path.read_text().splitlines()]
        self.assertIn("load_authorized", events)
        self.assertIn("run_failed", events)
        # falsification d'un montant dans l'historique
        lines = log.path.read_text().splitlines()
        lines[1] = lines[1].replace('"boss"', '"mallory"')
        log.path.write_text("\n".join(lines) + "\n")
        self.assertFalse(log.verify()[0])
        # suppression d'une ligne
        log.path.write_text("\n".join(lines[:1] + lines[2:]) + "\n")
        self.assertFalse(log.verify()[0])
        # mauvaise clé
        self.assertFalse(AuditLog(log.path, "autre-cle").verify()[0])

    def test_no_secret_in_audit(self):
        self.engine().run("budget", RunOptions(approved_by="boss"))
        self.assertNotIn(os.environ["TEST_HMAC"], (Path(self.tmp) / "audit.jsonl").read_text())

    def test_concurrent_run_blocked(self):
        with FlowLock(f"{self.tmp}/locks", "budget", "other-run"):
            with self.assertRaises(LockError):
                self.engine().run("budget", RunOptions(dry_run=True))


class TestConfigSecurity(unittest.TestCase):
    def _write(self, text):
        p = Path(tempfile.mkdtemp()) / "c.yaml"
        p.write_text(text)
        return p

    def test_example_config_is_valid(self):
        conf, h = load_config(Path(__file__).resolve().parents[1] / "config" / "flows.example.yaml")
        self.assertEqual(len(conf.flows), 2)
        self.assertEqual(len(h), 64)

    def test_inline_secret_rejected(self):
        p = self._write("tm1:\n  connection: {address: x, password: hunter2}\nflows: []\n")
        with self.assertRaises(ConfigError):
            load_config(p)

    def test_tls_disable_rejected(self):
        p = self._write("tm1:\n  verify_tls: false\nflows: []\n")
        with self.assertRaises(ConfigError):
            load_config(p)

    def test_http_pigment_rejected(self):
        p = self._write("pigment:\n  base_url: http://pigment.app/api\nflows: []\n")
        with self.assertRaises(ConfigError):
            load_config(p)


if __name__ == "__main__":
    unittest.main()
