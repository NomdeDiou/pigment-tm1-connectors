# Connecteur Pigment ⇄ IBM Planning Analytics (TM1)

Échanges de données bidirectionnels, déclaratifs et contrôlés entre Pigment et TM1 / Planning Analytics (on‑premise ou SaaS).

| Exigence | Comment elle est tenue |
|---|---|
| **Vérifiable** | Après chaque chargement, la cible est **relue** et réconciliée cellule à cellule avec la source (tolérance paramétrable). Empreintes SHA‑256 de la source, du payload et de l'état antérieur ; totaux de contrôle par axe ; dossier de preuves par exécution. |
| **Infaillible** | Validation **bloquante** avant toute écriture. Écriture atomique : **sandbox TM1** publiée seulement si la réconciliation est parfaite, sinon **snapshot + restauration automatique vérifiée**. Côté Pigment, ré‑import compensatoire de l'état antérieur. Verrou anti‑concurrence. Les imports ne sont jamais relancés à l'aveugle (pas de double chargement). |
| **Sécurisé** | Aucun secret dans la config (rejet à la validation). Secrets via variables d'environnement ou fichiers montés (Vault, Key Vault, secrets K8s). TLS obligatoire (désactivation refusée). Masquage des secrets dans les logs. Preuves en droits restreints. |
| **Gouvernable** | Flux déclarés en YAML versionné avec propriétaire. Membres protégés, listes blanches, seuils (lignes min/max, variation du total). Approbation nominative, ticket et **principe des quatre yeux** en production. **Journal d'audit chaîné et signé HMAC** : toute altération est détectée. Mode `--dry-run` avec prévisualisation des cellules créées / modifiées / effacées. |

## Déroulé d'un flux

```mermaid
flowchart LR
  A[Extraction source] --> B[Normalisation<br/>mapping + member_maps]
  B --> C{Validation<br/>éléments, doublons,<br/>membres protégés}
  C -- anomalie --> X[Arrêt : rien écrit]
  C --> D[Capture état cible<br/>+ prévisualisation]
  D --> E{Gouvernance<br/>seuils, approbation,<br/>ticket, 4 yeux}
  E -- refus --> X
  E --> F[Écriture atomique<br/>sandbox / snapshot]
  F --> G{Relecture +<br/>réconciliation}
  G -- écart --> R[Restauration vérifiée<br/>code 7]
  G -- OK --> S[Succès + audit]
```

Le même `mapping` (colonne Pigment → dimension TM1) sert dans les deux sens ; les `member_maps` doivent être bijectives pour être inversées.

## Installation

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp config/flows.example.yaml config/flows.yaml   # puis adapter
```

Secrets (exemples) :

```bash
export PIGMENT_API_KEY=...                 # compte de service Pigment, droits minimaux
export TM1_USER=... TM1_PASSWORD=...       # ou TM1_PASSWORD_FILE=/run/secrets/tm1
export CONNECTOR_AUDIT_HMAC_KEY=...        # obligatoire en prod ; à conserver hors du serveur
```

## Utilisation

```bash
python -m connector -c config/flows.yaml list
python -m connector -c config/flows.yaml validate-config
python -m connector -c config/flows.yaml run budget_pigment_to_tm1 --dry-run
python -m connector -c config/flows.yaml run budget_pigment_to_tm1 \
       --operator a.dupont --approved-by j.martin --ticket CHG-1234
python -m connector -c config/flows.yaml verify-audit
```

| Code | Signification |
|---|---|
| 0 | succès |
| 2 / 3 | configuration / secret |
| 4 | validation : anomalies dans les données, **rien écrit** |
| 5 | gouvernance : approbation, ticket ou seuil, **rien écrit** |
| 6 | échec de chargement, état antérieur restauré |
| 7 | écart de réconciliation, état antérieur **restauré et vérifié** |
| 8 | flux déjà en cours |
| 9 | **CRITIQUE** : restauration impossible, intervention manuelle (l'état antérieur est dans le dossier de preuves) |
| 10 | journal d'audit altéré |

Planifiez via votre ordonnanceur (Control‑M, Airflow, cron, chore TM1 appelant un script) en vous appuyant sur les codes de sortie.

## Preuves par exécution

`runs/<flux>/<run_id>/` contient : `source_*.csv` (brut), `source_canonical.csv`, `target_before.csv` (état antérieur, base de restauration), `preview_changes.csv`, `diffs*.csv` en cas d'écart, `pigment_import_status.json`, `report.json`. Ces fichiers contiennent des données financières : appliquez votre politique de rétention et de chiffrement au repos.

## Préparer Pigment et TM1

**Pigment**
- Créez une **vue dédiée** par flux, à plat (une ligne par cellule), avec les colonnes du `mapping` et la colonne valeur. Les droits de la clé API sont ceux de son propriétaire : utilisez un compte de service.
- Pour TM1 → Pigment, créez une **configuration d'import** (CSV, séparateur `,`) et une **vue de vérification** au même grain que les données importées. Sans elle, pas de relecture.

**TM1 / Planning Analytics**
- Chaque dimension du cube doit être soit mappée, soit fixée par `static_members` (contrôlé au démarrage).
- Seules les **feuilles** sont acceptées ; la correspondance des noms suit les règles TM1 (insensible à la casse et aux espaces).
- Utilisateur technique avec droits d'écriture limités aux cubes et versions concernés ; journal de transactions activé.
- Sandboxes activées sur le serveur pour le mode atomique (repli automatique en snapshot sinon).

## Points à valider dans votre environnement

Je n'ai pas pu tester contre vos instances. Avant la mise en production :

1. **API Pigment** : vérifiez sur `https://pigment.app/api/swagger` les URL, le nom du champ identifiant d'import (`importId`/`id`) et les libellés de statut (`import_success_states` / `import_failure_states` sont paramétrables).
2. **TM1py** : signatures `write_dataframe(..., sandbox_name, use_blob)`, `clear_with_mdx`, `sandboxes.*` selon votre version de TM1py et de Planning Analytics (v11 vs v12) ; mode d'authentification SaaS (`user`/`password`, clé API, namespace).
3. **Format des nombres** exportés par vos vues Pigment (séparateur décimal, milliers).
4. **Saisies concurrentes** : si des utilisateurs saisissent dans le périmètre pendant le chargement, la réconciliation échouera (c'est voulu) ; planifiez hors saisie ou verrouillez la version.
5. Exécutez d'abord tous les flux en `--dry-run` en environnement de test.

## Tests

```bash
python -m unittest discover -s tests -t . -v      # ou : pytest
```

26 tests couvrent les deux sens : succès réconciliés, effacement des cellules obsolètes, éléments inconnus, membres protégés, doublons, source vide, seuil de variation, approbation, ticket et quatre yeux, corruption silencieuse en sandbox (jamais publiée), restauration en mode snapshot, import Pigment partiel détecté puis compensé, falsification et suppression de lignes du journal d'audit, verrou concurrent, rejet des secrets en clair et du TLS désactivé.

## Limites connues

- Cellules **numériques** uniquement (pas de cellules texte TM1 / propriétés Pigment).
- Pas de synchronisation de métadonnées (création d'éléments, de listes) : les dimensions doivent exister des deux côtés ; tout élément inconnu bloque le flux.
- La compensation côté Pigment suppose une configuration d'import en mode remplacement sur le périmètre.
