"""Exceptions typées : chaque échec a une cause identifiable et un code de sortie stable."""


class ConnectorError(Exception):
    exit_code = 1


class ConfigError(ConnectorError):
    exit_code = 2


class SecretError(ConnectorError):
    exit_code = 3


class ValidationError(ConnectorError):
    """Les données sources ne respectent pas le contrat : rien n'a été écrit."""
    exit_code = 4

    def __init__(self, message: str, issues: list[str] | None = None):
        super().__init__(message)
        self.issues = issues or []


class GovernanceError(ConnectorError):
    """Règle de gouvernance bloquante (approbation, seuil, membre protégé) : rien n'a été écrit."""
    exit_code = 5


class LoadError(ConnectorError):
    exit_code = 6


class ReconciliationError(ConnectorError):
    """Les données relues dans la cible ne correspondent pas à la source."""
    exit_code = 7


class LockError(ConnectorError):
    exit_code = 8


class RollbackError(ConnectorError):
    """Le plus grave : l'écriture a échoué ET la restauration aussi. Intervention manuelle requise."""
    exit_code = 9
