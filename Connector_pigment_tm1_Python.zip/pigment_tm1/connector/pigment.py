"""Client Pigment (API publique REST).

Endpoints (à confirmer sur https://pigment.app/api/swagger pour votre tenant) :
  * export : GET  {base}/export/view/{viewId}                       -> CSV
  * import : POST {base}/import/push/csv?configurationId={id}       -> {importId}
  * statut : GET  {base}/import/{importId}/status?includedDetailedReport=true

Fiabilité : les lectures (GET) sont relancées sur 429/5xx avec backoff.
Les POST d'import NE SONT JAMAIS relancés automatiquement : une relance aveugle
pourrait importer deux fois. En cas d'incertitude, le moteur échoue proprement
et la réconciliation dira ce qui a réellement été chargé.
"""
from __future__ import annotations

import io
import logging
import time

import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import PigmentConf
from .errors import LoadError
from .secrets import get_secret

log = logging.getLogger(__name__)


class PigmentClient:
    def __init__(self, conf: PigmentConf, session: requests.Session | None = None):
        self.conf = conf
        self.s = session or requests.Session()
        retry = Retry(total=5, backoff_factor=2, status_forcelist=(429, 500, 502, 503, 504),
                      allowed_methods=frozenset({"GET"}), respect_retry_after_header=True)
        self.s.mount("https://", HTTPAdapter(max_retries=retry))
        self.s.verify = True
        self._key_env = conf.api_key_env

    def _headers(self, **extra) -> dict:
        return {"Authorization": f"Bearer {get_secret(self._key_env)}", **extra}

    # ---------- lecture ----------
    def export_view_csv(self, view_id: str) -> str:
        url = f"{self.conf.base_url}/export/view/{view_id}"
        r = self.s.get(url, headers=self._headers(Accept="text/csv"), timeout=self.conf.timeout_s)
        if r.status_code != 200:
            raise LoadError(f"Export Pigment {view_id} : HTTP {r.status_code} {r.text[:300]}")
        r.encoding = r.encoding or "utf-8"
        return r.text

    def export_view_df(self, view_id: str) -> tuple[pd.DataFrame, str]:
        text = self.export_view_csv(view_id)
        df = pd.read_csv(io.StringIO(text), sep=self.conf.csv_delimiter, dtype=str,
                         keep_default_na=False, na_values=[])
        return df, text

    # ---------- écriture ----------
    def push_csv(self, configuration_id: str, csv_text: str) -> str:
        url = f"{self.conf.base_url}/import/push/csv"
        r = self.s.post(url, params={"configurationId": configuration_id},
                        headers=self._headers(**{"Content-Type": "text/csv"}),
                        data=csv_text.encode("utf-8"), timeout=self.conf.timeout_s)
        if r.status_code not in (200, 201, 202):
            raise LoadError(f"Import Pigment refusé : HTTP {r.status_code} {r.text[:300]}")
        try:
            body = r.json()
        except ValueError:
            body = {"raw": r.text}
        import_id = body.get("importId") or body.get("id") or body.get("ImportId")
        if not import_id:
            raise LoadError(f"Réponse d'import sans identifiant : {str(body)[:300]}")
        return str(import_id)

    def import_status(self, import_id: str) -> dict:
        url = f"{self.conf.base_url}/import/{import_id}/status"
        r = self.s.get(url, params={"includedDetailedReport": "true"},
                       headers=self._headers(), timeout=self.conf.timeout_s)
        if r.status_code != 200:
            raise LoadError(f"Statut d'import {import_id} : HTTP {r.status_code}")
        return r.json()

    def wait_import(self, import_id: str) -> dict:
        ok = {s.lower() for s in self.conf.import_success_states}
        ko = {s.lower() for s in self.conf.import_failure_states}
        deadline = time.monotonic() + self.conf.import_timeout_s
        while True:
            st = self.import_status(import_id)
            state = str(st.get("status") or st.get("state") or "").lower()
            if state in ok:
                return st
            if state in ko:
                raise LoadError(f"Import Pigment {import_id} en échec : {str(st)[:1000]}")
            if time.monotonic() > deadline:
                raise LoadError(f"Import Pigment {import_id} : délai dépassé (dernier statut {state!r})")
            time.sleep(self.conf.import_poll_interval_s)
