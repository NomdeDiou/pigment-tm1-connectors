"""Adaptateur TM1 / Planning Analytics au-dessus de TM1py.

Écriture atomique :
  * mode sandbox (par défaut) : effacement + écriture + relecture dans une sandbox
    privée ; publication uniquement si la réconciliation est parfaite, sinon la
    sandbox est supprimée et la base n'a jamais été touchée ;
  * mode snapshot (sandboxes désactivées) : sauvegarde du périmètre, écriture,
    relecture ; restauration automatique de la sauvegarde en cas d'écart.
Le journal de transactions TM1 n'est jamais désactivé (traçabilité native).
"""
from __future__ import annotations

import logging
from contextlib import contextmanager

import pandas as pd

from .config import TM1Conf
from .secrets import get_secret

log = logging.getLogger(__name__)


def _q(name: str) -> str:
    return "[" + name.replace("]", "]]") + "]"


class TM1Adapter:
    """Interface minimale utilisée par le moteur (remplaçable par un double de test)."""

    def __init__(self, conf: TM1Conf):
        self.conf = conf
        self._tm1 = None

    # ---------- connexion ----------
    def __enter__(self):
        from TM1py import TM1Service  # import tardif : les tests n'en dépendent pas
        kwargs = dict(self.conf.connection)
        for param, env in self.conf.secret_env.items():
            kwargs[param] = get_secret(env)
        kwargs.setdefault("ssl", True)
        kwargs["verify"] = self.conf.verify_tls
        self._tm1 = TM1Service(**kwargs)
        return self

    def __exit__(self, *exc):
        if self._tm1 is not None:
            try:
                self._tm1.logout()
            except Exception:  # noqa: BLE001
                log.warning("Déconnexion TM1 incomplète")
        return False

    # ---------- métadonnées ----------
    def cube_dimensions(self, cube: str) -> list[str]:
        return self._tm1.cubes.get_dimension_names(cube)

    def leaf_elements(self, dimension: str) -> list[str]:
        return list(self._tm1.elements.get_leaf_element_names(dimension, dimension))

    def sandboxes_enabled(self) -> bool:
        try:
            self._tm1.sandboxes.get_all_names()
            return True
        except Exception:  # noqa: BLE001
            return False

    # ---------- MDX ----------
    def slice_mdx(self, cube: str, members: dict[str, list[str]]) -> str:
        """MDX couvrant exactement le périmètre : éléments listés, sinon toutes les feuilles."""
        dims = self.cube_dimensions(cube)
        sets = []
        for d in dims:
            if d in members:
                sets.append("{" + ",".join(f"{_q(d)}.{_q(d)}.{_q(e)}" for e in members[d]) + "}")
            else:
                sets.append(f"{{TM1FILTERBYLEVEL({{TM1SUBSETALL({_q(d)}.{_q(d)})}},0)}}")
        cols, rows = sets[-1], sets[:-1]
        rows_expr = " * ".join(rows) if rows else "{}"
        return f"SELECT NON EMPTY {cols} ON 0, NON EMPTY {rows_expr} ON 1 FROM {_q(cube)}"

    # ---------- données ----------
    def read(self, cube: str, members: dict[str, list[str]], sandbox: str | None = None,
             mdx: str | None = None) -> pd.DataFrame:
        query = mdx or self.slice_mdx(cube, members)
        return self._tm1.cells.execute_mdx_dataframe(query, skip_zeros=True, sandbox_name=sandbox)

    def clear(self, cube: str, members: dict[str, list[str]], sandbox: str | None = None) -> None:
        mdx = self.slice_mdx(cube, members).replace("NON EMPTY ", "")
        self._tm1.cells.clear_with_mdx(cube=cube, mdx=mdx, sandbox_name=sandbox)

    def write(self, cube: str, df: pd.DataFrame, dimensions: list[str], sandbox: str | None = None) -> None:
        ordered = df[dimensions + ["Value"]]
        self._tm1.cells.write_dataframe(cube, ordered, dimensions=dimensions, increment=False,
                                        sandbox_name=sandbox, use_blob=True)

    @contextmanager
    def sandbox(self, name: str):
        from TM1py.Objects import Sandbox
        self._tm1.sandboxes.create(Sandbox(name=name, include_in_sandbox_dimension=False))
        try:
            yield name
        finally:
            try:
                if self._tm1.sandboxes.exists(name):
                    self._tm1.sandboxes.delete(name)
            except Exception:  # noqa: BLE001
                log.error("Sandbox %s non supprimée : nettoyage manuel requis", name)

    def publish(self, sandbox: str) -> None:
        self._tm1.sandboxes.publish(sandbox)
