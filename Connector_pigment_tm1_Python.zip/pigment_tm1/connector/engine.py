"""Orchestration d'un flux : extraire -> valider -> contrôler -> charger -> relire -> réconcilier.

Garanties :
  * aucune écriture tant que validation et gouvernance ne sont pas passées ;
  * l'état cible antérieur est toujours capturé avant écriture (preuve + restauration) ;
  * un flux ne se termine en succès QUE si la relecture de la cible réconcilie à 100 %
    (à la tolérance près) ; sinon restauration automatique et code d'erreur ;
  * chaque étape est journalisée dans l'audit chaîné, avec les empreintes des données.
"""
from __future__ import annotations

import getpass
import hashlib
import json
import logging
import os
import uuid
from contextlib import nullcontext
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import pandas as pd

from . import dataset as ds
from .audit import AuditLog
from .config import AppConf, FlowConf
from .errors import (ConfigError, ConnectorError, GovernanceError, LoadError, ReconciliationError,
                     RollbackError, ValidationError)
from .lock import FlowLock
from .pigment import PigmentClient
from .secrets import get_secret, redact
from .tm1 import TM1Adapter

log = logging.getLogger(__name__)
VALUE = ds.VALUE


@dataclass
class RunOptions:
    dry_run: bool = False
    approved_by: str | None = None
    ticket: str | None = None
    operator: str | None = None


class Evidence:
    """Dossier de preuves d'une exécution (données sensibles : accès restreint)."""

    def __init__(self, root: Path):
        self.root = root
        root.mkdir(parents=True, exist_ok=True)
        os.chmod(root, 0o750)

    def text(self, name: str, content: str) -> str:
        p = self.root / name
        p.write_text(content, encoding="utf-8")
        os.chmod(p, 0o640)
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def frame(self, name: str, df: pd.DataFrame) -> str:
        return self.text(name, ds.to_csv(df))

    def json(self, name: str, obj) -> None:
        self.text(name, json.dumps(obj, indent=2, ensure_ascii=False, default=str))


class Engine:
    def __init__(self, conf: AppConf, conf_hash: str,
                 pigment: PigmentClient | None = None,
                 tm1_factory: Callable[[], TM1Adapter] | None = None):
        self.conf = conf
        self.conf_hash = conf_hash
        self.pigment = pigment or PigmentClient(conf.pigment)
        self.tm1_factory = tm1_factory or (lambda: TM1Adapter(conf.tm1))
        key = None
        if conf.runtime.audit_hmac_key_env:
            try:
                key = get_secret(conf.runtime.audit_hmac_key_env)
            except ConnectorError:
                if conf.runtime.environment == "prod":
                    raise
                log.warning("Audit non signé (pas de clé HMAC) : acceptable hors production uniquement")
        self.audit = AuditLog(conf.runtime.audit_log, key)

    # ================================================================== entrée
    def run(self, flow_name: str, opts: RunOptions) -> dict:
        flow = self.conf.flow(flow_name)
        if not flow.enabled:
            raise GovernanceError(f"Flux {flow.name} désactivé dans la configuration")
        run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
        operator = opts.operator or getpass.getuser()
        ev = Evidence(Path(self.conf.runtime.work_dir) / flow.name / run_id)
        base = {"run_id": run_id, "flow": flow.name, "direction": flow.direction,
                "config_sha256": self.conf_hash, "operator": operator,
                "environment": self.conf.runtime.environment, "dry_run": opts.dry_run}
        report: dict = {**base, "status": "started"}
        with FlowLock(self.conf.runtime.lock_dir, flow.name, run_id):
            self.audit.append("run_started", **base, approved_by=opts.approved_by, ticket=opts.ticket)
            try:
                if flow.direction == "pigment_to_tm1":
                    report.update(self._pigment_to_tm1(flow, opts, ev, operator, run_id))
                else:
                    report.update(self._tm1_to_pigment(flow, opts, ev, operator))
                report["status"] = "dry_run_ok" if opts.dry_run else "success"
                self.audit.append("run_succeeded", **base, result=_slim(report))
                return report
            except ConnectorError as exc:
                report.update(status="failed", error_type=type(exc).__name__, error=redact(str(exc)),
                              issues=getattr(exc, "issues", []))
                self.audit.append("run_failed", **base, error_type=type(exc).__name__,
                                  error=redact(str(exc))[:2000], result=_slim(report))
                raise
            except Exception as exc:  # erreur imprévue : on trace puis on remonte
                report.update(status="failed", error_type=type(exc).__name__, error=redact(str(exc)))
                self.audit.append("run_failed", **base, error_type=type(exc).__name__,
                                  error=redact(str(exc))[:2000])
                raise ConnectorError(f"Erreur inattendue : {redact(str(exc))}") from exc
            finally:
                ev.json("report.json", report)

    # ================================================================ gouvernance
    def _approve(self, flow: FlowConf, opts: RunOptions, operator: str) -> None:
        if opts.dry_run or not flow.governance.require_approval:
            return
        if not opts.approved_by:
            raise GovernanceError("Approbation requise : --approved-by <nom> (et --ticket en production)")
        if self.conf.runtime.environment == "prod":
            if not opts.ticket:
                raise GovernanceError("Référence de ticket/changement obligatoire en production (--ticket)")
            if opts.approved_by.strip().lower() == operator.strip().lower():
                raise GovernanceError("Principe des quatre yeux : l'approbateur doit différer de l'opérateur")

    @staticmethod
    def _change_guard(flow: FlowConf, before: pd.DataFrame, after: pd.DataFrame) -> dict:
        b = float(before[VALUE].sum()) if len(before) else 0.0
        a = float(after[VALUE].sum()) if len(after) else 0.0
        pct = None if b == 0 else abs(a - b) / abs(b) * 100
        info = {"total_before": round(b, 6), "total_after_expected": round(a, 6),
                "change_pct": None if pct is None else round(pct, 4)}
        lim = flow.governance.max_total_change_pct
        info["blocked"] = bool(lim is not None and pct is not None and pct > lim)
        return info

    # ========================================================= Pigment -> TM1
    def _pigment_to_tm1(self, flow: FlowConf, opts: RunOptions, ev: Evidence, operator: str, run_id: str) -> dict:
        src, tgt, m = flow.src, flow.tgt, flow.mapping
        raw_df, raw_text = self.pigment.export_view_df(src.view_id)
        out: dict = {"source_sha256": ev.text("source_pigment.csv", raw_text), "source_rows_raw": len(raw_df)}
        canon, issues = ds.pigment_to_canonical(raw_df, m, self.conf.pigment.decimal)

        with self.tm1_factory() as tm1:
            dims = tm1.cube_dimensions(tgt.cube)
            _check_coverage(dims, m, tgt.cube)
            if not issues:
                for d in m.columns.values():
                    canon, iss = ds.normalize_elements(canon, d, tm1.leaf_elements(d))
                    issues += iss
                for d, e in m.static_members.items():
                    if e.lower().replace(" ", "") not in {x.lower().replace(" ", "") for x in tm1.leaf_elements(d)}:
                        issues.append(f"Élément statique {d}={e} inexistant ou non-feuille")
                for d, allowed in tgt.slice.items():
                    if d in canon.columns:
                        outside = ~canon[d].str.lower().isin({a.lower() for a in allowed})
                        if outside.any():
                            issues.append(f"{int(outside.sum())} ligne(s) hors périmètre déclaré sur {d} : "
                                          f"{sorted(canon.loc[outside, d].unique())[:10]}")
                canon, iss = ds.validate(canon, dims, flow.governance, flow.aggregate_duplicates)
                issues += iss
            if issues:
                ev.json("validation_issues.json", issues)
                raise ValidationError(f"{len(issues)} anomalie(s) bloquante(s), aucune écriture", issues)

            out["canonical_sha256"] = ev.frame("source_canonical.csv", canon)
            out["fingerprint_source"] = ds.fingerprint(canon, dims)
            out["control_source"] = ds.control_totals(canon, flow.reconciliation.control_dimensions)

            scope = {**tgt.slice, **{d: [e] for d, e in m.static_members.items()}}
            before = ds.tm1_to_canonical(tm1.read(tgt.cube, scope), dims)
            out["before_sha256"] = ev.frame("target_before.csv", before)
            expected = canon if tgt.load_mode == "replace_slice" else _merge(before, canon, dims)

            preview = ds.reconcile(expected, before, dims, flow.reconciliation)
            ev.frame("preview_changes.csv", preview.diffs)
            out["preview"] = {"cells_new": preview.missing, "cells_cleared": preview.unexpected,
                              "cells_changed": preview.mismatched, "cells_unchanged": preview.matched}
            guard = self._change_guard(flow, before, expected)
            out["change_guard"] = guard
            if opts.dry_run:
                return out
            if guard["blocked"]:
                raise GovernanceError(f"Variation du total {guard['change_pct']} % > seuil "
                                      f"{flow.governance.max_total_change_pct} % : chargement bloqué")
            self._approve(flow, opts, operator)
            self.audit.append("load_authorized", run_id=run_id, flow=flow.name, approved_by=opts.approved_by,
                              ticket=opts.ticket, preview=out["preview"], change_guard=guard)

            use_sb = self.conf.tm1.use_sandbox and tm1.sandboxes_enabled()
            out["write_mode"] = "sandbox" if use_sb else "snapshot"
            recon = (self._load_sandbox if use_sb else self._load_snapshot)(
                tm1, flow, dims, scope, canon, expected, before, ev, run_id)
            out["reconciliation"] = recon.summary()
            return out

    def _write(self, tm1, flow, dims, scope, data, sandbox=None):
        if flow.tgt.load_mode == "replace_slice":
            tm1.clear(flow.tgt.cube, scope, sandbox=sandbox)
        if len(data):
            tm1.write(flow.tgt.cube, data, dims, sandbox=sandbox)

    def _verify(self, tm1, flow, dims, scope, expected, sandbox=None) -> ds.ReconResult:
        actual = ds.tm1_to_canonical(tm1.read(flow.tgt.cube, scope, sandbox=sandbox), dims)
        return ds.reconcile(expected, actual, dims, flow.reconciliation)

    def _load_sandbox(self, tm1, flow, dims, scope, canon, expected, before, ev, run_id):
        name = f"connector_{run_id}"[:60]
        with tm1.sandbox(name):
            self._write(tm1, flow, dims, scope, canon, sandbox=name)
            rs = self._verify(tm1, flow, dims, scope, expected, sandbox=name)
            if not rs.ok:
                ev.frame("diffs_sandbox.csv", rs.diffs)
                raise ReconciliationError(f"Écart en sandbox ({rs.summary()}) : rien n'a été publié")
            tm1.publish(name)
        rb = self._verify(tm1, flow, dims, scope, expected)
        if not rb.ok:
            ev.frame("diffs_after_publish.csv", rb.diffs)
            self._restore(tm1, flow, dims, scope, before, ev, reason="écart après publication")
        return rb

    def _load_snapshot(self, tm1, flow, dims, scope, canon, expected, before, ev, run_id):
        try:
            self._write(tm1, flow, dims, scope, canon)
        except Exception as exc:  # noqa: BLE001
            self._restore(tm1, flow, dims, scope, before, ev, reason=f"échec d'écriture : {exc}",
                          err_cls=LoadError)
        r = self._verify(tm1, flow, dims, scope, expected)
        if not r.ok:
            ev.frame("diffs.csv", r.diffs)
            self._restore(tm1, flow, dims, scope, before, ev, reason=f"écart de réconciliation {r.summary()}")
        return r

    def _restore(self, tm1, flow, dims, scope, before, ev, reason: str, err_cls=ReconciliationError):
        log.error("Restauration de l'état antérieur : %s", reason)
        try:
            tm1.clear(flow.tgt.cube, scope)
            if len(before):
                tm1.write(flow.tgt.cube, before, dims)
            chk = self._verify(tm1, flow, dims, scope, before)
        except Exception as exc:  # noqa: BLE001
            raise RollbackError(f"{reason} ; RESTAURATION ÉCHOUÉE ({exc}). "
                                f"État antérieur disponible : {ev.root / 'target_before.csv'}") from exc
        if not chk.ok:
            ev.frame("diffs_restore.csv", chk.diffs)
            raise RollbackError(f"{reason} ; restauration incomplète. Preuves : {ev.root}")
        raise err_cls(f"{reason} ; état antérieur restauré et vérifié")

    # ========================================================= TM1 -> Pigment
    def _tm1_to_pigment(self, flow: FlowConf, opts: RunOptions, ev: Evidence, operator: str) -> dict:
        src, tgt, m = flow.src, flow.tgt, flow.mapping
        keys = list(m.columns.values())
        out: dict = {}
        with self.tm1_factory() as tm1:
            dims = tm1.cube_dimensions(src.cube)
            _check_coverage(dims, m, src.cube)
            scope = {**src.slice, **{d: [e] for d, e in m.static_members.items()}}
            raw = ds.tm1_to_canonical(tm1.read(src.cube, scope, mdx=src.mdx), dims)
        out["source_sha256"] = ev.frame("source_tm1.csv", raw)
        issues = []
        for d, e in m.static_members.items():
            bad = raw[d].str.lower() != e.lower()
            if bad.any():
                issues.append(f"Lecture TM1 hors élément statique {d}={e} : {sorted(raw.loc[bad, d].unique())[:5]}")
        canon, iss = ds.validate(raw[keys + [VALUE]], keys, flow.governance, flow.aggregate_duplicates)
        issues += iss
        if issues:
            ev.json("validation_issues.json", issues)
            raise ValidationError(f"{len(issues)} anomalie(s) bloquante(s), aucun import", issues)

        out["fingerprint_source"] = ds.fingerprint(canon, keys)
        out["control_source"] = ds.control_totals(canon, flow.reconciliation.control_dimensions)
        payload = ds.to_csv(ds.canonical_to_pigment(canon, m), delimiter=",")
        out["payload_sha256"] = ev.text("payload_pigment.csv", payload)

        before = None
        if tgt.verification_view_id:
            before = self._pigment_view_canonical(tgt.verification_view_id, m, keys)
            ev.frame("target_before.csv", before)
            guard = self._change_guard(flow, before, canon)
            out["change_guard"] = guard
            prev = ds.reconcile(canon, before, keys, flow.reconciliation)
            out["preview"] = {"cells_new": prev.missing, "cells_absent_from_source": prev.unexpected,
                              "cells_changed": prev.mismatched, "cells_unchanged": prev.matched}
            if guard["blocked"] and not opts.dry_run:
                raise GovernanceError(f"Variation du total {guard['change_pct']} % > seuil : import bloqué")
        else:
            out["warning"] = "Pas de verification_view_id : import non relu (non recommandé)"
        if opts.dry_run:
            return out
        self._approve(flow, opts, operator)
        self.audit.append("load_authorized", flow=flow.name, approved_by=opts.approved_by, ticket=opts.ticket,
                          payload_sha256=out["payload_sha256"], preview=out.get("preview"))

        import_id = self.pigment.push_csv(tgt.import_configuration_id, payload)
        out["import_id"] = import_id
        self.audit.append("pigment_import_submitted", flow=flow.name, import_id=import_id)
        status = self.pigment.wait_import(import_id)
        ev.json("pigment_import_status.json", status)

        if tgt.verification_view_id:
            after = self._pigment_view_canonical(tgt.verification_view_id, m, keys)
            r = ds.reconcile(canon, after, keys, flow.reconciliation)
            out["reconciliation"] = r.summary()
            if not r.ok:
                ev.frame("diffs.csv", r.diffs)
                self._compensate_pigment(flow, before, m, keys, ev)
                raise ReconciliationError(f"Écart après import Pigment {r.summary()} ; "
                                          "état antérieur ré-importé et vérifié")
        return out

    def _pigment_view_canonical(self, view_id: str, m, keys) -> pd.DataFrame:
        df, _ = self.pigment.export_view_df(view_id)
        canon, issues = ds.pigment_to_canonical(df, m, self.conf.pigment.decimal)
        if issues:
            raise LoadError(f"Vue de vérification illisible : {issues}")
        return canon[keys + [VALUE]]

    def _compensate_pigment(self, flow, before, m, keys, ev):
        if before is None:
            return
        payload = ds.to_csv(ds.canonical_to_pigment(before, m), delimiter=",")
        ev.text("compensation_payload.csv", payload)
        try:
            iid = self.pigment.push_csv(flow.tgt.import_configuration_id, payload)
            self.pigment.wait_import(iid)
            chk = ds.reconcile(before, self._pigment_view_canonical(flow.tgt.verification_view_id, m, keys),
                               keys, flow.reconciliation)
        except Exception as exc:  # noqa: BLE001
            raise RollbackError(f"Compensation Pigment échouée : {exc}. État antérieur : "
                                f"{ev.root / 'target_before.csv'}") from exc
        if not chk.ok:
            raise RollbackError(f"Compensation Pigment incomplète. Preuves : {ev.root}")


# ------------------------------------------------------------------ utilitaires
def _check_coverage(dims: list[str], m, cube: str) -> None:
    covered = set(m.columns.values()) | set(m.static_members)
    missing, extra = set(dims) - covered, covered - set(dims)
    if missing or extra:
        raise ConfigError(f"Mapping incohérent avec le cube {cube} : dimensions non couvertes {sorted(missing)}, "
                          f"inconnues {sorted(extra)}. Chaque dimension doit être mappée ou statique.")


def _merge(before: pd.DataFrame, new: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    if before.empty:
        return new
    b = before.set_index(keys)
    n = new.set_index(keys)
    return pd.concat([b[~b.index.isin(n.index)], n]).reset_index()


def _slim(report: dict) -> dict:
    """Résumé pour l'audit (sans les totaux détaillés par membre)."""
    return {k: v for k, v in report.items() if k not in ("control_source",)}
