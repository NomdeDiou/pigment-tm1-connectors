"""Configuration déclarative et validée des flux.

Aucun secret n'est accepté dans ce fichier : uniquement des *noms* de variables
d'environnement. Le fichier est destiné à être versionné et revu (pull request).
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .errors import ConfigError

_FORBIDDEN_KEYS = {"password", "api_key", "apikey", "token", "secret", "client_secret"}


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class PigmentConf(_Strict):
    base_url: str = "https://pigment.app/api/v1"
    api_key_env: str = "PIGMENT_API_KEY"
    timeout_s: int = 300
    csv_delimiter: str = ";"
    decimal: str = "."
    import_poll_interval_s: float = 5.0
    import_timeout_s: int = 1800
    # Les libellés de statut d'import sont à confirmer sur https://pigment.app/api/swagger
    import_success_states: list[str] = ["completed", "succeeded", "success", "done"]
    import_failure_states: list[str] = ["failed", "error", "cancelled", "canceled", "rejected"]

    @field_validator("base_url")
    @classmethod
    def _https_only(cls, v: str) -> str:
        if not v.startswith("https://"):
            raise ValueError("Pigment doit être joint en HTTPS")
        return v.rstrip("/")


class TM1Conf(_Strict):
    """Paramètres non secrets passés tels quels à TM1py.TM1Service.

    `connection` : ex. {base_url: ..., namespace: ...} ou {address, port, ssl}.
    `secret_env` : paramètre TM1Service -> nom de variable d'environnement,
                   ex. {user: TM1_USER, password: TM1_PASSWORD}.
    """
    connection: dict = Field(default_factory=dict)
    secret_env: dict[str, str] = Field(default_factory=dict)
    verify_tls: bool | str = True
    use_sandbox: bool = True  # écriture atomique via sandbox TM1 si disponible

    @model_validator(mode="after")
    def _no_secret_inline(self):
        leaked = _FORBIDDEN_KEYS & {k.lower() for k in self.connection}
        if leaked:
            raise ValueError(f"Secret en clair interdit dans tm1.connection : {sorted(leaked)}. "
                             "Utilisez tm1.secret_env.")
        if self.verify_tls is False:
            raise ValueError("verify_tls: false est interdit. Fournissez un chemin de bundle CA si besoin.")
        if self.connection.get("ssl") is False:
            raise ValueError("ssl: false est interdit.")
        return self


class MappingConf(_Strict):
    # colonne Pigment -> dimension TM1 (sert dans les deux sens)
    columns: dict[str, str]
    value_column: str = "Value"           # colonne valeur côté Pigment
    static_members: dict[str, str] = Field(default_factory=dict)  # dimension TM1 -> élément fixe
    # dimension TM1 -> {valeur Pigment: élément TM1}. Doit être bijectif.
    member_maps: dict[str, dict[str, str]] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _bijective(self):
        tm1_dims = list(self.columns.values())
        if len(set(tm1_dims)) != len(tm1_dims):
            raise ValueError("Deux colonnes Pigment pointent vers la même dimension TM1")
        overlap = set(tm1_dims) & set(self.static_members)
        if overlap:
            raise ValueError(f"Dimensions à la fois mappées et statiques : {overlap}")
        for dim, m in self.member_maps.items():
            if len(set(m.values())) != len(m):
                raise ValueError(f"member_maps[{dim}] n'est pas bijectif (inversion impossible)")
        return self


class GovernanceConf(_Strict):
    # Membres jamais écrits (ex. Version: [Actual] pour un flux budget)
    protected_members: dict[str, list[str]] = Field(default_factory=dict)
    # Si défini, seuls ces membres sont autorisés (liste blanche)
    allowed_members: dict[str, list[str]] = Field(default_factory=dict)
    max_rows: int = 2_000_000
    min_rows: int = 1                     # protège contre l'effacement par une source vide
    max_total_change_pct: float | None = 25.0   # écart max du total vs l'existant cible
    require_approval: bool = True
    allow_negative: bool = True


class ReconciliationConf(_Strict):
    abs_tolerance: float = 0.005
    rel_tolerance: float = 1e-9
    control_dimensions: list[str] = Field(default_factory=list)  # totaux de contrôle par axe
    max_diff_report_rows: int = 500


class PigmentToTM1Source(_Strict):
    view_id: str


class PigmentToTM1Target(_Strict):
    cube: str
    # Périmètre écrit (et effacé en mode replace) : dimension -> éléments.
    # Les dimensions non listées et non statiques couvrent leurs feuilles (niveau 0).
    slice: dict[str, list[str]] = Field(default_factory=dict)
    load_mode: Literal["replace_slice", "merge"] = "replace_slice"


class TM1ToPigmentSource(_Strict):
    cube: str
    slice: dict[str, list[str]] = Field(default_factory=dict)
    mdx: str | None = None   # alternative : MDX explicite


class TM1ToPigmentTarget(_Strict):
    import_configuration_id: str
    # Vue Pigment (même grain) relue après import pour réconcilier. Fortement recommandé.
    verification_view_id: str | None = None


class FlowConf(_Strict):
    name: str
    description: str = ""
    owner: str                         # responsable métier du flux
    enabled: bool = True
    direction: Literal["pigment_to_tm1", "tm1_to_pigment"]
    source: dict
    target: dict
    mapping: MappingConf
    governance: GovernanceConf = GovernanceConf()
    reconciliation: ReconciliationConf = ReconciliationConf()
    aggregate_duplicates: bool = False  # par défaut, un doublon de clé est une erreur

    @field_validator("name")
    @classmethod
    def _safe_name(cls, v: str) -> str:
        if not v.replace("_", "").replace("-", "").isalnum():
            raise ValueError("Nom de flux : lettres, chiffres, _ et - uniquement")
        return v

    @property
    def src(self):
        return (PigmentToTM1Source if self.direction == "pigment_to_tm1" else TM1ToPigmentSource)(**self.source)

    @property
    def tgt(self):
        return (PigmentToTM1Target if self.direction == "pigment_to_tm1" else TM1ToPigmentTarget)(**self.target)

    @model_validator(mode="after")
    def _check_endpoints(self):
        _ = self.src, self.tgt  # validation stricte des sous-structures
        if self.direction == "tm1_to_pigment" and self.tgt.verification_view_id is None:
            # autorisé mais signalé : sans vue de vérification, pas de relecture.
            pass
        return self


class RuntimeConf(_Strict):
    work_dir: str = "./runs"            # preuves par exécution
    audit_log: str = "./audit/audit.jsonl"
    audit_hmac_key_env: str | None = "CONNECTOR_AUDIT_HMAC_KEY"
    lock_dir: str = "./locks"
    environment: Literal["dev", "test", "prod"] = "dev"


class AppConf(_Strict):
    runtime: RuntimeConf = RuntimeConf()
    pigment: PigmentConf = PigmentConf()
    tm1: TM1Conf = TM1Conf()
    flows: list[FlowConf]

    def flow(self, name: str) -> FlowConf:
        for f in self.flows:
            if f.name == name:
                return f
        raise ConfigError(f"Flux inconnu : {name}. Flux déclarés : {[f.name for f in self.flows]}")


def load_config(path: str | Path) -> tuple[AppConf, str]:
    """Charge et valide la configuration. Retourne (config, empreinte SHA-256 du fichier)."""
    p = Path(path)
    if not p.is_file():
        raise ConfigError(f"Fichier de configuration introuvable : {p}")
    raw = p.read_bytes()
    try:
        data = yaml.safe_load(raw)
        conf = AppConf.model_validate(data)
    except Exception as exc:  # pydantic / yaml
        raise ConfigError(f"Configuration invalide ({p}) :\n{exc}") from exc
    names = [f.name for f in conf.flows]
    if len(names) != len(set(names)):
        raise ConfigError("Noms de flux en double")
    return conf, hashlib.sha256(raw).hexdigest()
