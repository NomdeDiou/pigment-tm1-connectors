"""Modèle de données pivot, transformation, validation et réconciliation.

Format canonique : une colonne par dimension TM1 (noms TM1) + colonne "Value" (float).
Le même mapping sert dans les deux sens, ce qui garantit la symétrie des flux.
"""
from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass, field

import pandas as pd

from .config import GovernanceConf, MappingConf, ReconciliationConf

VALUE = "Value"


# ---------------------------------------------------------------- conversion
def _to_number(series: pd.Series, decimal: str) -> tuple[pd.Series, pd.Series]:
    s = series.astype(str).str.strip().str.replace(" ", "", regex=False).str.replace(" ", "", regex=False)
    if decimal != ".":
        s = s.str.replace(".", "", regex=False).str.replace(decimal, ".", regex=False)
    blank = s.eq("") | s.str.lower().isin({"nan", "none", "null"})
    num = pd.to_numeric(s.where(~blank), errors="coerce")
    bad = num.isna() & ~blank
    return num, bad


def pigment_to_canonical(df: pd.DataFrame, m: MappingConf, decimal: str = ".") -> tuple[pd.DataFrame, list[str]]:
    issues: list[str] = []
    expected = list(m.columns) + [m.value_column]
    missing = [c for c in expected if c not in df.columns]
    if missing:
        return pd.DataFrame(), [f"Colonnes absentes de l'export Pigment : {missing} (reçues : {list(df.columns)})"]
    out = df[expected].rename(columns={**m.columns, m.value_column: VALUE}).copy()
    for dim in m.columns.values():
        out[dim] = out[dim].astype(str).str.strip()
        if dim in m.member_maps:
            out[dim] = out[dim].map(lambda v, mm=m.member_maps[dim]: mm.get(v, v))
    num, bad = _to_number(out[VALUE], decimal)
    if bad.any():
        sample = out.loc[bad, VALUE].head(5).tolist()
        issues.append(f"{int(bad.sum())} valeur(s) non numérique(s), ex. {sample}")
    out[VALUE] = num
    out = out[out[VALUE].notna()]                # cellule vide = pas de donnée
    for dim, elem in m.static_members.items():
        out[dim] = elem
    return out.reset_index(drop=True), issues


def canonical_to_pigment(df: pd.DataFrame, m: MappingConf) -> pd.DataFrame:
    inverse_cols = {v: k for k, v in m.columns.items()}
    out = df[list(m.columns.values()) + [VALUE]].copy()
    for dim, mm in m.member_maps.items():
        inv = {v: k for k, v in mm.items()}
        out[dim] = out[dim].map(lambda v, inv=inv: inv.get(v, v))
    return out.rename(columns={**inverse_cols, VALUE: m.value_column})


def tm1_to_canonical(df: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame(columns=keys + [VALUE])
    out = df.copy()
    missing = [k for k in keys if k not in out.columns]
    if missing:
        raise ValueError(f"Dimensions absentes de la lecture TM1 : {missing}")
    out[VALUE] = pd.to_numeric(out[VALUE], errors="coerce")
    out = out[out[VALUE].notna()]
    return out[keys + [VALUE]].reset_index(drop=True)


def to_csv(df: pd.DataFrame, delimiter: str = ",") -> str:
    return df.to_csv(index=False, sep=delimiter, float_format="%.10g", lineterminator="\n")


# ---------------------------------------------------------------- validation
def normalize_elements(df: pd.DataFrame, dim: str, leaves: list[str]) -> tuple[pd.DataFrame, list[str]]:
    """TM1 ignore la casse et les espaces : on ramène chaque valeur au nom exact de l'élément feuille."""
    lookup = {e.lower().replace(" ", ""): e for e in leaves}
    keyed = df[dim].map(lambda v: lookup.get(str(v).lower().replace(" ", "")))
    unknown = sorted(df.loc[keyed.isna(), dim].unique().tolist())
    issues = []
    if unknown:
        issues.append(f"Dimension {dim} : {len(unknown)} élément(s) inconnu(s) ou non-feuille(s), ex. {unknown[:10]}")
    df = df.copy()
    df[dim] = keyed.fillna(df[dim])
    return df, issues


def validate(df: pd.DataFrame, keys: list[str], gov: GovernanceConf, aggregate_duplicates: bool
             ) -> tuple[pd.DataFrame, list[str]]:
    issues: list[str] = []
    n = len(df)
    if n < gov.min_rows:
        issues.append(f"Source avec {n} ligne(s) < min_rows={gov.min_rows} (protection contre l'effacement)")
    if n > gov.max_rows:
        issues.append(f"Source avec {n} lignes > max_rows={gov.max_rows}")
    for k in keys:
        blank = df[k].astype(str).str.strip().eq("")
        if blank.any():
            issues.append(f"{int(blank.sum())} clé(s) vide(s) sur {k}")
    if not df.empty and not df[VALUE].map(math.isfinite).all():
        issues.append("Valeurs infinies détectées")
    if not gov.allow_negative and (df[VALUE] < 0).any():
        issues.append(f"{int((df[VALUE] < 0).sum())} valeur(s) négative(s) interdite(s)")
    for dim, prot in gov.protected_members.items():
        if dim in df.columns:
            hit = df[dim].str.lower().isin({p.lower() for p in prot})
            if hit.any():
                issues.append(f"Membres protégés présents sur {dim} : {sorted(df.loc[hit, dim].unique())}")
    for dim, allowed in gov.allowed_members.items():
        if dim in df.columns:
            bad = ~df[dim].str.lower().isin({a.lower() for a in allowed})
            if bad.any():
                issues.append(f"Membres hors liste blanche sur {dim} : {sorted(df.loc[bad, dim].unique())[:10]}")
    dup = df.duplicated(subset=keys, keep=False)
    if dup.any():
        if aggregate_duplicates:
            df = df.groupby(keys, as_index=False, sort=False)[VALUE].sum()
        else:
            issues.append(f"{int(dup.sum())} ligne(s) en doublon de clé (aggregate_duplicates=false)")
    return df, issues


# ---------------------------------------------------------------- preuves
def fingerprint(df: pd.DataFrame, keys: list[str], decimals: int = 6) -> str:
    """Empreinte indépendante de l'ordre des lignes et des zéros."""
    if df.empty:
        return hashlib.sha256(b"").hexdigest()
    d = df[keys + [VALUE]].copy()
    d[VALUE] = d[VALUE].round(decimals)
    d = d[d[VALUE] != 0]
    d[keys] = d[keys].astype(str)
    d = d.sort_values(keys)
    h = hashlib.sha256()
    for row in d.itertuples(index=False):
        h.update(("\x1f".join(map(str, row[:-1])) + "\x1e" + f"{row[-1]:.{decimals}f}\n").encode())
    return h.hexdigest()


def control_totals(df: pd.DataFrame, dims: list[str]) -> dict:
    res = {"rows": int(len(df)), "total": round(float(df[VALUE].sum()) if len(df) else 0.0, 6),
           "abs_total": round(float(df[VALUE].abs().sum()) if len(df) else 0.0, 6)}
    for d in dims:
        if d in df.columns and len(df):
            res[f"by_{d}"] = {str(k): round(float(v), 6) for k, v in df.groupby(d)[VALUE].sum().items()}
    return res


@dataclass
class ReconResult:
    ok: bool
    expected_rows: int
    actual_rows: int
    matched: int
    missing: int          # attendues, absentes de la cible
    unexpected: int       # présentes dans la cible, non attendues
    mismatched: int       # valeur différente au-delà de la tolérance
    expected_total: float
    actual_total: float
    expected_fingerprint: str
    actual_fingerprint: str
    diffs: pd.DataFrame = field(repr=False, default_factory=pd.DataFrame)

    def summary(self) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k != "diffs"}
        d["diff_rows"] = int(len(self.diffs))
        return d


def reconcile(expected: pd.DataFrame, actual: pd.DataFrame, keys: list[str], rc: ReconciliationConf
              ) -> ReconResult:
    e = expected[keys + [VALUE]].copy()
    a = actual[keys + [VALUE]].copy()
    e = e[e[VALUE].abs() > rc.abs_tolerance]        # TM1 ne stocke pas les zéros
    a = a[a[VALUE].abs() > rc.abs_tolerance]
    for k in keys:
        e[k] = e[k].astype(str)
        a[k] = a[k].astype(str)
    j = e.merge(a, on=keys, how="outer", suffixes=("_expected", "_actual"), indicator=True)
    ve, va = j[f"{VALUE}_expected"], j[f"{VALUE}_actual"]
    both = j["_merge"] == "both"
    tol = rc.abs_tolerance + rc.rel_tolerance * ve.abs().fillna(0)
    mism = both & ((ve - va).abs() > tol)
    missing = j["_merge"] == "left_only"
    unexpected = j["_merge"] == "right_only"
    diffs = j[mism | missing | unexpected].copy()
    diffs["status"] = diffs["_merge"].map({"both": "valeur_differente", "left_only": "absente_cible",
                                           "right_only": "inattendue_cible"})
    diffs = diffs.drop(columns="_merge")
    ok = not (mism.any() or missing.any() or unexpected.any())
    return ReconResult(
        ok=ok, expected_rows=len(e), actual_rows=len(a), matched=int((both & ~mism).sum()),
        missing=int(missing.sum()), unexpected=int(unexpected.sum()), mismatched=int(mism.sum()),
        expected_total=round(float(e[VALUE].sum()), 6), actual_total=round(float(a[VALUE].sum()), 6),
        expected_fingerprint=fingerprint(e, keys), actual_fingerprint=fingerprint(a, keys),
        diffs=diffs.head(rc.max_diff_report_rows),
    )
