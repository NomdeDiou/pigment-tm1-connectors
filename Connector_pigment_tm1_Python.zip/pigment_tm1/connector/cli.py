"""Ligne de commande.

  python -m connector -c config/flows.yaml list
  python -m connector -c config/flows.yaml validate-config
  python -m connector -c config/flows.yaml run budget_pigment_to_tm1 --dry-run
  python -m connector -c config/flows.yaml run budget_pigment_to_tm1 --approved-by "j.martin" --ticket CHG-1234
  python -m connector -c config/flows.yaml verify-audit

Codes de sortie : 0 succès, 2 config, 3 secret, 4 validation, 5 gouvernance,
6 chargement, 7 réconciliation (état restauré), 8 verrou, 9 restauration échouée (CRITIQUE).
"""
from __future__ import annotations

import argparse
import json
import logging
import sys

from .audit import AuditLog
from .config import load_config
from .engine import Engine, RunOptions
from .errors import ConnectorError
from .secrets import RedactingFilter, get_secret


class _JsonFormatter(logging.Formatter):
    def format(self, r: logging.LogRecord) -> str:
        return json.dumps({"ts": self.formatTime(r, "%Y-%m-%dT%H:%M:%S%z"), "level": r.levelname,
                           "logger": r.name, "msg": r.getMessage()}, ensure_ascii=False)


def _setup_logging(level: str) -> None:
    h = logging.StreamHandler(sys.stderr)
    h.setFormatter(_JsonFormatter())
    h.addFilter(RedactingFilter())
    logging.basicConfig(level=level, handlers=[h], force=True)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="connector", description="Connecteur Pigment <-> TM1 / Planning Analytics")
    ap.add_argument("-c", "--config", default="config/flows.yaml")
    ap.add_argument("--log-level", default="INFO")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list", help="lister les flux")
    sub.add_parser("validate-config", help="valider la configuration sans rien contacter")
    sub.add_parser("verify-audit", help="vérifier l'intégrité du journal d'audit")
    r = sub.add_parser("run", help="exécuter un flux")
    r.add_argument("flow")
    r.add_argument("--dry-run", action="store_true", help="extraire, valider, prévisualiser ; n'écrit rien")
    r.add_argument("--approved-by")
    r.add_argument("--ticket")
    r.add_argument("--operator", help="identité de l'opérateur (défaut : utilisateur système)")
    a = ap.parse_args(argv)
    _setup_logging(a.log_level)

    try:
        conf, h = load_config(a.config)
        if a.cmd == "list":
            for f in conf.flows:
                print(f"{f.name:40s} {f.direction:16s} owner={f.owner:20s} {'actif' if f.enabled else 'INACTIF'}")
            return 0
        if a.cmd == "validate-config":
            print(json.dumps({"ok": True, "config_sha256": h, "flows": [f.name for f in conf.flows]}, indent=2))
            return 0
        if a.cmd == "verify-audit":
            key = None
            if conf.runtime.audit_hmac_key_env:
                try:
                    key = get_secret(conf.runtime.audit_hmac_key_env)
                except ConnectorError:
                    pass
            ok, n, msg = AuditLog(conf.runtime.audit_log, key).verify()
            print(json.dumps({"ok": ok, "records": n, "message": msg}, ensure_ascii=False))
            return 0 if ok else 10
        report = Engine(conf, h).run(a.flow, RunOptions(dry_run=a.dry_run, approved_by=a.approved_by,
                                                        ticket=a.ticket, operator=a.operator))
        print(json.dumps(report, indent=2, ensure_ascii=False, default=str))
        return 0
    except ConnectorError as exc:
        logging.getLogger("connector").error("%s: %s", type(exc).__name__, exc)
        for i in getattr(exc, "issues", []):
            logging.getLogger("connector").error("  - %s", i)
        return exc.exit_code


if __name__ == "__main__":
    sys.exit(main())
