"""Connecteur bidirectionnel Pigment <-> IBM Planning Analytics (TM1).

Principes :
  * vérifiable  : relecture après chargement + réconciliation cellule à cellule,
                  totaux de contrôle, empreintes SHA-256, preuves conservées par exécution ;
  * infaillible : validation bloquante avant écriture, écriture atomique (sandbox TM1
                  ou snapshot + restauration automatique), verrou anti-concurrence,
                  aucune relance automatique des écritures non idempotentes ;
  * sécurisé    : secrets uniquement via variables d'environnement / fichiers montés,
                  TLS vérifié obligatoire, masquage des secrets dans les logs ;
  * gouvernable : flux déclaratifs versionnés, membres protégés, seuils de garde,
                  approbation nominative + ticket, journal d'audit chaîné (HMAC).
"""

__version__ = "1.0.0"
