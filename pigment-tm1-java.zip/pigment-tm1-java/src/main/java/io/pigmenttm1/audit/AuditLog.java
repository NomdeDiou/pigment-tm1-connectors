package io.pigmenttm1.audit;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;

/**
 * Journal d'audit append-only, chaîné et (optionnellement) signé HMAC-SHA256.
 * Toute modification, suppression ou insertion a posteriori casse la chaîne.
 * Avec une clé HMAC conservée hors du serveur, la chaîne ne peut pas être réécrite.
 */
public final class AuditLog {
    public static final String GENESIS = "0".repeat(64);
    private static final ObjectMapper CANON = new ObjectMapper()
            .configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);

    public record Verification(boolean ok, int records, String message) {}

    private final Path path;
    private final byte[] key;

    public AuditLog(Path path, String hmacKey) {
        this.path = path;
        this.key = hmacKey == null ? null : hmacKey.getBytes(StandardCharsets.UTF_8);
    }

    public Path path() { return path; }

    private String digest(Map<String, Object> body) {
        try {
            byte[] canon = CANON.writeValueAsBytes(new TreeMap<>(body));
            if (key != null) {
                Mac mac = Mac.getInstance("HmacSHA256");
                mac.init(new SecretKeySpec(key, "HmacSHA256"));
                return HexFormat.of().formatHex(mac.doFinal(canon));
            }
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(canon));
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    /** Ajoute un événement ; écriture sous verrou fichier + fsync avant de rendre la main. */
    public synchronized Map<String, Object> append(String event, Map<String, Object> fields) {
        try {
            Files.createDirectories(path.toAbsolutePath().getParent());
            try (FileChannel ch = FileChannel.open(path, StandardOpenOption.CREATE,
                    StandardOpenOption.WRITE, StandardOpenOption.APPEND);
                 FileLock ignored = ch.lock()) {
                String prev = GENESIS;
                long seq = 0;
                List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
                for (int i = lines.size() - 1; i >= 0; i--) {
                    if (!lines.get(i).isBlank()) {
                        Map<String, Object> last = CANON.readValue(lines.get(i), new TypeReference<>() {});
                        prev = (String) last.get("hash");
                        seq = ((Number) last.get("seq")).longValue();
                        break;
                    }
                }
                Map<String, Object> body = new TreeMap<>(fields);
                body.put("seq", seq + 1);
                body.put("ts", Instant.now().toString());
                body.put("event", event);
                body.put("prev_hash", prev);
                body.put("signed", key != null);
                // normalisation : ce qui sera relu doit être exactement ce qui est haché
                body = CANON.readValue(CANON.writeValueAsBytes(body), new TypeReference<TreeMap<String, Object>>() {});
                Map<String, Object> rec = new TreeMap<>(body);
                rec.put("hash", digest(body));
                ch.write(ByteBuffer.wrap((CANON.writeValueAsString(rec) + "\n").getBytes(StandardCharsets.UTF_8)));
                ch.force(true);
                return rec;
            }
        } catch (IOException e) {
            throw new IllegalStateException("Écriture du journal d'audit impossible : " + e.getMessage(), e);
        }
    }

    public Verification verify() {
        if (!Files.exists(path)) return new Verification(true, 0, "journal vide");
        String prev = GENESIS;
        long expected = 1;
        int lineno = 0, ok = 0;
        try {
            for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
                lineno++;
                if (line.isBlank()) continue;
                Map<String, Object> rec;
                try {
                    rec = CANON.readValue(line, new TypeReference<TreeMap<String, Object>>() {});
                } catch (IOException e) {
                    return new Verification(false, ok, "ligne " + lineno + " illisible");
                }
                Object h = rec.remove("hash");
                Object seq = rec.get("seq");
                if (!(seq instanceof Number n) || n.longValue() != expected)
                    return new Verification(false, ok, "ligne " + lineno + " : séquence " + seq + " ≠ " + expected);
                if (!prev.equals(rec.get("prev_hash")))
                    return new Verification(false, ok, "ligne " + lineno + " : chaînage rompu");
                if (Boolean.TRUE.equals(rec.get("signed")) && key == null)
                    return new Verification(false, ok, "journal signé : clé HMAC requise pour vérifier");
                String d = digest(rec);
                if (!MessageDigest.isEqual(d.getBytes(StandardCharsets.US_ASCII),
                        String.valueOf(h).getBytes(StandardCharsets.US_ASCII)))
                    return new Verification(false, ok, "ligne " + lineno + " : empreinte invalide (altération)");
                prev = (String) h;
                expected++;
                ok++;
            }
        } catch (IOException e) {
            return new Verification(false, ok, "lecture impossible : " + e.getMessage());
        }
        return new Verification(true, ok, "intègre");
    }
}
