package io.pigmenttm1.cli;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import io.pigmenttm1.audit.AuditLog;
import io.pigmenttm1.config.Config;
import io.pigmenttm1.core.Engine;
import io.pigmenttm1.core.Errors.ConnectorException;
import io.pigmenttm1.core.Errors.SecretError;
import io.pigmenttm1.core.Secrets;

import java.io.PrintStream;
import java.nio.file.Path;
import java.time.Instant;
import java.util.*;
import java.util.logging.*;

/**
 * Ligne de commande.
 *
 *   java -jar pigment-tm1-connector.jar -c config/flows.json list
 *   java -jar pigment-tm1-connector.jar -c config/flows.json validate-config
 *   java -jar pigment-tm1-connector.jar -c config/flows.json run budget_pigment_to_tm1 --dry-run
 *   java -jar pigment-tm1-connector.jar -c config/flows.json run budget_pigment_to_tm1 --approved-by j.martin --ticket CHG-1234
 *   java -jar pigment-tm1-connector.jar -c config/flows.json verify-audit
 *
 * Codes de sortie : 0 succès, 2 config, 3 secret, 4 validation, 5 gouvernance, 6 chargement,
 * 7 réconciliation (état restauré), 8 verrou, 9 restauration échouée (CRITIQUE), 10 audit altéré, 64 usage.
 */
public final class Main {
    private static final ObjectMapper JSON = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

    public static void main(String[] args) {
        System.exit(run(args, System.out, System.err));
    }

    public static int run(String[] args, PrintStream out, PrintStream err) {
        setupLogging(err);
        String config = "config/flows.json", cmd = null, flow = null, approvedBy = null, ticket = null, operator = null;
        boolean dryRun = false;
        try {
            for (int i = 0; i < args.length; i++) {
                switch (args[i]) {
                    case "-c", "--config" -> config = args[++i];
                    case "--dry-run" -> dryRun = true;
                    case "--approved-by" -> approvedBy = args[++i];
                    case "--ticket" -> ticket = args[++i];
                    case "--operator" -> operator = args[++i];
                    case "-h", "--help" -> { usage(out); return 0; }
                    default -> {
                        if (args[i].startsWith("-")) throw new IllegalArgumentException("option inconnue : " + args[i]);
                        if (cmd == null) cmd = args[i];
                        else if (flow == null) flow = args[i];
                        else throw new IllegalArgumentException("argument en trop : " + args[i]);
                    }
                }
            }
        } catch (ArrayIndexOutOfBoundsException | IllegalArgumentException e) {
            err.println("Usage incorrect : " + e.getMessage());
            usage(err);
            return 64;
        }
        if (cmd == null) { usage(err); return 64; }

        try {
            Config.Loaded loaded = Config.load(Path.of(config));
            Config c = loaded.config();
            switch (cmd) {
                case "list" -> {
                    for (Config.Flow f : c.flows)
                        out.printf("%-40s %-16s owner=%-20s %s%n", f.name, f.direction, f.owner, f.enabled ? "actif" : "INACTIF");
                    return 0;
                }
                case "validate-config" -> {
                    Map<String, Object> r = new LinkedHashMap<>();
                    r.put("ok", true); r.put("config_sha256", loaded.sha256());
                    r.put("flows", c.flows.stream().map(f -> f.name).toList());
                    out.println(JSON.writeValueAsString(r));
                    return 0;
                }
                case "verify-audit" -> {
                    String key = null;
                    if (c.runtime.auditHmacKeyEnv != null) {
                        try { key = Secrets.get(c.runtime.auditHmacKeyEnv); } catch (SecretError ignored) { }
                    }
                    AuditLog.Verification v = new AuditLog(Path.of(c.runtime.auditLog), key).verify();
                    out.println(JSON.writeValueAsString(Map.of("ok", v.ok(), "records", v.records(), "message", v.message())));
                    return v.ok() ? 0 : 10;
                }
                case "run" -> {
                    if (flow == null) { err.println("Précisez le flux : run <nom>"); return 64; }
                    Map<String, Object> report = Engine.production(loaded)
                            .run(flow, new Engine.RunOptions(dryRun, approvedBy, ticket, operator));
                    out.println(JSON.writeValueAsString(report));
                    return 0;
                }
                default -> { err.println("Commande inconnue : " + cmd); usage(err); return 64; }
            }
        } catch (ConnectorException e) {
            Logger log = Logger.getLogger("connector");
            log.severe(e.getClass().getSimpleName() + ": " + e.getMessage());
            for (String i : e.issues()) log.severe("  - " + i);
            return e.exitCode();
        } catch (Exception e) {
            Logger.getLogger("connector").severe("Erreur inattendue : " + Secrets.redact(String.valueOf(e.getMessage())));
            return 1;
        }
    }

    private static void usage(PrintStream p) {
        p.println("""
                Usage : java -jar pigment-tm1-connector.jar [-c config/flows.json] <commande>
                  list                         lister les flux
                  validate-config              valider la configuration sans rien contacter
                  verify-audit                 vérifier l'intégrité du journal d'audit
                  run <flux> [--dry-run] [--approved-by NOM] [--ticket REF] [--operator NOM]""");
    }

    /** Logs JSON sur stderr, secrets masqués. */
    private static void setupLogging(PrintStream err) {
        Logger root = Logger.getLogger("");
        for (Handler h : root.getHandlers()) root.removeHandler(h);
        StreamHandler h = new StreamHandler(err, new java.util.logging.Formatter() {
            @Override public String format(LogRecord r) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("ts", Instant.ofEpochMilli(r.getMillis()).toString());
                m.put("level", r.getLevel().getName());
                m.put("logger", r.getLoggerName());
                m.put("msg", Secrets.redact(formatMessage(r)));
                try { return new ObjectMapper().writeValueAsString(m) + System.lineSeparator(); }
                catch (Exception e) { return r.getMessage() + System.lineSeparator(); }
            }
        }) {
            @Override public synchronized void publish(LogRecord record) { super.publish(record); flush(); }
        };
        root.addHandler(h);
        root.setLevel(Level.INFO);
    }
}
