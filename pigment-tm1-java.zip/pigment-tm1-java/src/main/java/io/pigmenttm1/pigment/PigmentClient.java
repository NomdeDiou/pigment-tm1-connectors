package io.pigmenttm1.pigment;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.pigmenttm1.config.Config;
import io.pigmenttm1.core.Errors.LoadError;
import io.pigmenttm1.core.Http;
import io.pigmenttm1.core.Secrets;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Client de l'API publique Pigment (endpoints à confirmer sur https://pigment.app/api/swagger) :
 *   export : GET  {base}/export/view/{viewId}
 *   import : POST {base}/import/push/csv?configurationId={id}
 *   statut : GET  {base}/import/{importId}/status?includedDetailedReport=true
 */
public final class PigmentClient implements PigmentApi {
    private static final ObjectMapper JSON = new ObjectMapper();
    private final Config.Pigment conf;
    private final Http http;

    public PigmentClient(Config.Pigment conf) {
        this.conf = conf;
        this.http = new Http(Duration.ofSeconds(30), null, null, false, 5);
    }

    private HttpRequest.Builder req(String pathAndQuery) {
        return HttpRequest.newBuilder(URI.create(conf.baseUrl.replaceAll("/+$", "") + pathAndQuery))
                .timeout(Duration.ofSeconds(conf.timeoutS))
                .header("Authorization", "Bearer " + Secrets.get(conf.apiKeyEnv));
    }

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    @Override
    public String exportViewCsv(String viewId) {
        HttpResponse<String> r = http.read(req("/export/view/" + enc(viewId)).header("Accept", "text/csv").GET().build());
        if (r.statusCode() != 200)
            throw new LoadError("Export Pigment " + viewId + " : HTTP " + r.statusCode() + " " + Http.excerpt(r.body()));
        return r.body();
    }

    @Override
    public String pushCsv(String configurationId, String csv) {
        HttpResponse<String> r = http.once(req("/import/push/csv?configurationId=" + enc(configurationId))
                .header("Content-Type", "text/csv; charset=utf-8")
                .POST(HttpRequest.BodyPublishers.ofString(csv, StandardCharsets.UTF_8)).build());
        if (r.statusCode() < 200 || r.statusCode() > 202)
            throw new LoadError("Import Pigment refusé : HTTP " + r.statusCode() + " " + Http.excerpt(r.body()));
        Map<String, Object> body;
        try {
            body = JSON.readValue(r.body(), new TypeReference<>() {});
        } catch (Exception e) {
            throw new LoadError("Réponse d'import illisible : " + Http.excerpt(r.body()));
        }
        Object id = body.getOrDefault("importId", body.getOrDefault("id", body.get("ImportId")));
        if (id == null) throw new LoadError("Réponse d'import sans identifiant : " + Http.excerpt(r.body()));
        return id.toString();
    }

    public Map<String, Object> importStatus(String importId) {
        HttpResponse<String> r = http.read(req("/import/" + enc(importId) + "/status?includedDetailedReport=true").GET().build());
        if (r.statusCode() != 200) throw new LoadError("Statut d'import " + importId + " : HTTP " + r.statusCode());
        try {
            return JSON.readValue(r.body(), new TypeReference<>() {});
        } catch (Exception e) {
            throw new LoadError("Statut d'import illisible : " + Http.excerpt(r.body()));
        }
    }

    @Override
    public Map<String, Object> waitImport(String importId) {
        Set<String> ok = lower(conf.importSuccessStates), ko = lower(conf.importFailureStates);
        long deadline = System.nanoTime() + Duration.ofSeconds(conf.importTimeoutS).toNanos();
        while (true) {
            Map<String, Object> st = importStatus(importId);
            Object s = st.getOrDefault("status", st.get("state"));
            String state = s == null ? "" : s.toString().toLowerCase(Locale.ROOT);
            if (ok.contains(state)) return st;
            if (ko.contains(state)) throw new LoadError("Import Pigment " + importId + " en échec : " + Http.excerpt(st.toString()));
            if (System.nanoTime() > deadline) throw new LoadError("Import Pigment " + importId + " : délai dépassé (statut " + state + ")");
            try {
                Thread.sleep((long) (conf.importPollIntervalS * 1000));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new LoadError("Attente d'import interrompue");
            }
        }
    }

    private static Set<String> lower(java.util.List<String> l) {
        return l.stream().map(x -> x.toLowerCase(Locale.ROOT)).collect(Collectors.toSet());
    }
}
