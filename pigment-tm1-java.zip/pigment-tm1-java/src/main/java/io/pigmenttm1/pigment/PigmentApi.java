package io.pigmenttm1.pigment;

import java.util.Map;

/** Contrat minimal utilisé par le moteur (implémenté par le client réel et par les doubles de test). */
public interface PigmentApi {
    /** Exporte une vue au format CSV (texte brut, tel que reçu). */
    String exportViewCsv(String viewId);

    /** Pousse un CSV vers une configuration d'import. Jamais relancé automatiquement. Retourne l'identifiant d'import. */
    String pushCsv(String configurationId, String csv);

    /** Attend la fin de l'import ; lève LoadError en cas d'échec ou de délai dépassé. */
    Map<String, Object> waitImport(String importId);
}
