package io.pigmenttm1.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import io.pigmenttm1.core.Errors.ConfigError;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.*;

/**
 * Configuration déclarative des flux (JSON, clés en snake_case, champs inconnus refusés).
 * Aucun secret accepté : uniquement des NOMS de variables d'environnement.
 */
public final class Config {
    public Runtime runtime = new Runtime();
    public Pigment pigment = new Pigment();
    public Tm1 tm1 = new Tm1();
    public List<Flow> flows = new ArrayList<>();

    public static final class Runtime {
        public String environment = "dev";             // dev | test | prod
        public String workDir = "./runs";
        public String auditLog = "./audit/audit.jsonl";
        public String auditHmacKeyEnv = "CONNECTOR_AUDIT_HMAC_KEY";
        public String lockDir = "./locks";
    }

    public static final class Pigment {
        public String baseUrl = "https://pigment.app/api/v1";
        public String apiKeyEnv = "PIGMENT_API_KEY";
        public int timeoutS = 300;
        public String csvDelimiter = ";";
        public String decimal = ".";
        public double importPollIntervalS = 5;
        public int importTimeoutS = 1800;
        /** Libellés à confirmer sur https://pigment.app/api/swagger. */
        public List<String> importSuccessStates = List.of("completed", "succeeded", "success", "done");
        public List<String> importFailureStates = List.of("failed", "error", "cancelled", "canceled", "rejected");
    }

    public static final class Tm1 {
        /** Racine REST, ex. https://tm1.interne:8010/api/v1  ou  https://<region>.planninganalytics.saas.ibm.com/api/<tenant>/v0/tm1/<db>/api/v1 */
        public String baseUrl;
        /** basic | cam | apikey (PA SaaS : Basic apikey:<clé>) | bearer (jeton fourni par l'IAM) */
        public String auth = "basic";
        public String namespace;                        // pour auth = cam
        public String userEnv = "TM1_USER";
        public String passwordEnv = "TM1_PASSWORD";     // mot de passe, ou clé API si auth = apikey
        public String tokenEnv = "TM1_TOKEN";           // pour auth = bearer
        /** Truststore PKCS12 optionnel pour une AC interne (la vérification TLS n'est jamais désactivable). */
        public String trustStore;
        public String trustStorePasswordEnv = "TM1_TRUSTSTORE_PASSWORD";
        public boolean useSandbox = true;
        public int writeBatchSize = 5000;
        public int timeoutS = 600;
    }

    public static final class Flow {
        public String name;
        public String description = "";
        public String owner;
        public boolean enabled = true;
        public String direction;                        // pigment_to_tm1 | tm1_to_pigment
        public Source source = new Source();
        public Target target = new Target();
        public Mapping mapping;
        public Governance governance = new Governance();
        public Reconciliation reconciliation = new Reconciliation();
        public boolean aggregateDuplicates = false;

        public boolean pigmentToTm1() { return "pigment_to_tm1".equals(direction); }
    }

    public static final class Source {
        public String viewId;                           // pigment_to_tm1
        public String cube;                             // tm1_to_pigment
        public LinkedHashMap<String, List<String>> slice = new LinkedHashMap<>();
        public String mdx;
    }

    public static final class Target {
        public String cube;                             // pigment_to_tm1
        public LinkedHashMap<String, List<String>> slice = new LinkedHashMap<>();
        public String loadMode = "replace_slice";       // replace_slice | merge
        public String importConfigurationId;            // tm1_to_pigment
        public String verificationViewId;
    }

    public static final class Mapping {
        /** colonne Pigment -> dimension TM1 (sert dans les deux sens) */
        public LinkedHashMap<String, String> columns = new LinkedHashMap<>();
        public String valueColumn = "Value";
        public LinkedHashMap<String, String> staticMembers = new LinkedHashMap<>();
        /** dimension TM1 -> {valeur Pigment : élément TM1}, bijectif */
        public Map<String, Map<String, String>> memberMaps = new LinkedHashMap<>();
    }

    public static final class Governance {
        public Map<String, List<String>> protectedMembers = new LinkedHashMap<>();
        public Map<String, List<String>> allowedMembers = new LinkedHashMap<>();
        public int maxRows = 2_000_000;
        public int minRows = 1;
        public Double maxTotalChangePct = 25.0;         // null = pas de seuil
        public boolean requireApproval = true;
        public boolean allowNegative = true;
    }

    public static final class Reconciliation {
        public double absTolerance = 0.005;
        public double relTolerance = 1e-9;
        public List<String> controlDimensions = new ArrayList<>();
        public int maxDiffReportRows = 500;
    }

    // ------------------------------------------------------------------ chargement
    public record Loaded(Config config, String sha256) {}

    public static ObjectMapper mapper() {
        return new ObjectMapper()
                .setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true)
                .configure(DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES, true);
    }

    public static Loaded load(Path path) {
        if (!Files.isRegularFile(path)) throw new ConfigError("Fichier de configuration introuvable : " + path);
        try {
            byte[] raw = Files.readAllBytes(path);
            Config c = mapper().readValue(raw, Config.class);
            c.validate();
            return new Loaded(c, sha256(raw));
        } catch (ConfigError e) {
            throw e;
        } catch (IOException e) {
            throw new ConfigError("Configuration invalide (" + path + ") : " + e.getMessage(), e);
        }
    }

    public Flow flow(String name) {
        return flows.stream().filter(f -> f.name.equals(name)).findFirst()
                .orElseThrow(() -> new ConfigError("Flux inconnu : " + name + ". Déclarés : "
                        + flows.stream().map(f -> f.name).toList()));
    }

    // ------------------------------------------------------------------ validation
    public void validate() {
        List<String> e = new ArrayList<>();
        if (!Set.of("dev", "test", "prod").contains(runtime.environment)) e.add("runtime.environment : dev|test|prod");
        if (pigment.baseUrl == null || !pigment.baseUrl.startsWith("https://")) e.add("pigment.base_url doit être en HTTPS");
        if (tm1.baseUrl == null || !tm1.baseUrl.startsWith("https://")) e.add("tm1.base_url doit être en HTTPS");
        if (!Set.of("basic", "cam", "apikey", "bearer").contains(tm1.auth)) e.add("tm1.auth : basic|cam|apikey|bearer");
        if ("cam".equals(tm1.auth) && (tm1.namespace == null || tm1.namespace.isBlank())) e.add("tm1.namespace requis pour auth=cam");
        if (pigment.csvDelimiter == null || pigment.csvDelimiter.length() != 1) e.add("pigment.csv_delimiter : un caractère");
        Set<String> names = new HashSet<>();
        for (Flow f : flows) {
            String p = "flux " + f.name + " : ";
            if (f.name == null || !f.name.matches("[A-Za-z0-9_-]+")) e.add("nom de flux invalide : " + f.name);
            if (!names.add(f.name)) e.add("nom de flux en double : " + f.name);
            if (f.owner == null || f.owner.isBlank()) e.add(p + "owner obligatoire");
            if (!"pigment_to_tm1".equals(f.direction) && !"tm1_to_pigment".equals(f.direction))
                e.add(p + "direction : pigment_to_tm1|tm1_to_pigment");
            if (f.mapping == null || f.mapping.columns.isEmpty()) { e.add(p + "mapping.columns obligatoire"); continue; }
            if (new HashSet<>(f.mapping.columns.values()).size() != f.mapping.columns.size())
                e.add(p + "deux colonnes Pigment pointent vers la même dimension TM1");
            for (String d : f.mapping.staticMembers.keySet())
                if (f.mapping.columns.containsValue(d)) e.add(p + "dimension à la fois mappée et statique : " + d);
            f.mapping.memberMaps.forEach((dim, m) -> {
                if (new HashSet<>(m.values()).size() != m.size()) e.add(p + "member_maps[" + dim + "] non bijectif");
            });
            if (f.pigmentToTm1()) {
                if (blank(f.source.viewId)) e.add(p + "source.view_id obligatoire");
                if (blank(f.target.cube)) e.add(p + "target.cube obligatoire");
                if (!Set.of("replace_slice", "merge").contains(f.target.loadMode)) e.add(p + "target.load_mode : replace_slice|merge");
            } else if ("tm1_to_pigment".equals(f.direction)) {
                if (blank(f.source.cube)) e.add(p + "source.cube obligatoire");
                if (blank(f.target.importConfigurationId)) e.add(p + "target.import_configuration_id obligatoire");
            }
        }
        if (!e.isEmpty()) throw new ConfigError("Configuration invalide :\n - " + String.join("\n - ", e));
    }

    private static boolean blank(String s) { return s == null || s.isBlank(); }

    public static String sha256(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (Exception ex) { throw new IllegalStateException(ex); }
    }
}
