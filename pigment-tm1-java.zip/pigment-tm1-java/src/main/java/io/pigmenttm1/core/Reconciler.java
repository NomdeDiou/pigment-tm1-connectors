package io.pigmenttm1.core;

import io.pigmenttm1.config.Config;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** Réconciliation cellule à cellule, empreintes et totaux de contrôle. */
public final class Reconciler {
    private Reconciler() {}

    public enum Status { valeur_differente, absente_cible, inattendue_cible }

    public record Diff(List<String> key, Double expected, Double actual, Status status) {}

    public record Result(boolean ok, int expectedRows, int actualRows, int matched, int missing, int unexpected,
                         int mismatched, double expectedTotal, double actualTotal, String expectedFingerprint,
                         String actualFingerprint, List<Diff> diffs) {
        public Map<String, Object> summary() {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("ok", ok); m.put("expected_rows", expectedRows); m.put("actual_rows", actualRows);
            m.put("matched", matched); m.put("missing", missing); m.put("unexpected", unexpected);
            m.put("mismatched", mismatched); m.put("expected_total", round(expectedTotal));
            m.put("actual_total", round(actualTotal)); m.put("expected_fingerprint", expectedFingerprint);
            m.put("actual_fingerprint", actualFingerprint); m.put("diff_rows", diffs.size());
            return m;
        }

        public String diffsCsv(List<String> dims) {
            List<String> h = new ArrayList<>(dims);
            h.addAll(List.of("Value_expected", "Value_actual", "status"));
            List<List<String>> rows = new ArrayList<>();
            for (Diff d : diffs) {
                List<String> r = new ArrayList<>(d.key());
                r.add(d.expected() == null ? "" : Numbers.format(d.expected()));
                r.add(d.actual() == null ? "" : Numbers.format(d.actual()));
                r.add(d.status().name());
                rows.add(r);
            }
            return Csv.write(h, rows, ',');
        }
    }

    public static Result reconcile(Dataset expected, Dataset actual, Config.Reconciliation rc) {
        if (!expected.dims().equals(actual.dims())) actual = actual.project(expected.dims());
        Map<List<String>, Double> e = nonZero(expected, rc.absTolerance);  // TM1 ne stocke pas les zéros
        Map<List<String>, Double> a = nonZero(actual, rc.absTolerance);
        List<Diff> diffs = new ArrayList<>();
        int matched = 0, missing = 0, unexpected = 0, mism = 0;
        for (var en : e.entrySet()) {
            Double av = a.get(en.getKey());
            if (av == null) { missing++; addDiff(diffs, rc, new Diff(en.getKey(), en.getValue(), null, Status.absente_cible)); }
            else if (Math.abs(en.getValue() - av) > rc.absTolerance + rc.relTolerance * Math.abs(en.getValue())) {
                mism++; addDiff(diffs, rc, new Diff(en.getKey(), en.getValue(), av, Status.valeur_differente));
            } else matched++;
        }
        for (var en : a.entrySet()) {
            if (!e.containsKey(en.getKey())) {
                unexpected++; addDiff(diffs, rc, new Diff(en.getKey(), null, en.getValue(), Status.inattendue_cible));
            }
        }
        return new Result(missing == 0 && unexpected == 0 && mism == 0, e.size(), a.size(), matched, missing,
                unexpected, mism, sum(e), sum(a), fingerprint(e), fingerprint(a), List.copyOf(diffs));
    }

    private static void addDiff(List<Diff> d, Config.Reconciliation rc, Diff x) {
        if (d.size() < rc.maxDiffReportRows) d.add(x);
    }

    private static Map<List<String>, Double> nonZero(Dataset ds, double tol) {
        Map<List<String>, Double> m = new HashMap<>();
        ds.cells().forEach((k, v) -> { if (Math.abs(v) > tol) m.put(k, v); });
        return m;
    }

    private static double sum(Map<List<String>, Double> m) {
        return m.values().stream().mapToDouble(Double::doubleValue).sum();
    }

    public static String fingerprint(Dataset ds) { return fingerprint(nonZero(ds, 0)); }

    /** Empreinte SHA-256 indépendante de l'ordre des lignes et des zéros (6 décimales). */
    public static String fingerprint(Map<List<String>, Double> cells) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            TreeMap<String, String> sorted = new TreeMap<>();
            cells.forEach((k, v) -> {
                String val = String.format(Locale.ROOT, "%.6f", v);
                if (Double.parseDouble(val) != 0) sorted.put(String.join("\u001f", k), val);
            });
            sorted.forEach((k, v) -> md.update((k + "\u001e" + v + "\n").getBytes(StandardCharsets.UTF_8)));
            return HexFormat.of().formatHex(md.digest());
        } catch (Exception ex) { throw new IllegalStateException(ex); }
    }

    public static Map<String, Object> controlTotals(Dataset ds, List<String> dims) {
        Map<String, Object> res = new LinkedHashMap<>();
        res.put("rows", ds.size());
        res.put("total", round(ds.total()));
        res.put("abs_total", round(ds.absTotal()));
        for (String d : dims) {
            int i = ds.dims().indexOf(d);
            if (i < 0) continue;
            TreeMap<String, Double> by = new TreeMap<>();
            ds.cells().forEach((k, v) -> by.merge(k.get(i), v, Double::sum));
            Map<String, Double> r = new LinkedHashMap<>();
            by.forEach((k, v) -> r.put(k, round(v)));
            res.put("by_" + d, r);
        }
        return res;
    }

    public static double round(double v) {
        return new java.math.BigDecimal(Double.toString(v)).setScale(6, java.math.RoundingMode.HALF_UP).doubleValue();
    }
}
