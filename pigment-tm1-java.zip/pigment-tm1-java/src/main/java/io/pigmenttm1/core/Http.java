package io.pigmenttm1.core;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.InputStream;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.time.Duration;
import java.util.Optional;
import java.util.Set;

/** Client HTTP commun : TLS toujours vérifié, relance des seules lectures idempotentes. */
public final class Http {
    private static final Set<Integer> RETRYABLE = Set.of(429, 500, 502, 503, 504);
    private final HttpClient client;
    private final int maxRetries;

    public Http(Duration connectTimeout, String trustStorePath, String trustStorePassword, boolean cookies, int maxRetries) {
        HttpClient.Builder b = HttpClient.newBuilder()
                .connectTimeout(connectTimeout)
                .followRedirects(HttpClient.Redirect.NEVER);      // pas de redirection silencieuse des secrets
        if (cookies) b.cookieHandler(new CookieManager(null, CookiePolicy.ACCEPT_ORIGINAL_SERVER));
        if (trustStorePath != null && !trustStorePath.isBlank()) b.sslContext(sslContext(trustStorePath, trustStorePassword));
        this.client = b.build();
        this.maxRetries = maxRetries;
    }

    private static SSLContext sslContext(String path, String password) {
        try (InputStream in = Files.newInputStream(Path.of(path))) {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(in, password == null ? null : password.toCharArray());
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(ks);
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, tmf.getTrustManagers(), null);
            return ctx;
        } catch (Exception e) {
            throw new Errors.ConfigError("Truststore illisible (" + path + ") : " + e.getMessage());
        }
    }

    /** Requête unique, sans relance (pour toute écriture). */
    public HttpResponse<String> once(HttpRequest req) {
        try {
            return client.send(req, HttpResponse.BodyHandlers.ofString());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new Errors.LoadError("Interrompu : " + req.method() + " " + req.uri().getPath());
        } catch (Exception e) {
            throw new Errors.LoadError("Échec réseau " + req.method() + " " + req.uri().getHost() + " : " + e.getMessage(), e);
        }
    }

    /** Lecture idempotente : relance avec backoff exponentiel sur 429/5xx et erreurs réseau. */
    public HttpResponse<String> read(HttpRequest req) {
        long wait = 1000;
        for (int attempt = 0; ; attempt++) {
            HttpResponse<String> r;
            try {
                r = once(req);
            } catch (Errors.LoadError e) {
                if (attempt >= maxRetries) throw e;
                sleep(wait); wait *= 2;
                continue;
            }
            if (!RETRYABLE.contains(r.statusCode()) || attempt >= maxRetries) return r;
            Optional<String> ra = r.headers().firstValue("Retry-After");
            long delay = ra.map(v -> { try { return Long.parseLong(v.trim()) * 1000; } catch (NumberFormatException x) { return 0L; } })
                    .filter(v -> v > 0).orElse(wait);
            sleep(Math.min(delay, 60_000));
            wait *= 2;
        }
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    public static String excerpt(String body) {
        if (body == null) return "";
        String b = Secrets.redact(body.replaceAll("\\s+", " "));
        return b.length() > 300 ? b.substring(0, 300) + "…" : b;
    }
}
