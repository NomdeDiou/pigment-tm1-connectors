package io.pigmenttm1.core;

import io.pigmenttm1.config.Config;

import java.util.*;

/**
 * Transformation et validation. Le même mapping (colonne Pigment -> dimension TM1) sert
 * dans les deux sens, ce qui garantit la symétrie des flux.
 */
public final class Transform {
    private Transform() {}

    public record Rows(List<String> dims, List<Dataset.Row> rows) {}

    /** Ordre canonique : dimensions mappées puis dimensions statiques. */
    public static List<String> canonicalDims(Config.Mapping m) {
        List<String> d = new ArrayList<>(m.columns.values());
        d.addAll(m.staticMembers.keySet());
        return d;
    }

    public static Rows pigmentToRows(Csv.Table t, Config.Mapping m, String decimal, List<String> issues) {
        List<String> expected = new ArrayList<>(m.columns.keySet());
        expected.add(m.valueColumn);
        List<String> missing = expected.stream().filter(c -> t.col(c) < 0).toList();
        List<String> dims = canonicalDims(m);
        if (!missing.isEmpty()) {
            issues.add("Colonnes absentes de l'export Pigment : " + missing + " (reçues : " + t.header() + ")");
            return new Rows(dims, List.of());
        }
        int[] keyCols = m.columns.keySet().stream().mapToInt(t::col).toArray();
        List<String> mappedDims = new ArrayList<>(m.columns.values());
        int valCol = t.col(m.valueColumn);
        List<Dataset.Row> rows = new ArrayList<>();
        int bad = 0;
        List<String> badSamples = new ArrayList<>();
        for (List<String> r : t.rows()) {
            Double v;
            try {
                v = Numbers.parse(r.get(valCol), decimal);
            } catch (NumberFormatException e) {
                bad++;
                if (badSamples.size() < 5) badSamples.add(r.get(valCol));
                continue;
            }
            if (v == null) continue;                         // cellule vide = pas de donnée
            List<String> key = new ArrayList<>(dims.size());
            for (int i = 0; i < keyCols.length; i++) {
                String raw = r.get(keyCols[i]).strip();
                Map<String, String> mm = m.memberMaps.get(mappedDims.get(i));
                key.add(mm != null ? mm.getOrDefault(raw, raw) : raw);
            }
            key.addAll(m.staticMembers.values());
            rows.add(new Dataset.Row(key, v));
        }
        if (bad > 0) issues.add(bad + " valeur(s) non numérique(s), ex. " + badSamples);
        return new Rows(dims, rows);
    }

    public static String canonicalToPigmentCsv(Dataset ds, Config.Mapping m) {
        List<String> mappedDims = new ArrayList<>(m.columns.values());
        Dataset p = ds.project(mappedDims);
        List<String> header = new ArrayList<>(m.columns.keySet());
        header.add(m.valueColumn);
        List<List<String>> out = new ArrayList<>();
        p.cells().forEach((k, v) -> {
            List<String> r = new ArrayList<>(k.size() + 1);
            for (int i = 0; i < k.size(); i++) {
                Map<String, String> mm = m.memberMaps.get(mappedDims.get(i));
                String val = k.get(i);
                if (mm != null) {
                    for (var e : mm.entrySet()) if (e.getValue().equals(val)) { val = e.getKey(); break; }
                }
                r.add(val);
            }
            r.add(Numbers.format(v));
            out.add(r);
        });
        return Csv.write(header, out, ',');
    }

    /** TM1 ignore casse et espaces : ramène chaque valeur au nom exact d'un élément feuille. */
    public static void normalizeElements(List<Dataset.Row> rows, int dimIndex, String dim,
                                         Collection<String> leaves, List<String> issues) {
        Map<String, String> lookup = new HashMap<>();
        for (String e : leaves) lookup.put(tm1Key(e), e);
        TreeSet<String> unknown = new TreeSet<>();
        for (int i = 0; i < rows.size(); i++) {
            Dataset.Row r = rows.get(i);
            String found = lookup.get(tm1Key(r.key().get(dimIndex)));
            if (found == null) { unknown.add(r.key().get(dimIndex)); continue; }
            if (!found.equals(r.key().get(dimIndex))) {
                List<String> k = new ArrayList<>(r.key());
                k.set(dimIndex, found);
                rows.set(i, new Dataset.Row(k, r.value()));
            }
        }
        if (!unknown.isEmpty()) issues.add("Dimension " + dim + " : " + unknown.size()
                + " élément(s) inconnu(s) ou non-feuille(s), ex. " + unknown.stream().limit(10).toList());
    }

    public static String tm1Key(String s) { return s.toLowerCase(Locale.ROOT).replace(" ", ""); }

    public static Dataset validate(List<String> dims, List<Dataset.Row> rows, Config.Governance g,
                                   boolean aggregate, List<String> issues) {
        int n = rows.size();
        if (n < g.minRows) issues.add("Source avec " + n + " ligne(s) < min_rows=" + g.minRows + " (protection contre l'effacement)");
        if (n > g.maxRows) issues.add("Source avec " + n + " lignes > max_rows=" + g.maxRows);
        for (int i = 0; i < dims.size(); i++) {
            final int di = i;
            long blank = rows.stream().filter(r -> r.key().get(di) == null || r.key().get(di).isBlank()).count();
            if (blank > 0) issues.add(blank + " clé(s) vide(s) sur " + dims.get(i));
        }
        if (!g.allowNegative) {
            long neg = rows.stream().filter(r -> r.value() < 0).count();
            if (neg > 0) issues.add(neg + " valeur(s) négative(s) interdite(s)");
        }
        g.protectedMembers.forEach((dim, prot) -> {
            int i = dims.indexOf(dim);
            if (i < 0) return;
            Set<String> p = lower(prot);
            TreeSet<String> hit = new TreeSet<>();
            rows.forEach(r -> { if (p.contains(r.key().get(i).toLowerCase(Locale.ROOT))) hit.add(r.key().get(i)); });
            if (!hit.isEmpty()) issues.add("Membres protégés présents sur " + dim + " : " + hit);
        });
        g.allowedMembers.forEach((dim, allowed) -> {
            int i = dims.indexOf(dim);
            if (i < 0) return;
            Set<String> a = lower(allowed);
            TreeSet<String> bad = new TreeSet<>();
            rows.forEach(r -> { if (!a.contains(r.key().get(i).toLowerCase(Locale.ROOT))) bad.add(r.key().get(i)); });
            if (!bad.isEmpty()) issues.add("Membres hors liste blanche sur " + dim + " : " + bad.stream().limit(10).toList());
        });
        return Dataset.fromRows(dims, rows, aggregate, issues);
    }

    /** Lignes dont un membre sort du périmètre déclaré (slice). */
    public static void checkScope(List<String> dims, List<Dataset.Row> rows, Map<String, List<String>> slice,
                                  List<String> issues) {
        slice.forEach((dim, allowed) -> {
            int i = dims.indexOf(dim);
            if (i < 0) return;
            Set<String> a = lower(allowed);
            TreeSet<String> out = new TreeSet<>();
            long cnt = rows.stream().filter(r -> {
                boolean o = !a.contains(r.key().get(i).toLowerCase(Locale.ROOT));
                if (o) out.add(r.key().get(i));
                return o;
            }).count();
            if (cnt > 0) issues.add(cnt + " ligne(s) hors périmètre déclaré sur " + dim + " : " + out.stream().limit(10).toList());
        });
    }

    private static Set<String> lower(Collection<String> c) {
        Set<String> s = new HashSet<>();
        c.forEach(x -> s.add(x.toLowerCase(Locale.ROOT)));
        return s;
    }
}
