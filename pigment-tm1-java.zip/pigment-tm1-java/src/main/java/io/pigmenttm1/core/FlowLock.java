package io.pigmenttm1.core;

import java.io.IOException;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

/**
 * Verrou exclusif par flux, porté par le système d'exploitation : il est libéré
 * automatiquement si le processus meurt (pas de verrou orphelin sur un hôte).
 * Pour plusieurs hôtes, placez lock_dir sur un stockage partagé qui supporte les verrous.
 */
public final class FlowLock implements AutoCloseable {
    private final FileChannel channel;
    private final FileLock lock;

    public FlowLock(Path dir, String flow, String runId) {
        Path p = dir.resolve(flow + ".lock");
        try {
            Files.createDirectories(dir);
            channel = FileChannel.open(p, StandardOpenOption.CREATE, StandardOpenOption.READ, StandardOpenOption.WRITE);
            FileLock l;
            try {
                l = channel.tryLock();
            } catch (OverlappingFileLockException e) {
                l = null;
            }
            if (l == null) {
                String holder = Files.readString(p, StandardCharsets.UTF_8);
                channel.close();
                throw new Errors.LockError("Flux " + flow + " déjà en cours d'exécution : " + holder);
            }
            lock = l;
            String info = "{\"run_id\":\"" + runId + "\",\"pid\":" + ProcessHandle.current().pid()
                    + ",\"host\":\"" + InetAddress.getLocalHost().getHostName() + "\",\"since\":\"" + Instant.now() + "\"}";
            channel.truncate(0);
            channel.write(ByteBuffer.wrap(info.getBytes(StandardCharsets.UTF_8)), 0);
            channel.force(true);
        } catch (IOException e) {
            throw new Errors.LockError("Verrou impossible : " + e.getMessage());
        }
    }

    @Override
    public void close() {
        try {
            channel.truncate(0);
            lock.release();
            channel.close();
        } catch (IOException ignored) {
            // le système libère le verrou à la fermeture du processus
        }
    }
}
