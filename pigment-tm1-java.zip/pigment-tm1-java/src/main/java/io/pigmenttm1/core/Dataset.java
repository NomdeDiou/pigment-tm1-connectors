package io.pigmenttm1.core;

import java.util.*;

/**
 * Format pivot : une coordonnée (un élément par dimension TM1, dans l'ordre de {@link #dims()})
 * associée à une valeur numérique. Clés uniques par construction.
 */
public final class Dataset {
    public record Row(List<String> key, double value) {}

    private final List<String> dims;
    private final LinkedHashMap<List<String>, Double> cells = new LinkedHashMap<>();

    public Dataset(List<String> dims) { this.dims = List.copyOf(dims); }

    public List<String> dims() { return dims; }
    public Map<List<String>, Double> cells() { return Collections.unmodifiableMap(cells); }
    public int size() { return cells.size(); }
    public boolean isEmpty() { return cells.isEmpty(); }

    public void put(List<String> key, double value) {
        if (key.size() != dims.size()) throw new IllegalArgumentException("clé de taille " + key.size() + " ≠ " + dims.size());
        cells.put(List.copyOf(key), value);
    }

    public double total() { return cells.values().stream().mapToDouble(Double::doubleValue).sum(); }
    public double absTotal() { return cells.values().stream().mapToDouble(Math::abs).sum(); }

    /** Réordonne / restreint les colonnes (toutes les dimensions demandées doivent exister). */
    public Dataset project(List<String> newDims) {
        int[] idx = newDims.stream().mapToInt(d -> {
            int i = dims.indexOf(d);
            if (i < 0) throw new IllegalArgumentException("dimension absente : " + d);
            return i;
        }).toArray();
        Dataset out = new Dataset(newDims);
        cells.forEach((k, v) -> {
            List<String> nk = new ArrayList<>(idx.length);
            for (int i : idx) nk.add(k.get(i));
            out.cells.merge(List.copyOf(nk), v, Double::sum);
        });
        return out;
    }

    /** Construit le jeu en détectant les doublons de clé (erreur, ou somme si aggregate). */
    public static Dataset fromRows(List<String> dims, List<Row> rows, boolean aggregate, List<String> issues) {
        Dataset ds = new Dataset(dims);
        int dup = 0;
        for (Row r : rows) {
            List<String> k = List.copyOf(r.key());
            if (ds.cells.containsKey(k)) {
                dup++;
                if (aggregate) ds.cells.merge(k, r.value(), Double::sum);
            } else ds.cells.put(k, r.value());
        }
        if (dup > 0 && !aggregate) issues.add(dup + " ligne(s) en doublon de clé (aggregate_duplicates=false)");
        return ds;
    }

    public String toCsv() {
        List<String> header = new ArrayList<>(dims);
        header.add("Value");
        List<List<String>> rows = new ArrayList<>();
        cells.forEach((k, v) -> {
            List<String> r = new ArrayList<>(k);
            r.add(Numbers.format(v));
            rows.add(r);
        });
        return Csv.write(header, rows, ',');
    }
}
