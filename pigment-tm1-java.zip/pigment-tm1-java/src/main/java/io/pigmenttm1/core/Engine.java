package io.pigmenttm1.core;

import io.pigmenttm1.audit.AuditLog;
import io.pigmenttm1.config.Config;
import io.pigmenttm1.core.Errors.*;
import io.pigmenttm1.pigment.PigmentApi;
import io.pigmenttm1.pigment.PigmentClient;
import io.pigmenttm1.tm1.Tm1Api;
import io.pigmenttm1.tm1.Tm1RestClient;

import java.nio.file.Path;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.logging.Logger;

/**
 * Orchestration d'un flux : extraire -> valider -> contrôler -> charger -> relire -> réconcilier.
 *
 * Garanties :
 *  - aucune écriture tant que validation et gouvernance ne sont pas passées ;
 *  - l'état cible antérieur est toujours capturé avant écriture (preuve + restauration) ;
 *  - succès uniquement si la relecture de la cible réconcilie à 100 % (à la tolérance près),
 *    sinon restauration automatique vérifiée et code d'erreur ;
 *  - chaque étape est tracée dans l'audit chaîné, avec les empreintes des données.
 */
public final class Engine {
    private static final Logger LOG = Logger.getLogger(Engine.class.getName());

    public record RunOptions(boolean dryRun, String approvedBy, String ticket, String operator) {}

    private final Config conf;
    private final String confHash;
    private final PigmentApi pigment;
    private final Supplier<Tm1Api> tm1Factory;
    private final AuditLog audit;

    public Engine(Config conf, String confHash, PigmentApi pigment, Supplier<Tm1Api> tm1Factory) {
        this.conf = conf;
        this.confHash = confHash;
        this.pigment = pigment;
        this.tm1Factory = tm1Factory;
        String key = null;
        if (conf.runtime.auditHmacKeyEnv != null) {
            try {
                key = Secrets.get(conf.runtime.auditHmacKeyEnv);
            } catch (SecretError e) {
                if ("prod".equals(conf.runtime.environment)) throw e;
                LOG.warning("Audit non signé (pas de clé HMAC) : acceptable hors production uniquement");
            }
        }
        this.audit = new AuditLog(Path.of(conf.runtime.auditLog), key);
    }

    public static Engine production(Config.Loaded l) {
        return new Engine(l.config(), l.sha256(), new PigmentClient(l.config().pigment),
                () -> new Tm1RestClient(l.config().tm1));
    }

    // ================================================================== entrée
    public Map<String, Object> run(String flowName, RunOptions o) {
        Config.Flow flow = conf.flow(flowName);
        if (!flow.enabled) throw new GovernanceError("Flux " + flow.name + " désactivé dans la configuration");
        String runId = ZonedDateTime.now(ZoneOffset.UTC).format(DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'"))
                + "-" + UUID.randomUUID().toString().substring(0, 8);
        String operator = o.operator() != null ? o.operator() : System.getProperty("user.name");
        Evidence ev = new Evidence(Path.of(conf.runtime.workDir, flow.name, runId));
        Map<String, Object> base = new LinkedHashMap<>();
        base.put("run_id", runId); base.put("flow", flow.name); base.put("direction", flow.direction);
        base.put("config_sha256", confHash); base.put("operator", operator);
        base.put("environment", conf.runtime.environment); base.put("dry_run", o.dryRun());
        Map<String, Object> report = new LinkedHashMap<>(base);
        report.put("status", "started");

        try (FlowLock ignored = new FlowLock(Path.of(conf.runtime.lockDir), flow.name, runId)) {
            Map<String, Object> start = new LinkedHashMap<>(base);
            start.put("approved_by", o.approvedBy()); start.put("ticket", o.ticket());
            audit.append("run_started", start);
            try {
                report.putAll(flow.pigmentToTm1() ? pigmentToTm1(flow, o, ev, operator, runId) : tm1ToPigment(flow, o, ev, operator));
                report.put("status", o.dryRun() ? "dry_run_ok" : "success");
                audit.append("run_succeeded", with(base, "result", slim(report)));
                return report;
            } catch (ConnectorException e) {
                report.put("status", "failed");
                report.put("error_type", e.getClass().getSimpleName());
                report.put("error", Secrets.redact(e.getMessage()));
                report.put("issues", e.issues());
                Map<String, Object> f = with(base, "error_type", e.getClass().getSimpleName());
                f.put("error", truncate(Secrets.redact(e.getMessage())));
                f.put("result", slim(report));
                audit.append("run_failed", f);
                throw e;
            } catch (RuntimeException e) {
                report.put("status", "failed");
                report.put("error_type", e.getClass().getSimpleName());
                report.put("error", Secrets.redact(String.valueOf(e.getMessage())));
                Map<String, Object> f = with(base, "error_type", e.getClass().getSimpleName());
                f.put("error", truncate(Secrets.redact(String.valueOf(e.getMessage()))));
                audit.append("run_failed", f);
                throw new ConnectorException("Erreur inattendue : " + Secrets.redact(String.valueOf(e.getMessage())), 1, e);
            } finally {
                ev.json("report.json", report);
            }
        }
    }

    // ================================================================ gouvernance
    private void approve(Config.Flow flow, RunOptions o, String operator) {
        if (o.dryRun() || !flow.governance.requireApproval) return;
        if (o.approvedBy() == null || o.approvedBy().isBlank())
            throw new GovernanceError("Approbation requise : --approved-by <nom> (et --ticket en production)");
        if ("prod".equals(conf.runtime.environment)) {
            if (o.ticket() == null || o.ticket().isBlank())
                throw new GovernanceError("Référence de ticket/changement obligatoire en production (--ticket)");
            if (o.approvedBy().strip().equalsIgnoreCase(operator.strip()))
                throw new GovernanceError("Principe des quatre yeux : l'approbateur doit différer de l'opérateur");
        }
    }

    private static Map<String, Object> changeGuard(Config.Flow flow, Dataset before, Dataset after) {
        double b = before.total(), a = after.total();
        Double pct = b == 0 ? null : Math.abs(a - b) / Math.abs(b) * 100;
        Map<String, Object> g = new LinkedHashMap<>();
        g.put("total_before", Reconciler.round(b));
        g.put("total_after_expected", Reconciler.round(a));
        g.put("change_pct", pct == null ? null : Reconciler.round(pct));
        Double lim = flow.governance.maxTotalChangePct;
        g.put("blocked", lim != null && pct != null && pct > lim);
        return g;
    }

    // ========================================================= Pigment -> TM1
    private Map<String, Object> pigmentToTm1(Config.Flow flow, RunOptions o, Evidence ev, String operator, String runId) {
        Config.Mapping m = flow.mapping;
        String cube = flow.target.cube;
        Map<String, Object> out = new LinkedHashMap<>();
        String raw = pigment.exportViewCsv(flow.source.viewId);
        out.put("source_sha256", ev.text("source_pigment.csv", raw));
        Csv.Table table = Csv.parse(raw, conf.pigment.csvDelimiter.charAt(0));
        out.put("source_rows_raw", table.rows().size());
        List<String> issues = new ArrayList<>();
        Transform.Rows rows = Transform.pigmentToRows(table, m, conf.pigment.decimal, issues);

        try (Tm1Api tm1 = tm1Factory.get()) {
            List<String> dims = tm1.cubeDimensions(cube);
            checkCoverage(dims, m, cube);
            List<Dataset.Row> list = new ArrayList<>(rows.rows());
            List<String> cdims = rows.dims();
            Map<String, List<String>> scope = new LinkedHashMap<>();
            Dataset src = null;
            if (issues.isEmpty()) {
                Map<String, List<String>> leaves = new HashMap<>();
                for (String d : dims) leaves.put(d, tm1.leafElements(d));
                for (int i = 0; i < m.columns.size(); i++) {
                    String d = cdims.get(i);
                    Transform.normalizeElements(list, i, d, leaves.get(d), issues);
                }
                scope = normalizeScope(flow.target.slice, m.staticMembers, leaves, issues);
                Transform.checkScope(cdims, list, scope, issues);
                src = Transform.validate(cdims, list, flow.governance, flow.aggregateDuplicates, issues);
            }
            if (!issues.isEmpty()) {
                ev.json("validation_issues.json", issues);
                throw new ValidationError(issues.size() + " anomalie(s) bloquante(s), aucune écriture", issues);
            }
            Dataset canon = src.project(dims);
            out.put("canonical_sha256", ev.text("source_canonical.csv", canon.toCsv()));
            out.put("fingerprint_source", Reconciler.fingerprint(canon));
            out.put("control_source", Reconciler.controlTotals(canon, flow.reconciliation.controlDimensions));

            Dataset before = tm1.read(cube, scope, null, null);
            out.put("before_sha256", ev.text("target_before.csv", before.toCsv()));
            Dataset expected = "replace_slice".equals(flow.target.loadMode) ? canon : merge(before, canon);

            Reconciler.Result preview = Reconciler.reconcile(expected, before, flow.reconciliation);
            ev.text("preview_changes.csv", preview.diffsCsv(dims));
            Map<String, Object> pv = new LinkedHashMap<>();
            pv.put("cells_new", preview.missing()); pv.put("cells_cleared", preview.unexpected());
            pv.put("cells_changed", preview.mismatched()); pv.put("cells_unchanged", preview.matched());
            out.put("preview", pv);
            Map<String, Object> guard = changeGuard(flow, before, expected);
            out.put("change_guard", guard);
            if (o.dryRun()) return out;
            if (Boolean.TRUE.equals(guard.get("blocked")))
                throw new GovernanceError("Variation du total " + guard.get("change_pct") + " % > seuil "
                        + flow.governance.maxTotalChangePct + " % : chargement bloqué");
            approve(flow, o, operator);
            Map<String, Object> auth = new LinkedHashMap<>();
            auth.put("run_id", runId); auth.put("flow", flow.name); auth.put("approved_by", o.approvedBy());
            auth.put("ticket", o.ticket()); auth.put("preview", pv); auth.put("change_guard", guard);
            audit.append("load_authorized", auth);

            boolean useSb = conf.tm1.useSandbox && tm1.sandboxesEnabled();
            out.put("write_mode", useSb ? "sandbox" : "snapshot");
            Load load = new Load(tm1, flow, scope, canon, expected, before, ev);
            Reconciler.Result r = useSb ? load.viaSandbox("connector_" + runId) : load.viaSnapshot();
            out.put("reconciliation", r.summary());
            return out;
        }
    }

    /** Périmètre exact (noms TM1) : éléments du slice + éléments statiques, tous feuilles. */
    private static Map<String, List<String>> normalizeScope(Map<String, List<String>> slice, Map<String, String> statics,
                                                            Map<String, List<String>> leaves, List<String> issues) {
        Map<String, List<String>> scope = new LinkedHashMap<>();
        Map<String, List<String>> wanted = new LinkedHashMap<>(slice);
        statics.forEach((d, e) -> wanted.put(d, List.of(e)));
        wanted.forEach((d, elems) -> {
            List<String> lv = leaves.get(d);
            if (lv == null) { issues.add("Périmètre : dimension inconnue " + d); return; }
            Map<String, String> lk = new HashMap<>();
            lv.forEach(e -> lk.put(Transform.tm1Key(e), e));
            List<String> exact = new ArrayList<>();
            for (String e : elems) {
                String f = lk.get(Transform.tm1Key(e));
                if (f == null) issues.add("Périmètre : " + d + "=" + e + " inexistant ou non-feuille");
                else exact.add(f);
            }
            scope.put(d, exact);
        });
        return scope;
    }

    /** Écriture atomique dans TM1 et restauration. */
    private final class Load {
        final Tm1Api tm1; final Config.Flow flow; final Map<String, List<String>> scope;
        final Dataset canon, expected, before; final Evidence ev; final String cube;

        Load(Tm1Api tm1, Config.Flow flow, Map<String, List<String>> scope, Dataset canon, Dataset expected,
             Dataset before, Evidence ev) {
            this.tm1 = tm1; this.flow = flow; this.scope = scope; this.canon = canon;
            this.expected = expected; this.before = before; this.ev = ev; this.cube = flow.target.cube;
        }

        void write(String sandbox) {
            if ("replace_slice".equals(flow.target.loadMode)) tm1.clear(cube, scope, sandbox);
            if (!canon.isEmpty()) tm1.write(cube, canon, sandbox);
        }

        Reconciler.Result verify(Dataset exp, String sandbox) {
            return Reconciler.reconcile(exp, tm1.read(cube, scope, sandbox, null), flow.reconciliation);
        }

        /** Sandbox : rien n'atteint la base tant que la relecture en sandbox n'est pas parfaite. */
        Reconciler.Result viaSandbox(String name) {
            tm1.createSandbox(name);
            try {
                write(name);
                Reconciler.Result rs = verify(expected, name);
                if (!rs.ok()) {
                    ev.text("diffs_sandbox.csv", rs.diffsCsv(expected.dims()));
                    throw new ReconciliationError("Écart en sandbox " + rs.summary() + " : rien n'a été publié");
                }
                tm1.publish(name);
            } finally {
                try { tm1.deleteSandbox(name); }
                catch (RuntimeException e) { LOG.severe("Sandbox " + name + " non supprimée : nettoyage manuel requis"); }
            }
            Reconciler.Result rb = verify(expected, null);
            if (!rb.ok()) {
                ev.text("diffs_after_publish.csv", rb.diffsCsv(expected.dims()));
                restore("écart après publication " + rb.summary(), ReconciliationError::new);
            }
            return rb;
        }

        /** Snapshot : état antérieur capturé, restauré et vérifié en cas d'échec ou d'écart. */
        Reconciler.Result viaSnapshot() {
            try {
                write(null);
            } catch (RuntimeException e) {
                restore("échec d'écriture : " + e.getMessage(), LoadError::new);
            }
            Reconciler.Result r = verify(expected, null);
            if (!r.ok()) {
                ev.text("diffs.csv", r.diffsCsv(expected.dims()));
                restore("écart de réconciliation " + r.summary(), ReconciliationError::new);
            }
            return r;
        }

        void restore(String reason, Function<String, ConnectorException> err) {
            LOG.severe("Restauration de l'état antérieur : " + Secrets.redact(reason));
            Reconciler.Result chk;
            try {
                tm1.clear(cube, scope, null);
                if (!before.isEmpty()) tm1.write(cube, before, null);
                chk = verify(before, null);
            } catch (RuntimeException e) {
                throw new RollbackError(reason + " ; RESTAURATION ÉCHOUÉE (" + e.getMessage() + "). État antérieur : "
                        + ev.root().resolve("target_before.csv"), e);
            }
            if (!chk.ok()) {
                ev.text("diffs_restore.csv", chk.diffsCsv(before.dims()));
                throw new RollbackError(reason + " ; restauration incomplète. Preuves : " + ev.root());
            }
            throw err.apply(reason + " ; état antérieur restauré et vérifié");
        }
    }

    // ========================================================= TM1 -> Pigment
    private Map<String, Object> tm1ToPigment(Config.Flow flow, RunOptions o, Evidence ev, String operator) {
        Config.Mapping m = flow.mapping;
        List<String> keys = new ArrayList<>(m.columns.values());
        Map<String, Object> out = new LinkedHashMap<>();
        Dataset raw;
        try (Tm1Api tm1 = tm1Factory.get()) {
            List<String> dims = tm1.cubeDimensions(flow.source.cube);
            checkCoverage(dims, m, flow.source.cube);
            Map<String, List<String>> scope = new LinkedHashMap<>(flow.source.slice);
            m.staticMembers.forEach((d, e) -> scope.put(d, List.of(e)));
            raw = tm1.read(flow.source.cube, scope, null, flow.source.mdx);
        }
        out.put("source_sha256", ev.text("source_tm1.csv", raw.toCsv()));
        List<String> issues = new ArrayList<>();
        m.staticMembers.forEach((d, e) -> {
            int i = raw.dims().indexOf(d);
            TreeSet<String> bad = new TreeSet<>();
            raw.cells().keySet().forEach(k -> { if (!k.get(i).equalsIgnoreCase(e)) bad.add(k.get(i)); });
            if (!bad.isEmpty()) issues.add("Lecture TM1 hors élément statique " + d + "=" + e + " : " + bad.stream().limit(5).toList());
        });
        List<Dataset.Row> rows = new ArrayList<>();
        raw.project(keys).cells().forEach((k, v) -> rows.add(new Dataset.Row(k, v)));
        Dataset canon = Transform.validate(keys, rows, flow.governance, flow.aggregateDuplicates, issues);
        if (!issues.isEmpty()) {
            ev.json("validation_issues.json", issues);
            throw new ValidationError(issues.size() + " anomalie(s) bloquante(s), aucun import", issues);
        }
        out.put("fingerprint_source", Reconciler.fingerprint(canon));
        out.put("control_source", Reconciler.controlTotals(canon, flow.reconciliation.controlDimensions));
        String payload = Transform.canonicalToPigmentCsv(canon, m);
        out.put("payload_sha256", ev.text("payload_pigment.csv", payload));

        Dataset before = null;
        String vv = flow.target.verificationViewId;
        if (vv != null) {
            before = pigmentView(vv, m, keys);
            ev.text("target_before.csv", before.toCsv());
            Map<String, Object> guard = changeGuard(flow, before, canon);
            out.put("change_guard", guard);
            Reconciler.Result pr = Reconciler.reconcile(canon, before, flow.reconciliation);
            Map<String, Object> pv = new LinkedHashMap<>();
            pv.put("cells_new", pr.missing()); pv.put("cells_absent_from_source", pr.unexpected());
            pv.put("cells_changed", pr.mismatched()); pv.put("cells_unchanged", pr.matched());
            out.put("preview", pv);
            if (Boolean.TRUE.equals(guard.get("blocked")) && !o.dryRun())
                throw new GovernanceError("Variation du total " + guard.get("change_pct") + " % > seuil : import bloqué");
        } else {
            out.put("warning", "Pas de verification_view_id : import non relu (non recommandé)");
        }
        if (o.dryRun()) return out;
        approve(flow, o, operator);
        Map<String, Object> auth = new LinkedHashMap<>();
        auth.put("flow", flow.name); auth.put("approved_by", o.approvedBy()); auth.put("ticket", o.ticket());
        auth.put("payload_sha256", out.get("payload_sha256")); auth.put("preview", out.get("preview"));
        audit.append("load_authorized", auth);

        String importId = pigment.pushCsv(flow.target.importConfigurationId, payload);
        out.put("import_id", importId);
        audit.append("pigment_import_submitted", Map.of("flow", flow.name, "import_id", importId));
        ev.json("pigment_import_status.json", pigment.waitImport(importId));

        if (vv != null) {
            Reconciler.Result r = Reconciler.reconcile(canon, pigmentView(vv, m, keys), flow.reconciliation);
            out.put("reconciliation", r.summary());
            if (!r.ok()) {
                ev.text("diffs.csv", r.diffsCsv(keys));
                compensatePigment(flow, before, m, keys, ev);
                throw new ReconciliationError("Écart après import Pigment " + r.summary() + " ; état antérieur ré-importé et vérifié");
            }
        }
        return out;
    }

    private Dataset pigmentView(String viewId, Config.Mapping m, List<String> keys) {
        List<String> issues = new ArrayList<>();
        Csv.Table t = Csv.parse(pigment.exportViewCsv(viewId), conf.pigment.csvDelimiter.charAt(0));
        Transform.Rows rows = Transform.pigmentToRows(t, m, conf.pigment.decimal, issues);
        Dataset ds = Dataset.fromRows(rows.dims(), rows.rows(), true, issues);
        if (!issues.isEmpty()) throw new LoadError("Vue de vérification illisible : " + issues);
        return ds.project(keys);
    }

    private void compensatePigment(Config.Flow flow, Dataset before, Config.Mapping m, List<String> keys, Evidence ev) {
        if (before == null) return;
        String payload = Transform.canonicalToPigmentCsv(before, m);
        ev.text("compensation_payload.csv", payload);
        Reconciler.Result chk;
        try {
            String id = pigment.pushCsv(flow.target.importConfigurationId, payload);
            pigment.waitImport(id);
            chk = Reconciler.reconcile(before, pigmentView(flow.target.verificationViewId, m, keys), flow.reconciliation);
        } catch (RuntimeException e) {
            throw new RollbackError("Compensation Pigment échouée : " + e.getMessage() + ". État antérieur : "
                    + ev.root().resolve("target_before.csv"), e);
        }
        if (!chk.ok()) throw new RollbackError("Compensation Pigment incomplète. Preuves : " + ev.root());
    }

    // ------------------------------------------------------------------ utilitaires
    private static void checkCoverage(List<String> dims, Config.Mapping m, String cube) {
        Set<String> covered = new HashSet<>(m.columns.values());
        covered.addAll(m.staticMembers.keySet());
        Set<String> missing = new TreeSet<>(dims); missing.removeAll(covered);
        Set<String> extra = new TreeSet<>(covered); extra.removeAll(dims);
        if (!missing.isEmpty() || !extra.isEmpty())
            throw new ConfigError("Mapping incohérent avec le cube " + cube + " : dimensions non couvertes " + missing
                    + ", inconnues " + extra + ". Chaque dimension doit être mappée ou statique.");
    }

    private static Dataset merge(Dataset before, Dataset fresh) {
        Dataset out = new Dataset(fresh.dims());
        before.project(fresh.dims()).cells().forEach(out::put);
        fresh.cells().forEach(out::put);
        return out;
    }

    private static Map<String, Object> with(Map<String, Object> base, String k, Object v) {
        Map<String, Object> m = new LinkedHashMap<>(base);
        m.put(k, v);
        return m;
    }

    private static Map<String, Object> slim(Map<String, Object> report) {
        Map<String, Object> m = new LinkedHashMap<>(report);
        m.remove("control_source");
        return m;
    }

    private static String truncate(String s) { return s == null ? null : s.length() > 2000 ? s.substring(0, 2000) : s; }
}
