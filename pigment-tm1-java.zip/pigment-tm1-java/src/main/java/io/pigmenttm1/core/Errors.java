package io.pigmenttm1.core;

import java.util.List;

/** Exceptions typées : chaque échec a une cause identifiable et un code de sortie stable. */
public final class Errors {
    private Errors() {}

    public static class ConnectorException extends RuntimeException {
        private final int exitCode;
        public ConnectorException(String msg, int exitCode) { super(msg); this.exitCode = exitCode; }
        public ConnectorException(String msg, int exitCode, Throwable cause) { super(msg, cause); this.exitCode = exitCode; }
        public ConnectorException(String msg) { this(msg, 1); }
        public int exitCode() { return exitCode; }
        public List<String> issues() { return List.of(); }
    }

    public static class ConfigError extends ConnectorException {
        public ConfigError(String m) { super(m, 2); }
        public ConfigError(String m, Throwable c) { super(m, 2, c); }
    }

    public static class SecretError extends ConnectorException {
        public SecretError(String m) { super(m, 3); }
    }

    /** Les données sources ne respectent pas le contrat : rien n'a été écrit. */
    public static class ValidationError extends ConnectorException {
        private final List<String> issues;
        public ValidationError(String m, List<String> issues) { super(m, 4); this.issues = List.copyOf(issues); }
        @Override public List<String> issues() { return issues; }
    }

    /** Règle de gouvernance bloquante : rien n'a été écrit. */
    public static class GovernanceError extends ConnectorException {
        public GovernanceError(String m) { super(m, 5); }
    }

    public static class LoadError extends ConnectorException {
        public LoadError(String m) { super(m, 6); }
        public LoadError(String m, Throwable c) { super(m, 6, c); }
    }

    /** La cible relue ne correspond pas à la source (état antérieur restauré). */
    public static class ReconciliationError extends ConnectorException {
        public ReconciliationError(String m) { super(m, 7); }
    }

    public static class LockError extends ConnectorException {
        public LockError(String m) { super(m, 8); }
    }

    /** Le plus grave : écriture en échec ET restauration en échec. Intervention manuelle. */
    public static class RollbackError extends ConnectorException {
        public RollbackError(String m, Throwable c) { super(m, 9, c); }
        public RollbackError(String m) { super(m, 9); }
    }
}
