package io.pigmenttm1.core;

import java.math.BigDecimal;

public final class Numbers {
    private Numbers() {}

    /** Représentation exacte et sans notation scientifique, identique d'une exécution à l'autre. */
    public static String format(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return Long.toString((long) v);
        return new BigDecimal(Double.toString(v)).stripTrailingZeros().toPlainString();
    }

    /**
     * Analyse un nombre exporté (espaces, espaces insécables, séparateur décimal configurable).
     * @return null si cellule vide ; lève NumberFormatException si non numérique.
     */
    public static Double parse(String raw, String decimal) {
        if (raw == null) return null;
        String s = raw.strip().replace(" ", "").replace(" ", "").replace(" ", "");
        if (s.isEmpty() || s.equalsIgnoreCase("nan") || s.equalsIgnoreCase("null") || s.equalsIgnoreCase("none")) return null;
        if (!".".equals(decimal)) s = s.replace(".", "").replace(decimal, ".");
        double d = Double.parseDouble(s);
        if (Double.isNaN(d) || Double.isInfinite(d)) throw new NumberFormatException("valeur non finie : " + raw);
        return d;
    }
}
