package io.pigmenttm1.core;

import java.util.ArrayList;
import java.util.List;

/** Lecture / écriture CSV RFC 4180 (guillemets, séparateurs et retours à la ligne échappés). */
public final class Csv {
    private Csv() {}

    public record Table(List<String> header, List<List<String>> rows) {
        public int col(String name) { return header.indexOf(name); }
    }

    public static Table parse(String text, char delimiter) {
        List<List<String>> records = new ArrayList<>();
        List<String> current = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean inQuotes = false, fieldStarted = false;
        int i = 0, n = text.length();
        if (n > 0 && text.charAt(0) == '﻿') i = 1; // BOM
        for (; i < n; i++) {
            char c = text.charAt(i);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < n && text.charAt(i + 1) == '"') { field.append('"'); i++; }
                    else inQuotes = false;
                } else field.append(c);
            } else if (c == '"' && !fieldStarted) {
                inQuotes = true; fieldStarted = true;
            } else if (c == delimiter) {
                current.add(field.toString()); field.setLength(0); fieldStarted = false;
            } else if (c == '\n' || c == '\r') {
                if (c == '\r' && i + 1 < n && text.charAt(i + 1) == '\n') i++;
                current.add(field.toString()); field.setLength(0); fieldStarted = false;
                if (!(current.size() == 1 && current.get(0).isEmpty())) records.add(current);
                current = new ArrayList<>();
            } else {
                field.append(c); fieldStarted = true;
            }
        }
        if (inQuotes) throw new IllegalArgumentException("CSV invalide : guillemet non fermé");
        if (fieldStarted || field.length() > 0 || !current.isEmpty()) {
            current.add(field.toString());
            records.add(current);
        }
        if (records.isEmpty()) return new Table(List.of(), List.of());
        List<String> header = records.get(0).stream().map(String::strip).toList();
        List<List<String>> rows = records.subList(1, records.size());
        for (int r = 0; r < rows.size(); r++) {
            if (rows.get(r).size() != header.size()) {
                throw new IllegalArgumentException("CSV invalide : ligne " + (r + 2) + " a " + rows.get(r).size()
                        + " champs, en-tête " + header.size());
            }
        }
        return new Table(header, List.copyOf(rows));
    }

    public static String write(List<String> header, List<List<String>> rows, char delimiter) {
        StringBuilder sb = new StringBuilder();
        line(sb, header, delimiter);
        for (List<String> r : rows) line(sb, r, delimiter);
        return sb.toString();
    }

    private static void line(StringBuilder sb, List<String> fields, char d) {
        for (int i = 0; i < fields.size(); i++) {
            if (i > 0) sb.append(d);
            String f = fields.get(i) == null ? "" : fields.get(i);
            if (f.indexOf(d) >= 0 || f.indexOf('"') >= 0 || f.indexOf('\n') >= 0 || f.indexOf('\r') >= 0) {
                sb.append('"').append(f.replace("\"", "\"\"")).append('"');
            } else sb.append(f);
        }
        sb.append('\n');
    }
}
