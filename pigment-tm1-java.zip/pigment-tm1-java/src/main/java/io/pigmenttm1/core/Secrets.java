package io.pigmenttm1.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

/**
 * Résolution des secrets et masquage.
 * Sources, dans l'ordre : VAR_FILE (fichier monté : secret K8s/Docker, Vault Agent),
 * puis VAR (variable d'environnement injectée par le coffre). Jamais dans la config.
 */
public final class Secrets {
    private static final Set<String> REGISTERED = ConcurrentHashMap.newKeySet();
    private static Function<String, String> env = System::getenv;

    private Secrets() {}

    /** Pour les tests uniquement. */
    public static void setEnvironment(Map<String, String> vars) { env = vars::get; }
    public static void resetEnvironment() { env = System::getenv; }

    public static String get(String name) {
        String value;
        String file = env.apply(name + "_FILE");
        if (file != null && !file.isBlank()) {
            try {
                value = Files.readString(Path.of(file), StandardCharsets.UTF_8).strip();
            } catch (IOException e) {
                throw new Errors.SecretError(name + "_FILE pointe vers un fichier illisible");
            }
        } else {
            value = env.apply(name);
        }
        if (value == null || value.isEmpty()) {
            throw new Errors.SecretError("Secret manquant : définissez " + name + " ou " + name + "_FILE");
        }
        if (value.length() >= 4) REGISTERED.add(value);
        return value;
    }

    public static String redact(String text) {
        if (text == null) return null;
        String out = text;
        for (String s : REGISTERED) out = out.replace(s, "***");
        return out;
    }
}
