package io.pigmenttm1.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import io.pigmenttm1.config.Config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;

/** Dossier de preuves d'une exécution (données financières : accès restreint au propriétaire et au groupe). */
public final class Evidence {
    private static final ObjectMapper JSON = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);
    private final Path root;

    public Evidence(Path root) {
        this.root = root;
        try {
            Files.createDirectories(root);
            restrict(root, "rwxr-x---");
        } catch (IOException e) {
            throw new Errors.ConnectorException("Dossier de preuves impossible : " + root);
        }
    }

    public Path root() { return root; }

    /** Écrit un fichier et retourne son empreinte SHA-256. */
    public String text(String name, String content) {
        Path p = root.resolve(name);
        try {
            byte[] b = content.getBytes(StandardCharsets.UTF_8);
            Files.write(p, b);
            restrict(p, "rw-r-----");
            return Config.sha256(b);
        } catch (IOException e) {
            throw new Errors.ConnectorException("Écriture de preuve impossible : " + p);
        }
    }

    public String json(String name, Object o) {
        try {
            return text(name, JSON.writeValueAsString(o));
        } catch (IOException e) {
            throw new Errors.ConnectorException("Sérialisation impossible : " + name);
        }
    }

    private static void restrict(Path p, String perms) {
        try {
            Files.setPosixFilePermissions(p, PosixFilePermissions.fromString(perms));
        } catch (UnsupportedOperationException | IOException ignored) {
            // Windows : appliquer les ACL au niveau du répertoire work_dir
        }
    }
}
