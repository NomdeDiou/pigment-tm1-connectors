package io.pigmenttm1.tm1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** Génération MDX d'un périmètre et échappement des noms. */
public final class Mdx {
    private Mdx() {}

    public static String q(String name) { return "[" + name.replace("]", "]]") + "]"; }

    /** MDX couvrant exactement le périmètre : éléments listés, sinon toutes les feuilles (niveau 0). */
    public static String slice(String cube, List<String> dims, Map<String, List<String>> members) {
        List<String> sets = new ArrayList<>();
        for (String d : dims) {
            List<String> m = members.get(d);
            if (m != null) {
                sets.add("{" + m.stream().map(e -> q(d) + "." + q(d) + "." + q(e)).collect(Collectors.joining(",")) + "}");
            } else {
                sets.add("{TM1FILTERBYLEVEL({TM1SUBSETALL(" + q(d) + "." + q(d) + ")},0)}");
            }
        }
        String cols = sets.get(sets.size() - 1);
        List<String> rows = sets.subList(0, sets.size() - 1);
        String rowsExpr = rows.isEmpty() ? "{}" : String.join(" * ", rows);
        return "SELECT NON EMPTY " + cols + " ON 0, NON EMPTY " + rowsExpr + " ON 1 FROM " + q(cube);
    }

    /** Dimension d'un membre à partir de son UniqueName : [Dim].[Hier].[Elem] ou [Dim].[Elem]. */
    public static String dimensionOf(String uniqueName) {
        if (uniqueName == null || !uniqueName.startsWith("[")) throw new IllegalArgumentException("UniqueName inattendu : " + uniqueName);
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < uniqueName.length(); i++) {
            char c = uniqueName.charAt(i);
            if (c == ']') {
                if (i + 1 < uniqueName.length() && uniqueName.charAt(i + 1) == ']') { sb.append(']'); i++; }
                else return sb.toString();
            } else sb.append(c);
        }
        throw new IllegalArgumentException("UniqueName inattendu : " + uniqueName);
    }
}
