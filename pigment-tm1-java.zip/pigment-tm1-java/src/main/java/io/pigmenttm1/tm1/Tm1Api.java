package io.pigmenttm1.tm1;

import io.pigmenttm1.core.Dataset;

import java.util.List;
import java.util.Map;

/** Contrat minimal TM1 utilisé par le moteur (client REST réel ou double de test). */
public interface Tm1Api extends AutoCloseable {
    /** Dimensions du cube dans leur ordre naturel (hors dimension technique des sandboxes). */
    List<String> cubeDimensions(String cube);

    /** Éléments feuilles (non consolidés) de la hiérarchie principale. */
    List<String> leafElements(String dimension);

    boolean sandboxesEnabled();

    /**
     * Lit les cellules non nulles du périmètre (éléments listés ; sinon toutes les feuilles),
     * ou d'une requête MDX explicite. Colonnes du résultat : dimensions du cube, dans l'ordre.
     */
    Dataset read(String cube, Map<String, List<String>> scope, String sandbox, String mdx);

    /** Met à zéro toutes les cellules non nulles du périmètre. */
    void clear(String cube, Map<String, List<String>> scope, String sandbox);

    /** Écrit les valeurs (colonnes = dimensions du cube, dans l'ordre). */
    void write(String cube, Dataset data, String sandbox);

    void createSandbox(String name);

    void deleteSandbox(String name);

    void publish(String sandbox);

    @Override
    void close();
}
