package io.pigmenttm1.tm1;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.pigmenttm1.config.Config;
import io.pigmenttm1.core.Dataset;
import io.pigmenttm1.core.Errors.LoadError;
import io.pigmenttm1.core.Http;
import io.pigmenttm1.core.Secrets;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.logging.Logger;

/**
 * Client REST TM1 / Planning Analytics (API OData v4, TM1 11.x et PA Engine 12).
 *
 *  - lecture   : POST /ExecuteMDX puis GET /Cellsets('id')?$expand=..., puis DELETE du cellset ;
 *  - écriture  : POST /Cubes('c')/tm1.Update (par lots, journal de transactions conservé) ;
 *  - effacement: relecture du périmètre puis écriture de zéros (aucun droit admin / TI requis) ;
 *  - sandboxes : POST /Sandboxes, ?!sandbox=nom, /Sandboxes('n')/tm1.Publish, DELETE.
 */
public final class Tm1RestClient implements Tm1Api {
    private static final Logger LOG = Logger.getLogger(Tm1RestClient.class.getName());
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final String SANDBOX_DIM = "}Sandboxes";

    private final Config.Tm1 conf;
    private final Http http;
    private final String base;
    private final String authorization;
    private final Map<String, List<String>> dimsCache = new HashMap<>();

    public Tm1RestClient(Config.Tm1 conf) {
        this.conf = conf;
        String tsPwd = conf.trustStore == null ? null : Secrets.get(conf.trustStorePasswordEnv);
        this.http = new Http(Duration.ofSeconds(30), conf.trustStore, tsPwd, true, 3);
        this.base = conf.baseUrl.replaceAll("/+$", "");
        this.authorization = switch (conf.auth) {
            case "basic" -> "Basic " + b64(Secrets.get(conf.userEnv) + ":" + Secrets.get(conf.passwordEnv));
            case "cam" -> "CAMNamespace " + b64(Secrets.get(conf.userEnv) + ":" + Secrets.get(conf.passwordEnv) + ":" + conf.namespace);
            case "apikey" -> "Basic " + b64("apikey:" + Secrets.get(conf.passwordEnv));
            case "bearer" -> "Bearer " + Secrets.get(conf.tokenEnv);
            default -> throw new IllegalArgumentException("auth inconnue : " + conf.auth);
        };
    }

    private static String b64(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }

    // ------------------------------------------------------------------ HTTP
    /** Nom d'objet dans un chemin OData : quotes doublées puis encodage URL. */
    static String path(String name) {
        return URLEncoder.encode(name.replace("'", "''"), StandardCharsets.UTF_8).replace("+", "%20");
    }

    /** Nom d'objet dans un lien @odata.bind (même règle que TM1py). */
    static String bind(String name) {
        return name.replace("'", "''").replace("%", "%25").replace("#", "%23").replace("?", "%3F").replace("&", "%26");
    }

    private URI uri(String p, String sandbox) {
        String u = base + p;
        if (sandbox != null) u += (p.contains("?") ? "&" : "?") + "!sandbox=" + URLEncoder.encode(sandbox, StandardCharsets.UTF_8);
        return URI.create(u);
    }

    private HttpRequest.Builder req(URI u) {
        return HttpRequest.newBuilder(u).timeout(Duration.ofSeconds(conf.timeoutS))
                .header("Authorization", authorization)
                .header("Content-Type", "application/json; charset=utf-8")
                .header("Accept", "application/json")
                .header("TM1-SessionContext", "pigment-tm1-connector");     // visible dans le moniteur de threads TM1
    }

    private JsonNode check(HttpResponse<String> r, String what) {
        if (r.statusCode() / 100 != 2) throw new LoadError("TM1 " + what + " : HTTP " + r.statusCode() + " " + Http.excerpt(r.body()));
        try {
            return r.body() == null || r.body().isBlank() ? JSON.nullNode() : JSON.readTree(r.body());
        } catch (Exception e) {
            throw new LoadError("TM1 " + what + " : réponse illisible");
        }
    }

    private JsonNode get(String p, String sandbox, String what) { return check(http.read(req(uri(p, sandbox)).GET().build()), what); }

    private JsonNode post(String p, String sandbox, String body, String what) {
        return check(http.once(req(uri(p, sandbox)).POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build()), what);
    }

    private void delete(String p, String sandbox, String what) { check(http.once(req(uri(p, sandbox)).DELETE().build()), what); }

    // ------------------------------------------------------------------ métadonnées
    @Override
    public List<String> cubeDimensions(String cube) {
        return dimsCache.computeIfAbsent(cube, c -> {
            JsonNode n = get("/Cubes('" + path(c) + "')/Dimensions?$select=Name", null, "dimensions de " + c);
            List<String> d = new ArrayList<>();
            n.path("value").forEach(x -> { if (!SANDBOX_DIM.equals(x.path("Name").asText())) d.add(x.path("Name").asText()); });
            if (d.isEmpty()) throw new LoadError("Cube TM1 introuvable ou sans dimension : " + c);
            return List.copyOf(d);
        });
    }

    @Override
    public List<String> leafElements(String dimension) {
        String d = path(dimension);
        JsonNode n = get("/Dimensions('" + d + "')/Hierarchies('" + d + "')/Elements?$select=Name&$filter=Type%20ne%203",
                null, "éléments de " + dimension);
        List<String> out = new ArrayList<>();
        n.path("value").forEach(x -> out.add(x.path("Name").asText()));
        return out;
    }

    @Override
    public boolean sandboxesEnabled() {
        try {
            get("/Sandboxes?$select=Name", null, "sandboxes");
            return true;
        } catch (LoadError e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ données
    @Override
    public Dataset read(String cube, Map<String, List<String>> scope, String sandbox, String mdx) {
        List<String> dims = cubeDimensions(cube);
        String query = mdx != null ? mdx : Mdx.slice(cube, dims, scope);
        ObjectNode body = JSON.createObjectNode().put("MDX", query);
        String id = post("/ExecuteMDX", sandbox, body.toString(), "ExecuteMDX").path("ID").asText();
        if (id.isEmpty()) throw new LoadError("TM1 ExecuteMDX : pas d'identifiant de cellset");
        try {
            JsonNode cs = get("/Cellsets('" + path(id) + "')?$expand=Axes($expand=Tuples($expand=Members($select=Name,UniqueName))),"
                    + "Cells($select=Ordinal,Value)", sandbox, "cellset");
            return parseCellset(cs, dims, scope);
        } finally {
            try { delete("/Cellsets('" + path(id) + "')", sandbox, "suppression cellset"); }
            catch (LoadError e) { LOG.warning("Cellset " + id + " non supprimé (libéré à la fin de session)"); }
        }
    }

    /** Convertit un cellset (2 axes ou plus) en Dataset ordonné selon les dimensions du cube. */
    static Dataset parseCellset(JsonNode cs, List<String> dims, Map<String, List<String>> scope) {
        List<List<List<String[]>>> axes = new ArrayList<>();  // axe -> tuple -> membres (dim, élément)
        for (JsonNode ax : cs.path("Axes")) {
            List<List<String[]>> tuples = new ArrayList<>();
            for (JsonNode t : ax.path("Tuples")) {
                List<String[]> members = new ArrayList<>();
                for (JsonNode m : t.path("Members"))
                    members.add(new String[]{Mdx.dimensionOf(m.path("UniqueName").asText()), m.path("Name").asText()});
                tuples.add(members);
            }
            axes.add(tuples);
        }
        Dataset out = new Dataset(dims);
        if (axes.isEmpty() || axes.stream().anyMatch(List::isEmpty)) return out;   // NON EMPTY vide
        int[] sizes = axes.stream().mapToInt(List::size).toArray();
        // dimensions absentes des axes (clause WHERE) : complétées depuis le périmètre si un seul élément
        Set<String> onAxes = new HashSet<>();
        axes.forEach(a -> a.get(0).forEach(m -> onAxes.add(m[0])));
        Map<String, String> fixed = new HashMap<>();
        for (String d : dims) {
            if (onAxes.contains(d)) continue;
            List<String> s = scope.get(d);
            if (s == null || s.size() != 1)
                throw new LoadError("Dimension " + d + " absente des axes MDX : placez-la sur un axe ou fixez un seul élément dans le périmètre");
            fixed.put(d, s.get(0));
        }
        for (JsonNode cell : cs.path("Cells")) {
            JsonNode v = cell.path("Value");
            if (!v.isNumber() || v.asDouble() == 0) continue;
            int ord = cell.path("Ordinal").asInt();
            Map<String, String> coord = new HashMap<>(fixed);
            for (int a = 0; a < axes.size(); a++) {
                int idx = ord % sizes[a];
                ord /= sizes[a];
                for (String[] m : axes.get(a).get(idx)) coord.put(m[0], m[1]);
            }
            List<String> key = new ArrayList<>(dims.size());
            for (String d : dims) key.add(coord.get(d));
            out.put(key, v.asDouble());
        }
        return out;
    }

    @Override
    public void clear(String cube, Map<String, List<String>> scope, String sandbox) {
        Dataset current = read(cube, scope, sandbox, null);
        Dataset zeros = new Dataset(current.dims());
        current.cells().keySet().forEach(k -> zeros.put(k, 0));
        write(cube, zeros, sandbox);
    }

    @Override
    public void write(String cube, Dataset data, String sandbox) {
        List<String> dims = cubeDimensions(cube);
        if (!data.dims().equals(dims)) data = data.project(dims);
        String p = "/Cubes('" + path(cube) + "')/tm1.Update";
        ArrayNode batch = JSON.createArrayNode();
        for (var e : data.cells().entrySet()) {
            ObjectNode upd = batch.addObject();
            ArrayNode tuple = upd.putArray("Cells").addObject().putArray("Tuple@odata.bind");
            for (int i = 0; i < dims.size(); i++) {
                String d = bind(dims.get(i));
                tuple.add("Dimensions('" + d + "')/Hierarchies('" + d + "')/Elements('" + bind(e.getKey().get(i)) + "')");
            }
            upd.put("Value", e.getValue());
            if (batch.size() >= conf.writeBatchSize) { post(p, sandbox, batch.toString(), "écriture " + cube); batch.removeAll(); }
        }
        if (!batch.isEmpty()) post(p, sandbox, batch.toString(), "écriture " + cube);
    }

    // ------------------------------------------------------------------ sandboxes
    @Override
    public void createSandbox(String name) {
        ObjectNode b = JSON.createObjectNode().put("Name", name).put("IncludeInSandboxDimension", false);
        post("/Sandboxes", null, b.toString(), "création sandbox");
    }

    @Override
    public void deleteSandbox(String name) { delete("/Sandboxes('" + path(name) + "')", null, "suppression sandbox"); }

    @Override
    public void publish(String sandbox) { post("/Sandboxes('" + path(sandbox) + "')/tm1.Publish", null, "{}", "publication sandbox"); }

    @Override
    public void close() {
        try {
            http.once(req(uri("/ActiveSession/tm1.Close", null)).POST(HttpRequest.BodyPublishers.ofString("{}")).build());
        } catch (Exception e) {
            LOG.warning("Fermeture de session TM1 incomplète");
        }
    }
}
