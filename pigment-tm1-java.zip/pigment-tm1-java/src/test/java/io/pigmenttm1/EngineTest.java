package io.pigmenttm1;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.pigmenttm1.Fakes.FakePigment;
import io.pigmenttm1.Fakes.FakeTm1;
import io.pigmenttm1.audit.AuditLog;
import io.pigmenttm1.config.Config;
import io.pigmenttm1.core.Csv;
import io.pigmenttm1.core.Engine;
import io.pigmenttm1.core.Engine.RunOptions;
import io.pigmenttm1.core.Errors.*;
import io.pigmenttm1.core.FlowLock;
import io.pigmenttm1.core.Secrets;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/** Tests de bout en bout du moteur (Pigment et TM1 simulés en mémoire). */
class EngineTest {
    static final List<String> ENTITIES = List.of("FR01", "DE01", "US01");
    static final List<String> ACCOUNTS = List.of("6000", "6100", "7000");
    static final List<String> PERIODS = List.of("2027-01", "2027-02", "2027-03");
    static final Map<String, String> MONTHS = Map.of("2027-01", "Jan 27", "2027-02", "Feb 27", "2027-03", "Mar 27");
    static final List<String> PG_HEADER = List.of("Entity", "Account", "Month", "Version", "Amount");
    static final String HMAC = "cle-hmac-de-test-0123456789";

    Path tmp;
    FakeTm1 tm1;
    FakePigment pg;

    @BeforeEach
    void setUp() throws Exception {
        tmp = Files.createTempDirectory("connector-test");
        Secrets.setEnvironment(Map.of("TEST_HMAC", HMAC));
        tm1 = new FakeTm1();
        tm1.dims.put("Budget", new ArrayList<>(List.of("Entity", "Account", "Period", "Version", "Measure")));
        tm1.leaves.put("Entity", ENTITIES); tm1.leaves.put("Account", ACCOUNTS); tm1.leaves.put("Period", PERIODS);
        tm1.leaves.put("Version", List.of("Actual", "Budget 2027")); tm1.leaves.put("Measure", List.of("Amount"));
        Map<List<String>, Double> cube = new HashMap<>();
        int i = 0;
        for (String e : ENTITIES) for (String a : ACCOUNTS) for (String p : PERIODS) {
            i++;
            cube.put(List.of(e, a, p, "Budget 2027", "Amount"), i * 1000.5);
            cube.put(List.of(e, a, p, "Actual", "Amount"), i * 10.0);
        }
        cube.put(List.of("FR01", "6000", "2027-01", "Budget 2027", "Amount"), 1.0);   // sera écrasé
        tm1.data.put("Budget", cube);
        pg = new FakePigment();
        pg.views.put("V_BUDGET", budget(1.0, List.of()));
        pg.importTargets.put("CFG1", "V_ACT");
        pg.views.put("V_ACT", new Csv.Table(PG_HEADER, List.of()));
    }

    @AfterEach
    void tearDown() { Secrets.resetEnvironment(); }

    static Csv.Table budget(double scale, List<List<String>> extra) {
        List<List<String>> rows = new ArrayList<>();
        int i = 0;
        for (String e : ENTITIES) for (String a : ACCOUNTS) for (String p : PERIODS) {
            i++;
            rows.add(List.of(e, a, MONTHS.get(p), "Budget 2027", String.format(Locale.ROOT, "%.2f", i * 1000.5 * scale)));
        }
        rows.addAll(extra);
        return new Csv.Table(PG_HEADER, rows);
    }

    Map<String, Object> conf(String env) {
        Map<String, Object> mapping = Map.of(
                "columns", new LinkedHashMap<>(Map.of("Entity", "Entity", "Account", "Account", "Month", "Period", "Version", "Version")),
                "value_column", "Amount",
                "static_members", Map.of("Measure", "Amount"),
                "member_maps", Map.of("Period", Map.of("Jan 27", "2027-01", "Feb 27", "2027-02", "Mar 27", "2027-03")));
        Map<String, Object> p2t = new LinkedHashMap<>();
        p2t.put("name", "budget"); p2t.put("owner", "cdg"); p2t.put("direction", "pigment_to_tm1");
        p2t.put("source", Map.of("view_id", "V_BUDGET"));
        p2t.put("target", Map.of("cube", "Budget", "slice", Map.of("Version", List.of("Budget 2027"), "Period", PERIODS)));
        p2t.put("mapping", mapping);
        p2t.put("governance", Map.of("protected_members", Map.of("Version", List.of("Actual")), "min_rows", 1,
                "max_total_change_pct", 25, "require_approval", true));
        p2t.put("reconciliation", Map.of("control_dimensions", List.of("Entity")));
        Map<String, Object> t2p = new LinkedHashMap<>();
        t2p.put("name", "actuals"); t2p.put("owner", "compta"); t2p.put("direction", "tm1_to_pigment");
        t2p.put("source", Map.of("cube", "Budget", "slice", Map.of("Version", List.of("Actual"), "Period", PERIODS)));
        t2p.put("target", Map.of("import_configuration_id", "CFG1", "verification_view_id", "V_ACT"));
        t2p.put("mapping", mapping);
        Map<String, Object> gov = new HashMap<>();
        gov.put("min_rows", 1); gov.put("max_total_change_pct", null); gov.put("require_approval", true);
        t2p.put("governance", gov);
        return Map.of(
                "runtime", Map.of("environment", env, "work_dir", tmp + "/runs", "audit_log", tmp + "/audit.jsonl",
                        "lock_dir", tmp + "/locks", "audit_hmac_key_env", "TEST_HMAC"),
                "tm1", Map.of("base_url", "https://tm1.test/api/v1"),
                "flows", List.of(p2t, t2p));
    }

    Engine engine(String env) {
        Config c = Config.mapper().convertValue(conf(env), Config.class);
        c.validate();
        return new Engine(c, "testhash", pg, () -> tm1);
    }

    Engine engine() { return engine("dev"); }

    static RunOptions approved() { return new RunOptions(false, "boss", null, "alice"); }

    Map<List<String>, Double> actuals() {
        Map<List<String>, Double> m = new HashMap<>();
        tm1.data.get("Budget").forEach((k, v) -> { if (k.get(3).equals("Actual")) m.put(k, v); });
        return m;
    }

    // ------------------------------------------------------------ Pigment -> TM1
    @Test
    void dryRunWritesNothing() {
        var before = tm1.snapshot("Budget");
        Map<String, Object> r = engine().run("budget", new RunOptions(true, null, null, "alice"));
        assertEquals("dry_run_ok", r.get("status"));
        assertEquals(1, ((Map<?, ?>) r.get("preview")).get("cells_changed"));
        assertEquals(before, tm1.snapshot("Budget"));
    }

    @Test
    void successInSandboxIsReconciled() {
        var actualBefore = actuals();
        Map<String, Object> r = engine().run("budget", approved());
        assertEquals("success", r.get("status"));
        assertEquals("sandbox", r.get("write_mode"));
        Map<?, ?> rec = (Map<?, ?>) r.get("reconciliation");
        assertEquals(true, rec.get("ok"));
        assertEquals(rec.get("expected_fingerprint"), rec.get("actual_fingerprint"));
        assertEquals(1000.5, tm1.data.get("Budget").get(List.of("FR01", "6000", "2027-01", "Budget 2027", "Amount")));
        assertEquals(actualBefore, actuals(), "le réel ne doit jamais être touché");
        assertTrue(tm1.sandboxes.isEmpty(), "sandbox supprimée");
    }

    @Test
    void replaceSliceClearsObsoleteCells() {
        List<List<String>> rows = new ArrayList<>(budget(1, List.of()).rows());
        rows.remove(rows.size() - 1);                                   // cellule supprimée côté Pigment
        pg.views.put("V_BUDGET", new Csv.Table(PG_HEADER, rows));
        Map<String, Object> r = engine().run("budget", approved());
        assertEquals(true, ((Map<?, ?>) r.get("reconciliation")).get("ok"));
        assertFalse(tm1.data.get("Budget").containsKey(List.of("US01", "7000", "2027-03", "Budget 2027", "Amount")));
    }

    @Test
    void elementNamesAreCaseAndSpaceInsensitive() {
        List<List<String>> rows = new ArrayList<>(budget(1, List.of()).rows());
        List<String> first = new ArrayList<>(rows.get(0));
        first.set(0, "fr 01");
        rows.set(0, first);
        pg.views.put("V_BUDGET", new Csv.Table(PG_HEADER, rows));
        engine().run("budget", approved());
        assertEquals(1000.5, tm1.data.get("Budget").get(List.of("FR01", "6000", "2027-01", "Budget 2027", "Amount")));
    }

    @Test
    void unknownElementBlocksEverything() {
        pg.views.put("V_BUDGET", budget(1, List.of(List.of("XX99", "6000", "Jan 27", "Budget 2027", "1"))));
        var before = tm1.snapshot("Budget");
        ValidationError e = assertThrows(ValidationError.class, () -> engine().run("budget", approved()));
        assertTrue(e.issues().stream().anyMatch(i -> i.contains("XX99")));
        assertEquals(before, tm1.snapshot("Budget"));
    }

    @Test
    void protectedMemberBlocks() {
        pg.views.put("V_BUDGET", budget(1, List.of(List.of("FR01", "6000", "Jan 27", "Actual", "1"))));
        ValidationError e = assertThrows(ValidationError.class, () -> engine().run("budget", approved()));
        assertTrue(e.issues().stream().anyMatch(i -> i.contains("protégés")));
    }

    @Test
    void nonNumericAndDuplicatesBlock() {
        List<List<String>> rows = new ArrayList<>(budget(1, List.of()).rows());
        List<String> r1 = new ArrayList<>(rows.get(1));
        r1.set(4, "abc");
        rows.set(1, r1);
        pg.views.put("V_BUDGET", new Csv.Table(PG_HEADER, rows));
        assertThrows(ValidationError.class, () -> engine().run("budget", approved()));
        pg.views.put("V_BUDGET", budget(1, List.of(budget(1, List.of()).rows().get(0))));
        ValidationError e = assertThrows(ValidationError.class, () -> engine().run("budget", approved()));
        assertTrue(e.issues().stream().anyMatch(i -> i.contains("doublon")));
    }

    @Test
    void emptySourceCannotWipeTarget() {
        pg.views.put("V_BUDGET", new Csv.Table(PG_HEADER, List.of()));
        assertThrows(ValidationError.class, () -> engine().run("budget", approved()));
    }

    @Test
    void changeThresholdBlocks() {
        pg.views.put("V_BUDGET", budget(2.0, List.of()));
        assertThrows(GovernanceError.class, () -> engine().run("budget", approved()));
    }

    @Test
    void approvalRequired() {
        assertThrows(GovernanceError.class, () -> engine().run("budget", new RunOptions(false, null, null, "alice")));
    }

    @Test
    void prodRequiresTicketAndFourEyes() {
        Engine e = engine("prod");
        assertThrows(GovernanceError.class, () -> e.run("budget", new RunOptions(false, "boss", null, "alice")));
        assertThrows(GovernanceError.class, () -> e.run("budget", new RunOptions(false, "alice", "CHG-1", "alice")));
        assertEquals("success", e.run("budget", new RunOptions(false, "boss", "CHG-1", "alice")).get("status"));
    }

    @Test
    void sandboxCorruptionIsNeverPublished() {
        var before = tm1.snapshot("Budget");
        tm1.corruptNextWrite = true;
        assertThrows(ReconciliationError.class, () -> engine().run("budget", approved()));
        assertEquals(before, tm1.snapshot("Budget"));
        assertTrue(tm1.published.isEmpty());
        assertTrue(tm1.sandboxes.isEmpty(), "sandbox supprimée même en cas d'échec");
    }

    @Test
    void snapshotModeRestoresOnCorruption() {
        tm1.sandboxesOk = false;
        var before = tm1.snapshot("Budget");
        tm1.corruptNextWrite = true;
        ReconciliationError e = assertThrows(ReconciliationError.class, () -> engine().run("budget", approved()));
        assertTrue(e.getMessage().contains("restauré"));
        assertEquals(before, tm1.snapshot("Budget"));
    }

    @Test
    void snapshotModeRestoresOnWriteFailure() {
        tm1.sandboxesOk = false;
        var before = tm1.snapshot("Budget");
        tm1.failNextWrite = true;
        assertThrows(LoadError.class, () -> engine().run("budget", approved()));
        assertEquals(before, tm1.snapshot("Budget"));
    }

    @Test
    void mappingMustCoverCube() {
        tm1.dims.get("Budget").add("Currency");
        assertThrows(ConfigError.class, () -> engine().run("budget", new RunOptions(true, null, null, "a")));
    }

    @Test
    void evidenceIsWritten() throws Exception {
        Map<String, Object> r = engine().run("budget", approved());
        Path d = tmp.resolve("runs/budget/" + r.get("run_id"));
        for (String f : List.of("source_pigment.csv", "source_canonical.csv", "target_before.csv", "report.json"))
            assertTrue(Files.exists(d.resolve(f)), f);
        Map<?, ?> rep = new ObjectMapper().readValue(d.resolve("report.json").toFile(), Map.class);
        assertEquals("success", rep.get("status"));
    }

    // ------------------------------------------------------------ TM1 -> Pigment
    @Test
    void tm1ToPigmentSucceedsWithInverseMapping() {
        Map<String, Object> r = engine().run("actuals", approved());
        assertEquals("success", r.get("status"));
        assertEquals(true, ((Map<?, ?>) r.get("reconciliation")).get("ok"));
        Csv.Table v = pg.views.get("V_ACT");
        assertEquals(27, v.rows().size());
        Set<String> months = new HashSet<>(), versions = new HashSet<>();
        v.rows().forEach(row -> { months.add(row.get(v.col("Month"))); versions.add(row.get(v.col("Version"))); });
        assertEquals(Set.of("Jan 27", "Feb 27", "Mar 27"), months);
        assertEquals(Set.of("Actual"), versions);
    }

    @Test
    void partialPigmentImportIsDetectedAndCompensated() {
        engine().run("actuals", approved());
        Csv.Table good = pg.views.get("V_ACT");
        tm1.data.get("Budget").put(List.of("FR01", "6000", "2027-01", "Actual", "Amount"), 99.0);
        pg.dropRowsOnImport = 2;
        assertThrows(ReconciliationError.class, () -> engine().run("actuals", approved()));
        assertEquals(new HashSet<>(good.rows()), new HashSet<>(pg.views.get("V_ACT").rows()));
    }

    @Test
    void tm1ToPigmentDryRunDoesNotImport() {
        engine().run("actuals", new RunOptions(true, null, null, "a"));
        assertTrue(pg.pushed.isEmpty());
    }

    // ------------------------------------------------------------ audit et verrou
    @Test
    void auditChainDetectsTampering() throws Exception {
        engine().run("budget", approved());
        assertThrows(GovernanceError.class, () -> engine().run("budget", new RunOptions(false, null, null, "a")));
        AuditLog log = new AuditLog(tmp.resolve("audit.jsonl"), HMAC);
        AuditLog.Verification v = log.verify();
        assertTrue(v.ok(), v.message());
        assertTrue(v.records() >= 5);
        String content = Files.readString(log.path());
        assertTrue(content.contains("\"load_authorized\"") && content.contains("\"run_failed\""));
        assertFalse(content.contains(HMAC), "aucun secret dans l'audit");

        List<String> lines = new ArrayList<>(Files.readAllLines(log.path()));
        List<String> tampered = new ArrayList<>(lines);
        tampered.set(1, tampered.get(1).replace("\"boss\"", "\"mallory\""));
        Files.write(log.path(), tampered);
        assertFalse(log.verify().ok(), "modification détectée");

        List<String> deleted = new ArrayList<>(lines);
        deleted.remove(1);
        Files.write(log.path(), deleted);
        assertFalse(log.verify().ok(), "suppression détectée");

        Files.write(log.path(), lines);
        assertTrue(log.verify().ok());
        assertFalse(new AuditLog(log.path(), "autre-cle").verify().ok(), "mauvaise clé détectée");
    }

    @Test
    void concurrentRunIsBlocked() {
        try (FlowLock ignored = new FlowLock(tmp.resolve("locks"), "budget", "other-run")) {
            assertThrows(LockError.class, () -> engine().run("budget", new RunOptions(true, null, null, "a")));
        }
    }

    @Test
    void prodRefusesUnsignedAudit() {
        Secrets.setEnvironment(Map.of());
        assertThrows(SecretError.class, () -> engine("prod"));
    }
}
