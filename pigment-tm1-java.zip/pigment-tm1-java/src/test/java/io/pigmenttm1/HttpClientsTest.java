package io.pigmenttm1;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import io.pigmenttm1.config.Config;
import io.pigmenttm1.core.Dataset;
import io.pigmenttm1.core.Errors.LoadError;
import io.pigmenttm1.core.Secrets;
import io.pigmenttm1.pigment.PigmentClient;
import io.pigmenttm1.tm1.Mdx;
import io.pigmenttm1.tm1.Tm1RestClient;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Vérifie les requêtes HTTP réellement émises par les clients TM1 et Pigment
 * (chemins OData, échappement, sandbox, authentification, corps JSON, relances).
 */
class HttpClientsTest {
    record Req(String method, String path, String query, String body, String auth) {}

    HttpServer server;
    final List<Req> requests = new CopyOnWriteArrayList<>();
    Function<Req, Object[]> handler;          // -> {status, body}
    final ObjectMapper json = new ObjectMapper();

    @BeforeEach
    void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/", this::handle);
        server.start();
        Secrets.setEnvironment(Map.of("TM1_USER", "svc_conn", "TM1_PASSWORD", "s3cr3t-pwd",
                "PIGMENT_API_KEY", "pg-key-123", "TM1_TOKEN", "tok-abc"));
    }

    @AfterEach
    void stop() { server.stop(0); Secrets.resetEnvironment(); }

    private void handle(HttpExchange ex) throws IOException {
        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Req r = new Req(ex.getRequestMethod(), ex.getRequestURI().getRawPath(), ex.getRequestURI().getRawQuery(), body,
                ex.getRequestHeaders().getFirst("Authorization"));
        requests.add(r);
        Object[] res = handler.apply(r);
        byte[] out = ((String) res[1]).getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders((int) res[0], out.length == 0 ? -1 : out.length);
        if (out.length > 0) ex.getResponseBody().write(out);
        ex.close();
    }

    String url() { return "http://127.0.0.1:" + server.getAddress().getPort() + "/api/v1"; }

    Tm1RestClient tm1(String auth) {
        Config.Tm1 c = new Config.Tm1();
        c.baseUrl = url(); c.auth = auth; c.namespace = "LDAP"; c.writeBatchSize = 2;
        return new Tm1RestClient(c);
    }

    static String dec(String s) { return s == null ? "" : URLDecoder.decode(s, StandardCharsets.UTF_8); }

    // ------------------------------------------------------------------ TM1
    @Test
    void tm1ReadParsesCellsetAndCleansUp() throws Exception {
        String cellset = """
            {"ID":"cs1","Axes":[
              {"Ordinal":0,"Tuples":[
                 {"Members":[{"Name":"Amount","UniqueName":"[Measure].[Measure].[Amount]"}]}]},
              {"Ordinal":1,"Tuples":[
                 {"Members":[{"Name":"FR01","UniqueName":"[Entity].[Entity].[FR01]"},{"Name":"Jan","UniqueName":"[Period].[Jan]"}]},
                 {"Members":[{"Name":"DE01","UniqueName":"[Entity].[Entity].[DE01]"},{"Name":"Jan","UniqueName":"[Period].[Jan]"}]},
                 {"Members":[{"Name":"US]1","UniqueName":"[Entity].[Entity].[US]]1]"},{"Name":"Feb","UniqueName":"[Period].[Feb]"}]}]}],
             "Cells":[{"Ordinal":0,"Value":10.5},{"Ordinal":1,"Value":null},{"Ordinal":2,"Value":-3}]}""";
        handler = r -> switch (r.method() + " " + dec(r.path())) {
            case "GET /api/v1/Cubes('Budget')/Dimensions" -> new Object[]{200,
                    "{\"value\":[{\"Name\":\"Entity\"},{\"Name\":\"Period\"},{\"Name\":\"}Sandboxes\"},{\"Name\":\"Measure\"}]}"};
            case "POST /api/v1/ExecuteMDX" -> new Object[]{201, "{\"ID\":\"cs1\"}"};
            case "GET /api/v1/Cellsets('cs1')" -> new Object[]{200, cellset};
            case "DELETE /api/v1/Cellsets('cs1')" -> new Object[]{204, ""};
            default -> new Object[]{404, "{}"};
        };
        try (Tm1RestClient c = tm1("basic")) {
            Dataset ds = c.read("Budget", Map.of("Measure", List.of("Amount")), "sb 1", null);
            assertEquals(List.of("Entity", "Period", "Measure"), ds.dims(), "dimension }Sandboxes ignorée");
            assertEquals(2, ds.size(), "cellules vides ignorées");
            assertEquals(10.5, ds.cells().get(List.of("FR01", "Jan", "Amount")));
            assertEquals(-3.0, ds.cells().get(List.of("US]1", "Feb", "Amount")));
        }
        Req exec = requests.stream().filter(r -> r.path().endsWith("ExecuteMDX")).findFirst().orElseThrow();
        assertEquals("!sandbox=sb+1", exec.query(), "sandbox transmise en paramètre");
        String mdx = json.readTree(exec.body()).path("MDX").asText();
        assertTrue(mdx.contains("{[Measure].[Measure].[Amount]} ON 0"), mdx);
        assertTrue(mdx.contains("TM1FILTERBYLEVEL({TM1SUBSETALL([Entity].[Entity])},0)"), mdx);
        assertTrue(requests.stream().anyMatch(r -> r.method().equals("DELETE")), "cellset supprimé côté serveur");
        assertEquals("Basic " + Base64.getEncoder().encodeToString("svc_conn:s3cr3t-pwd".getBytes()), exec.auth());
    }

    @Test
    void tm1WriteSendsBatchedOdataUpdates() throws Exception {
        handler = r -> r.path().contains("Dimensions")
                ? new Object[]{200, "{\"value\":[{\"Name\":\"Entity\"},{\"Name\":\"Account\"}]}"}
                : new Object[]{204, ""};
        Dataset ds = new Dataset(List.of("Entity", "Account"));
        ds.put(List.of("FR'01", "60#00"), 1.5);
        ds.put(List.of("DE01", "6100"), 2);
        ds.put(List.of("US01", "7000"), 3);
        try (Tm1RestClient c = tm1("cam")) {
            c.write("My Cube", ds, null);
        }
        List<Req> updates = requests.stream().filter(r -> r.path().endsWith("tm1.Update")).toList();
        assertEquals(2, updates.size(), "lots de 2 cellules");
        assertEquals("/api/v1/Cubes('My%20Cube')/tm1.Update", updates.get(0).path());
        JsonNode first = json.readTree(updates.get(0).body()).get(0);
        assertEquals("Dimensions('Entity')/Hierarchies('Entity')/Elements('FR''01')",
                first.path("Cells").get(0).path("Tuple@odata.bind").get(0).asText());
        assertEquals("Dimensions('Account')/Hierarchies('Account')/Elements('60%2300')",
                first.path("Cells").get(0).path("Tuple@odata.bind").get(1).asText());
        assertEquals(1.5, first.path("Value").asDouble());
        String cam = "CAMNamespace " + Base64.getEncoder().encodeToString("svc_conn:s3cr3t-pwd:LDAP".getBytes());
        assertEquals(cam, updates.get(0).auth());
    }

    @Test
    void tm1SandboxLifecycleAndErrors() throws Exception {
        handler = r -> r.path().endsWith("tm1.Publish") && r.path().contains("bad")
                ? new Object[]{500, "{\"error\":{\"message\":\"boom s3cr3t-pwd\"}}"}
                : new Object[]{201, "{}"};
        try (Tm1RestClient c = tm1("apikey")) {
            c.createSandbox("connector_run1");
            c.publish("connector_run1");
            c.deleteSandbox("connector_run1");
            LoadError e = assertThrows(LoadError.class, () -> c.publish("bad"));
            assertFalse(e.getMessage().contains("s3cr3t-pwd"), "secret masqué dans les erreurs");
        }
        assertEquals("{\"Name\":\"connector_run1\",\"IncludeInSandboxDimension\":false}", requests.get(0).body());
        assertEquals("/api/v1/Sandboxes('connector_run1')/tm1.Publish", requests.get(1).path());
        assertEquals("DELETE", requests.get(2).method());
        assertEquals("Basic " + Base64.getEncoder().encodeToString("apikey:s3cr3t-pwd".getBytes()), requests.get(0).auth());
        assertTrue(requests.get(requests.size() - 1).path().endsWith("ActiveSession/tm1.Close"), "session fermée");
    }

    @Test
    void mdxHelpers() {
        assertEquals("[A]]B]", Mdx.q("A]B"));
        assertEquals("My]Dim", Mdx.dimensionOf("[My]]Dim].[My]]Dim].[x]"));
        assertEquals("SELECT NON EMPTY {[M].[M].[x]} ON 0, NON EMPTY {[E].[E].[a],[E].[E].[b]} ON 1 FROM [C]",
                Mdx.slice("C", List.of("E", "M"), Map.of("E", List.of("a", "b"), "M", List.of("x"))));
    }

    // ------------------------------------------------------------------ Pigment
    PigmentClient pigment() {
        Config.Pigment c = new Config.Pigment();
        c.baseUrl = url(); c.importPollIntervalS = 0.01; c.importTimeoutS = 5;
        return new PigmentClient(c);
    }

    @Test
    void pigmentExportImportAndStatus() {
        int[] polls = {0};
        handler = r -> {
            if (r.path().startsWith("/api/v1/export/view/")) return new Object[]{200, "A;B\n1;2\n"};
            if (r.path().equals("/api/v1/import/push/csv")) return new Object[]{200, "{\"importId\":\"imp-9\"}"};
            if (r.path().equals("/api/v1/import/imp-9/status"))
                return new Object[]{200, ++polls[0] < 3 ? "{\"status\":\"Running\"}" : "{\"status\":\"Completed\"}"};
            return new Object[]{404, ""};
        };
        PigmentClient p = pigment();
        assertEquals("A;B\n1;2\n", p.exportViewCsv("view/1"));
        assertEquals("imp-9", p.pushCsv("cfg-1", "A,B\n1,2\n"));
        assertEquals("Completed", p.waitImport("imp-9").get("status"));
        assertEquals("/api/v1/export/view/view%2F1", requests.get(0).path(), "identifiant encodé");
        assertEquals("Bearer pg-key-123", requests.get(0).auth());
        assertEquals("configurationId=cfg-1", requests.get(1).query());
        assertEquals("A,B\n1,2\n", requests.get(1).body());
    }

    @Test
    void pigmentImportIsNeverRetriedButReadsAre() {
        int[] gets = {0};
        handler = r -> {
            if (r.method().equals("POST")) return new Object[]{503, "busy"};
            return ++gets[0] == 1 ? new Object[]{503, ""} : new Object[]{200, "X\n"};
        };
        PigmentClient p = pigment();
        assertThrows(LoadError.class, () -> p.pushCsv("cfg", "X\n"));
        assertEquals(1, requests.stream().filter(r -> r.method().equals("POST")).count(), "aucune relance d'écriture");
        assertEquals("X\n", p.exportViewCsv("v"));
        assertEquals(2, gets[0], "lecture relancée après 503");
    }

    @Test
    void pigmentFailedImportRaises() {
        handler = r -> r.method().equals("POST") ? new Object[]{200, "{\"id\":\"i1\"}"}
                : new Object[]{200, "{\"status\":\"Failed\",\"errors\":[\"bad row 3\"]}"};
        PigmentClient p = pigment();
        String id = p.pushCsv("cfg", "X\n");
        LoadError e = assertThrows(LoadError.class, () -> p.waitImport(id));
        assertTrue(e.getMessage().contains("bad row 3"));
    }
}
