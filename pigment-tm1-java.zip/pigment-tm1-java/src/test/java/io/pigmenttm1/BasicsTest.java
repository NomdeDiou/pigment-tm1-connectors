package io.pigmenttm1;

import io.pigmenttm1.config.Config;
import io.pigmenttm1.core.Csv;
import io.pigmenttm1.core.Errors.ConfigError;
import io.pigmenttm1.core.Errors.SecretError;
import io.pigmenttm1.core.Numbers;
import io.pigmenttm1.core.Secrets;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/** Configuration, secrets, CSV et nombres. */
class BasicsTest {
    @AfterEach
    void reset() { Secrets.resetEnvironment(); }

    Path write(String json) throws Exception {
        Path p = Files.createTempFile("conf", ".json");
        Files.writeString(p, json);
        return p;
    }

    @Test
    void exampleConfigIsValid() {
        Config.Loaded l = Config.load(Path.of("config/flows.example.json"));
        assertEquals(2, l.config().flows.size());
        assertEquals(64, l.sha256().length());
    }

    @Test
    void inlineSecretIsRejected() throws Exception {
        Path p = write("{\"tm1\":{\"base_url\":\"https://x/api/v1\",\"password\":\"hunter2\"},\"flows\":[]}");
        assertThrows(ConfigError.class, () -> Config.load(p));
    }

    @Test
    void plainHttpIsRejected() throws Exception {
        assertThrows(ConfigError.class, () -> Config.load(write("{\"tm1\":{\"base_url\":\"http://x/api/v1\"},\"flows\":[]}")));
        assertThrows(ConfigError.class, () -> Config.load(write(
                "{\"pigment\":{\"base_url\":\"http://pigment.app/api\"},\"tm1\":{\"base_url\":\"https://x\"},\"flows\":[]}")));
    }

    @Test
    void nonBijectiveMemberMapIsRejected() throws Exception {
        String flow = "{\"name\":\"f\",\"owner\":\"o\",\"direction\":\"pigment_to_tm1\",\"source\":{\"view_id\":\"v\"},"
                + "\"target\":{\"cube\":\"C\"},\"mapping\":{\"columns\":{\"A\":\"A\"},"
                + "\"member_maps\":{\"A\":{\"x\":\"1\",\"y\":\"1\"}}}}";
        Path p = write("{\"tm1\":{\"base_url\":\"https://x\"},\"flows\":[" + flow + "]}");
        ConfigError e = assertThrows(ConfigError.class, () -> Config.load(p));
        assertTrue(e.getMessage().contains("bijectif"));
    }

    @Test
    void secretsFromFileAndRedaction() throws Exception {
        Path f = Files.createTempFile("secret", "");
        Files.writeString(f, "from-file-secret\n");
        Secrets.setEnvironment(Map.of("A_FILE", f.toString(), "B", "env-secret"));
        assertEquals("from-file-secret", Secrets.get("A"));
        assertEquals("env-secret", Secrets.get("B"));
        assertEquals("x *** y", Secrets.redact("x env-secret y"));
        assertThrows(SecretError.class, () -> Secrets.get("MISSING"));
    }

    @Test
    void csvRoundTripWithQuotesAndDelimiters() {
        List<List<String>> rows = List.of(List.of("a;b", "say \"hi\""), List.of("multi\nline", ""));
        String text = Csv.write(List.of("H1", "H2"), rows, ';');
        Csv.Table t = Csv.parse(text, ';');
        assertEquals(List.of("H1", "H2"), t.header());
        assertEquals(rows, t.rows());
        assertThrows(IllegalArgumentException.class, () -> Csv.parse("A;B\n1;2;3\n", ';'));
        assertEquals(List.of("A"), Csv.parse("﻿A\r\n1\r\n", ';').header());
    }

    @Test
    void numbers() {
        assertEquals(1234.5, Numbers.parse(" 1 234,5 ", ","));
        assertEquals(1234567.25, Numbers.parse("1.234.567,25", ","));
        assertEquals(-12.0, Numbers.parse("-12", "."));
        assertNull(Numbers.parse("", "."));
        assertThrows(NumberFormatException.class, () -> Numbers.parse("abc", "."));
        assertThrows(NumberFormatException.class, () -> Numbers.parse("Infinity", "."));
        assertEquals("1000", Numbers.format(1000.0));
        assertEquals("0.1", Numbers.format(0.1));
        assertEquals("123456789012.34", Numbers.format(123456789012.34));
    }
}
