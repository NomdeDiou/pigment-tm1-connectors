package io.pigmenttm1;

import io.pigmenttm1.core.Csv;
import io.pigmenttm1.core.Dataset;
import io.pigmenttm1.pigment.PigmentApi;
import io.pigmenttm1.tm1.Tm1Api;

import java.util.*;

/** Doubles en mémoire de Pigment et TM1, fidèles au contrat utilisé par le moteur. */
final class Fakes {
    private Fakes() {}

    static final class FakeTm1 implements Tm1Api {
        final Map<String, List<String>> dims = new HashMap<>();
        final Map<String, List<String>> leaves = new HashMap<>();
        Map<String, Map<List<String>, Double>> data = new HashMap<>();
        final Map<String, Map<String, Map<List<String>, Double>>> sandboxes = new HashMap<>();
        boolean sandboxesOk = true;
        boolean corruptNextWrite = false;     // écriture silencieusement partielle
        boolean failNextWrite = false;
        final List<String> published = new ArrayList<>();

        private Map<List<String>, Double> store(String cube, String sb) {
            return sb == null ? data.get(cube) : sandboxes.get(sb).get(cube);
        }

        private boolean inScope(String cube, List<String> k, Map<String, List<String>> scope) {
            List<String> d = dims.get(cube);
            for (int i = 0; i < d.size(); i++) {
                List<String> m = scope.get(d.get(i));
                if (m != null && !m.contains(k.get(i))) return false;
            }
            return true;
        }

        @Override public List<String> cubeDimensions(String cube) { return List.copyOf(dims.get(cube)); }
        @Override public List<String> leafElements(String d) { return List.copyOf(leaves.get(d)); }
        @Override public boolean sandboxesEnabled() { return sandboxesOk; }

        @Override
        public Dataset read(String cube, Map<String, List<String>> scope, String sb, String mdx) {
            Dataset ds = new Dataset(dims.get(cube));
            store(cube, sb).forEach((k, v) -> { if (v != 0 && inScope(cube, k, scope)) ds.put(k, v); });
            return ds;
        }

        @Override
        public void clear(String cube, Map<String, List<String>> scope, String sb) {
            store(cube, sb).keySet().removeIf(k -> inScope(cube, k, scope));
        }

        @Override
        public void write(String cube, Dataset d, String sb) {
            if (failNextWrite) { failNextWrite = false; throw new RuntimeException("TM1 write failed"); }
            List<Map.Entry<List<String>, Double>> cells = new ArrayList<>(d.project(dims.get(cube)).cells().entrySet());
            if (corruptNextWrite) { corruptNextWrite = false; cells.remove(cells.size() - 1); }
            Map<List<String>, Double> st = store(cube, sb);
            cells.forEach(e -> { if (e.getValue() == 0) st.remove(e.getKey()); else st.put(e.getKey(), e.getValue()); });
        }

        @Override
        public void createSandbox(String name) {
            Map<String, Map<List<String>, Double>> copy = new HashMap<>();
            data.forEach((c, m) -> copy.put(c, new HashMap<>(m)));
            sandboxes.put(name, copy);
        }

        @Override public void deleteSandbox(String name) { sandboxes.remove(name); }

        @Override
        public void publish(String name) {
            Map<String, Map<List<String>, Double>> copy = new HashMap<>();
            sandboxes.get(name).forEach((c, m) -> copy.put(c, new HashMap<>(m)));
            data = copy;
            published.add(name);
        }

        @Override public void close() { }

        Map<List<String>, Double> snapshot(String cube) { return new HashMap<>(data.get(cube)); }
    }

    /** Vues = tables CSV ; une configuration d'import remplace le contenu d'une vue. */
    static final class FakePigment implements PigmentApi {
        final Map<String, Csv.Table> views = new HashMap<>();
        final Map<String, String> importTargets = new HashMap<>();
        final List<String> pushed = new ArrayList<>();
        int dropRowsOnImport = 0;

        @Override
        public String exportViewCsv(String viewId) {
            Csv.Table t = views.get(viewId);
            return Csv.write(t.header(), t.rows(), ';');
        }

        @Override
        public String pushCsv(String configurationId, String csv) {
            pushed.add(csv);
            Csv.Table t = Csv.parse(csv, ',');
            List<List<String>> rows = new ArrayList<>(t.rows());
            if (dropRowsOnImport > 0) { rows = rows.subList(0, rows.size() - dropRowsOnImport); dropRowsOnImport = 0; }
            views.put(importTargets.get(configurationId), new Csv.Table(t.header(), List.copyOf(rows)));
            return "imp-" + pushed.size();
        }

        @Override
        public Map<String, Object> waitImport(String importId) { return Map.of("status", "Completed", "importId", importId); }
    }
}
