# Connecteur Pigment ⇄ IBM Planning Analytics (TM1) — version Java

Échanges de données bidirectionnels, déclaratifs et contrôlés entre Pigment et TM1 / Planning Analytics (on‑premise 11.x ou Planning Analytics Engine 12 / SaaS).

Même architecture et mêmes garanties que la version Python : les deux produisent des empreintes de données identiques.

| Exigence | Comment elle est tenue |
|---|---|
| **Vérifiable** | Après chaque chargement, la cible est **relue** et réconciliée cellule à cellule avec la source (tolérance paramétrable). Empreintes SHA‑256 de la source, du payload et de l'état antérieur ; totaux de contrôle par axe ; dossier de preuves par exécution. |
| **Infaillible** | Validation **bloquante** avant toute écriture. Écriture atomique : **sandbox TM1** publiée seulement si la relecture est parfaite, sinon **snapshot + restauration automatique vérifiée**. Côté Pigment, ré‑import compensatoire de l'état antérieur. Verrou système par flux (libéré même si le processus meurt). Les écritures ne sont jamais relancées automatiquement (pas de double chargement). |
| **Sécurisé** | Une seule dépendance d'exécution (Jackson) ; HTTP, TLS, CSV et HMAC via le JDK. Aucun secret dans la config : tout champ inconnu, dont `password`, est refusé. Secrets via variables d'environnement ou fichiers montés. HTTPS obligatoire, vérification TLS non désactivable (truststore PKCS12 possible pour une AC interne), pas de redirection suivie. Secrets masqués dans les logs et les erreurs. |
| **Gouvernable** | Flux déclarés en JSON versionné avec propriétaire. Membres protégés, listes blanches, seuils (lignes min/max, variation du total). Approbation nominative, ticket et **quatre yeux** en production. **Journal d'audit chaîné et signé HMAC** (toute altération détectée). `--dry-run` avec prévisualisation. Sessions TM1 identifiées (`TM1-SessionContext`) dans le moniteur de threads. |

## Prérequis

- Java 17 ou plus récent
- Maven 3.8+ (accès à Maven Central ou à votre dépôt interne : Nexus, Artifactory)

## Construire et tester

```bash
mvn test        # 36 tests
mvn package     # produit target/pigment-tm1-connector.jar (jar unique, exécutable)
```

## Configurer

```bash
cp config/flows.example.json config/flows.json      # puis adapter
```

Les clés sont les mêmes que dans la version Python (`work_dir`, `view_id`, `static_members`…). Côté TM1 :

| `tm1.auth` | Usage | Secrets lus |
|---|---|---|
| `basic` | Sécurité native TM1 (mode 1/2) | `TM1_USER`, `TM1_PASSWORD` |
| `cam` | CAM / LDAP (renseigner `namespace`) | `TM1_USER`, `TM1_PASSWORD` |
| `apikey` | Planning Analytics SaaS (clé API) | variable désignée par `password_env` |
| `bearer` | Jeton obtenu par votre IAM | `TM1_TOKEN` |

`tm1.base_url` est la racine REST, se terminant par `/api/v1`. Par exemple :
- on‑premise : `https://tm1.interne:8010/api/v1`
- SaaS : `https://<région>.planninganalytics.saas.ibm.com/api/<tenant>/v0/tm1/<base>/api/v1`

Secrets (exemple) :

```bash
export PIGMENT_API_KEY=...
export TM1_USER=... TM1_PASSWORD=...          # ou TM1_PASSWORD_FILE=/run/secrets/tm1
export CONNECTOR_AUDIT_HMAC_KEY=$(openssl rand -hex 32)   # obligatoire en prod ; à conserver dans le coffre
```

## Utiliser

```bash
JAR=target/pigment-tm1-connector.jar
java -jar $JAR -c config/flows.json list
java -jar $JAR -c config/flows.json validate-config
java -jar $JAR -c config/flows.json run budget_pigment_to_tm1 --dry-run
java -jar $JAR -c config/flows.json run budget_pigment_to_tm1 --operator a.dupont --approved-by j.martin --ticket CHG-1234
java -jar $JAR -c config/flows.json verify-audit
```

Sous Windows, ajoutez `-Dstdout.encoding=UTF-8 -Dstderr.encoding=UTF-8` pour un affichage correct des accents.

| Code | Signification |
|---|---|
| 0 | succès |
| 2 / 3 | configuration / secret |
| 4 | validation : anomalies dans les données, **rien écrit** |
| 5 | gouvernance : approbation, ticket ou seuil, **rien écrit** |
| 6 | échec de chargement, état antérieur restauré |
| 7 | écart de réconciliation, état antérieur **restauré et vérifié** |
| 8 | flux déjà en cours |
| 9 | **CRITIQUE** : restauration impossible, intervention manuelle (état antérieur dans le dossier de preuves) |
| 10 | journal d'audit altéré |
| 64 | erreur d'usage de la ligne de commande |

## Comment le client TM1 travaille

Le connecteur appelle directement l'API REST TM1 (OData v4), sans bibliothèque intermédiaire.

| Opération | Appel REST |
|---|---|
| Lecture | `POST /ExecuteMDX`, puis `GET /Cellsets('id')?$expand=Axes(…),Cells(…)`, puis `DELETE` du cellset |
| Écriture | `POST /Cubes('c')/tm1.Update`, par lots (`write_batch_size`) ; journal de transactions conservé |
| Effacement du périmètre | relecture des cellules non nulles puis écriture de zéros. **Ne nécessite ni droits admin ni TurboIntegrator.** |
| Sandbox | `POST /Sandboxes`, paramètre `?!sandbox=nom`, `POST /Sandboxes('n')/tm1.Publish`, `DELETE` |

Droits nécessaires pour l'utilisateur technique : lecture des dimensions concernées, écriture sur le cube et les versions du périmètre, création de sandboxes personnelles. Aucun droit admin.

## Preuves par exécution

`runs/<flux>/<run_id>/` contient : `source_*.csv` (brut), `source_canonical.csv`, `target_before.csv` (état antérieur, base de restauration), `preview_changes.csv`, `diffs*.csv` en cas d'écart, `pigment_import_status.json`, `report.json`. Les fichiers sont créés en `rw-r-----`. Ils contiennent des données financières : appliquez votre politique de rétention et de chiffrement au repos.

## Ce qui a été testé, et ce qui reste à valider chez vous

Les 36 tests couvrent :
- le moteur : succès réconciliés dans les deux sens, effacement des cellules obsolètes, éléments inconnus, membres protégés, doublons, source vide, seuil de variation, approbation, ticket et quatre yeux ;
- les échecs : corruption silencieuse en sandbox jamais publiée, restauration en mode snapshot, import Pigment partiel détecté puis compensé ;
- l'audit et la concurrence : falsification et suppression de lignes du journal, verrou concurrent ;
- **les requêtes HTTP réellement émises** contre de faux serveurs locaux : chemins OData, échappement des noms (`'`, `#`, espaces, `]`), paramètre sandbox, corps `tm1.Update`, en‑têtes d'authentification des 4 modes, lecture des cellsets, aucune relance des imports, relance des lectures sur 503, masquage des secrets dans les erreurs.

À valider contre vos instances avant la production :
1. **API Pigment** : URL, champ identifiant d'import et libellés de statut, à vérifier sur `https://pigment.app/api/swagger` (les libellés sont paramétrables).
2. **TM1** : le format des réponses de cellset sur votre version (11.x ou 12) et le mode d'authentification SaaS de votre tenant.
3. **Volumétrie** : la lecture se fait en un seul cellset. Au‑delà de quelques millions de cellules, découpez le périmètre en plusieurs flux.
4. **Saisies concurrentes** dans le périmètre pendant le chargement : la réconciliation échouera (c'est voulu). Planifiez hors saisie ou verrouillez la version.
5. Exécutez d'abord chaque flux en `--dry-run` sur un environnement de test.

## Limites connues

- Cellules **numériques** uniquement.
- Pas de synchronisation de métadonnées : les éléments et listes doivent exister des deux côtés ; tout élément inconnu bloque le flux.
- Hiérarchie principale uniquement (celle qui porte le nom de la dimension).
- La compensation côté Pigment suppose une configuration d'import en mode remplacement sur le périmètre.
