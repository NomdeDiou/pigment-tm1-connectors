"""Modèle du problème de décision et vérificateur indépendant.

Une solution = un ensemble d'options retenues (codé en bits : bit i = option i).
Valeur d'une solution = somme des valeurs des options + synergies des paires retenues.
Contraintes : capacités des ressources, options obligatoires / interdites,
groupes exclusifs (au plus une), dépendances (A requiert B), nombre min/max d'options.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .config import DecisionConf
from .errors import ValidationError

EPS = 1e-9


@dataclass(frozen=True)
class Option:
    id: str
    label: str
    value: float
    stdev: float
    costs: tuple[float, ...]


@dataclass
class Problem:
    name: str
    currency: str
    options: list[Option]
    resources: list[str]
    resource_labels: list[str]
    capacities: list[float]
    units: list[float]
    mandatory: frozenset[str] = frozenset()
    forbidden: frozenset[str] = frozenset()
    exclusive_groups: tuple[tuple[str, ...], ...] = ()
    requires: dict[str, tuple[str, ...]] = field(default_factory=dict)
    min_selected: int | None = None
    max_selected: int | None = None
    synergies: dict[tuple[str, str], float] = field(default_factory=dict)

    def __post_init__(self):
        self.ids = [o.id for o in self.options]
        self.index = {o.id: i for i, o in enumerate(self.options)}
        self.n = len(self.options)
        self.v = np.array([o.value for o in self.options], dtype=float)
        self.sd = np.array([o.stdev for o in self.options], dtype=float)
        self.C = np.array([[o.costs[r] for o in self.options] for r in range(len(self.resources))], dtype=float).reshape(
            len(self.resources), self.n)
        self.cap = np.array(self.capacities, dtype=float)
        self.syn = [(self.index[a], self.index[b], val) for (a, b), val in sorted(self.synergies.items())]

    # ------------------------------------------------------------ codage
    def ids_of(self, code: int) -> list[str]:
        return [self.ids[i] for i in range(self.n) if (code >> i) & 1]

    def code_of(self, ids) -> int:
        return sum(1 << self.index[i] for i in ids)

    def label(self, oid: str) -> str:
        o = self.options[self.index[oid]]
        return o.label if o.label and o.label != oid else oid

    # ------------------------------------------------------------ empreinte
    def to_dict(self) -> dict:
        return {
            "name": self.name, "currency": self.currency,
            "options": [{"id": o.id, "label": o.label, "value": o.value, "stdev": o.stdev,
                         "costs": dict(zip(self.resources, o.costs))} for o in self.options],
            "resources": [{"name": r, "label": l, "capacity": c, "unit": u}
                          for r, l, c, u in zip(self.resources, self.resource_labels, self.capacities, self.units)],
            "rules": {"mandatory": sorted(self.mandatory), "forbidden": sorted(self.forbidden),
                      "exclusive_groups": [list(g) for g in self.exclusive_groups],
                      "requires": {k: list(v) for k, v in sorted(self.requires.items())},
                      "min_selected": self.min_selected, "max_selected": self.max_selected},
            "synergies": [{"a": a, "b": b, "value": v} for (a, b), v in sorted(self.synergies.items())],
        }

    def fingerprint(self) -> str:
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True, ensure_ascii=False).encode()).hexdigest()


# ---------------------------------------------------------------- vérificateur indépendant
def check_pure(p: Problem, selected) -> tuple[bool, list[str], float, dict[str, float]]:
    """Vérification en Python pur (aucun numpy) : seconde implémentation, indépendante des solveurs."""
    sel = set(selected)
    violations: list[str] = []
    for s in sel:
        if s not in p.index:
            violations.append(f"option inconnue {s}")
    usage = {}
    for r, name in enumerate(p.resources):
        used = 0.0
        for o in p.options:
            if o.id in sel:
                used += o.costs[r]
        usage[name] = used
        if used > p.capacities[r] + EPS * max(1.0, abs(p.capacities[r])):
            violations.append(f"capacité {name} dépassée ({used:g} > {p.capacities[r]:g})")
    for m in p.mandatory:
        if m not in sel:
            violations.append(f"option obligatoire {m} absente")
    for f in p.forbidden:
        if f in sel:
            violations.append(f"option interdite {f} retenue")
    for g in p.exclusive_groups:
        k = len([x for x in g if x in sel])
        if k > 1:
            violations.append(f"groupe exclusif {list(g)} : {k} options retenues")
    for a, needs in p.requires.items():
        if a in sel:
            for b in needs:
                if b not in sel:
                    violations.append(f"{a} requiert {b}")
    if p.min_selected is not None and len(sel) < p.min_selected:
        violations.append(f"moins de {p.min_selected} options")
    if p.max_selected is not None and len(sel) > p.max_selected:
        violations.append(f"plus de {p.max_selected} options")
    value = 0.0
    for o in p.options:
        if o.id in sel:
            value += o.value
    for (a, b), v in p.synergies.items():
        if a in sel and b in sel:
            value += v
    return (not violations), violations, value, usage


# ---------------------------------------------------------------- construction
def build_problem(dec: DecisionConf, table: pd.DataFrame, capacities: dict[str, float]) -> Problem:
    """table : colonnes id, label, value, stdev, puis une colonne par ressource (coût)."""
    issues: list[str] = []
    res_names = list(dec.resources)
    for col in ["id", "value"] + res_names:
        if col not in table.columns:
            issues.append(f"colonne absente des données : {col}")
    if issues:
        raise ValidationError("Données d'entrée incomplètes", issues)
    t = table.copy()
    t["id"] = t["id"].astype(str).str.strip()
    if "label" not in t.columns:
        t["label"] = t["id"]
    if "stdev" not in t.columns:
        t["stdev"] = 0.0
    t["label"] = [dec.source.labels.get(i, l if isinstance(l, str) and l.strip() else i) for i, l in zip(t["id"], t["label"])]
    for c in ["value", "stdev"] + res_names:
        t[c] = pd.to_numeric(t[c], errors="coerce").astype(float)
    dup = t["id"][t["id"].duplicated()].tolist()
    if dup:
        issues.append(f"options en double : {dup}")
    for c in ["value"] + res_names:
        bad = t.loc[~t[c].map(lambda x: isinstance(x, float) and math.isfinite(x)), "id"].tolist()
        if bad:
            issues.append(f"{c} manquant ou non numérique pour {bad[:10]}")
    t["stdev"] = t["stdev"].fillna(0.0)
    if (t["stdev"] < 0).any():
        issues.append(f"écart-type négatif : {t.loc[t['stdev'] < 0, 'id'].tolist()}")
    for c in res_names:
        neg = t.loc[t[c] < 0, "id"].tolist()
        if neg:
            issues.append(f"coût négatif sur {c} : {neg[:10]}")
    caps = []
    for r in res_names:
        c = capacities.get(r)
        if c is None or not math.isfinite(c) or c < 0:
            issues.append(f"capacité invalide pour {r} : {c}")
        caps.append(float(c) if c is not None else 0.0)
    ids = set(t["id"])
    rules = dec.rules
    refs = (list(rules.mandatory) + list(rules.forbidden) + [x for g in rules.exclusive_groups for x in g]
            + list(rules.requires) + [x for v in rules.requires.values() for x in v]
            + [s.a for s in dec.synergies] + [s.b for s in dec.synergies])
    unknown = sorted({r for r in refs if r not in ids})
    if unknown:
        issues.append(f"règles ou synergies citant des options absentes : {unknown}")
    both = set(rules.mandatory) & set(rules.forbidden)
    if both:
        issues.append(f"options à la fois obligatoires et interdites : {sorted(both)}")
    if len(t) == 0:
        issues.append("aucune option")
    if issues:
        raise ValidationError(f"{len(issues)} anomalie(s) dans les données", issues)

    options = [Option(r.id, r.label, float(r.value), float(r.stdev), tuple(float(getattr(r, c)) for c in res_names))
               for r in t.itertuples(index=False)]
    syn: dict[tuple[str, str], float] = {}
    for s in dec.synergies:
        if s.a == s.b:
            raise ValidationError("synergie d'une option avec elle-même", [s.a])
        key = tuple(sorted((s.a, s.b)))
        syn[key] = syn.get(key, 0.0) + s.value
    return Problem(
        name=dec.name, currency=dec.currency, options=options, resources=res_names,
        resource_labels=[dec.resources[r].label or r for r in res_names], capacities=caps,
        units=[dec.resources[r].unit for r in res_names],
        mandatory=frozenset(rules.mandatory), forbidden=frozenset(rules.forbidden),
        exclusive_groups=tuple(tuple(g) for g in rules.exclusive_groups),
        requires={k: tuple(v) for k, v in rules.requires.items()},
        min_selected=rules.min_selected, max_selected=rules.max_selected, synergies=syn)
