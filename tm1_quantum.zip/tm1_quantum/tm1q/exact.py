"""Résolution exacte : énumération de toutes les combinaisons, ou K meilleures prouvées par MILP.

* Énumération (n ≤ seuil) : chaque combinaison est évaluée ; on obtient TOUTES les solutions
  admissibles, leur classement exact et leur nombre. C'est la vérité de référence.
* MILP (n > seuil) : programme linéaire en nombres entiers (solveur HiGHS via SciPy) ; la
  meilleure solution est prouvée optimale, puis on exclut chaque solution trouvée (« coupe
  no-good ») pour obtenir la suivante : on obtient les K meilleures, dans l'ordre, prouvées.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

from .problem import EPS, Problem

CHUNK = 1 << 16


@dataclass
class Enumeration:
    method: str                   # "exhaustive" | "milp"
    combinations_examined: int    # 2^n pour l'exhaustif
    feasible_count: int           # nombre total de solutions admissibles (exhaustif) ou trouvées (milp)
    codes: np.ndarray             # solutions admissibles triées (valeur décroissante, puis code croissant)
    values: np.ndarray
    proven_optimal: bool
    complete: bool                # True si toutes les solutions admissibles sont connues


def _bits(codes: np.ndarray, n: int) -> np.ndarray:
    return ((codes[:, None] >> np.arange(n, dtype=np.int64)) & 1).astype(np.int8)


def feasible_and_value(p: Problem, bits: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Vectorisé : admissibilité et valeur pour un lot de combinaisons (lignes = combinaisons)."""
    b = bits.astype(np.float64)
    ok = np.ones(len(bits), dtype=bool)
    if len(p.resources):
        used = b @ p.C.T
        ok &= np.all(used <= p.cap + EPS * np.maximum(1.0, np.abs(p.cap)), axis=1)
    for m in p.mandatory:
        ok &= bits[:, p.index[m]] == 1
    for f in p.forbidden:
        ok &= bits[:, p.index[f]] == 0
    for g in p.exclusive_groups:
        ok &= bits[:, [p.index[x] for x in g]].sum(axis=1) <= 1
    for a, needs in p.requires.items():
        for nb in needs:
            ok &= bits[:, p.index[a]] <= bits[:, p.index[nb]]
    cnt = bits.sum(axis=1)
    if p.min_selected is not None:
        ok &= cnt >= p.min_selected
    if p.max_selected is not None:
        ok &= cnt <= p.max_selected
    val = b @ p.v
    for i, j, s in p.syn:
        val = val + s * b[:, i] * b[:, j]
    return ok, val


def enumerate_all(p: Problem) -> Enumeration:
    total = 1 << p.n
    codes_l, vals_l = [], []
    for start in range(0, total, CHUNK):
        codes = np.arange(start, min(start + CHUNK, total), dtype=np.int64)
        ok, val = feasible_and_value(p, _bits(codes, p.n))
        codes_l.append(codes[ok])
        vals_l.append(val[ok])
    codes = np.concatenate(codes_l) if codes_l else np.array([], dtype=np.int64)
    vals = np.concatenate(vals_l) if vals_l else np.array([], dtype=float)
    order = np.lexsort((codes, -np.round(vals, 9)))       # valeur décroissante, puis code : déterministe
    return Enumeration("exhaustive", total, len(codes), codes[order], vals[order], True, True)


def top_k_milp(p: Problem, k: int, time_limit_s: float = 120.0) -> Enumeration:
    n, pairs = p.n, p.syn
    nv = n + len(pairs)                                   # x_i puis y_ij (= x_i ET x_j)
    c = np.zeros(nv)
    c[:n] = -p.v
    for t, (_, _, s) in enumerate(pairs):
        c[n + t] = -s
    rows, lo, hi = [], [], []

    def add(row, lb, ub):
        rows.append(row); lo.append(lb); hi.append(ub)

    for r in range(len(p.resources)):
        row = np.zeros(nv); row[:n] = p.C[r]
        add(row, -np.inf, p.cap[r] + EPS * max(1.0, abs(p.cap[r])))
    for g in p.exclusive_groups:
        row = np.zeros(nv)
        for x in g:
            row[p.index[x]] = 1
        add(row, -np.inf, 1)
    for a, needs in p.requires.items():
        for nb in needs:
            row = np.zeros(nv); row[p.index[a]] = 1; row[p.index[nb]] = -1
            add(row, -np.inf, 0)
    if p.min_selected is not None or p.max_selected is not None:
        row = np.zeros(nv); row[:n] = 1
        add(row, p.min_selected if p.min_selected is not None else -np.inf,
            p.max_selected if p.max_selected is not None else np.inf)
    for t, (i, j, _) in enumerate(pairs):                 # linéarisation exacte du produit
        for idx in (i, j):
            row = np.zeros(nv); row[n + t] = 1; row[idx] = -1
            add(row, -np.inf, 0)                          # y ≤ x
        row = np.zeros(nv); row[n + t] = 1; row[i] = -1; row[j] = -1
        add(row, -1, np.inf)                              # y ≥ xi + xj - 1
    lb, ub = np.zeros(nv), np.ones(nv)
    for m in p.mandatory:
        lb[p.index[m]] = 1
    for f in p.forbidden:
        ub[p.index[f]] = 0

    found_codes, found_vals = [], []
    proven = True
    for _ in range(k):
        cons = [LinearConstraint(np.array(rows), np.array(lo), np.array(hi))] if rows else []
        res = milp(c, constraints=cons, integrality=np.ones(nv), bounds=Bounds(lb, ub),
                   options={"time_limit": time_limit_s, "mip_rel_gap": 0.0})
        if res.status == 2 or res.x is None:              # plus aucune solution admissible
            break
        if res.status != 0:                               # limite de temps : optimalité non prouvée
            proven = False
            if res.x is None:
                break
        x = np.round(res.x[:n]).astype(int)
        code = int(sum(1 << i for i in range(n) if x[i]))
        ok, val = feasible_and_value(p, _bits(np.array([code], dtype=np.int64), n))
        if not ok[0]:
            proven = False
            break
        found_codes.append(code); found_vals.append(float(val[0]))
        row = np.zeros(nv)                                # coupe no-good : exclut exactement cette solution
        row[:n] = np.where(x == 1, 1.0, -1.0)
        add(row, -np.inf, x.sum() - 1)
    codes = np.array(found_codes, dtype=np.int64)
    vals = np.array(found_vals, dtype=float)
    order = np.lexsort((codes, -np.round(vals, 9)))
    return Enumeration("milp", 0, len(codes), codes[order], vals[order], proven, False)
