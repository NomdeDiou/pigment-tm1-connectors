"""Orchestration du calcul quantique et analyse des mesures.

1. Formulation : pénalisation déséquilibrée calibrée (peu de qubits) ou variables d'écart (garantie).
   Calibration : on cherche les coefficients λ pour lesquels le minimum du QUBO est exactement
   la meilleure décision connue (vérifié sur tous les états). Tableau de calibration conservé.
2. Contrôles : Ising = QUBO sur tous les états ; circuit exporté = évolution simulée (porte par porte).
3. Exécution : simulateur local (exact, puis 'shots' mesures tirées) ou IBM Quantum.
4. Lecture : chaque mesure est décodée en décision et vérifiée classiquement (admissibilité,
   valeur, rang exact). Une solution quantique n'est jamais acceptée sans cette vérification.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import circuit as circ
from . import qaoa
from .config import QuantumConf
from .exact import Enumeration, feasible_and_value
from .ibm import run_on_ibm
from .problem import Problem
from .qubo import Qubo, build_qubo, ising_energy_vector

GRID_L1 = [0.25, 0.5, 1, 2, 4, 8, 16, 32]
GRID_L2 = [0.25, 0.5, 1, 2, 4, 8, 16, 32, 64, 128, 256]


@dataclass
class QuantumOutcome:
    status: str                                   # ok | skipped | failed
    reason: str = ""
    formulation: str = ""
    lambdas: tuple[float, float] | None = None
    calibration: list[dict] = field(default_factory=list)
    qubits: int = 0
    slack_qubits: int = 0
    penalty: float = 0.0
    backend: str = ""
    backend_meta: dict = field(default_factory=dict)
    layers: int = 0
    gammas: list[float] = field(default_factory=list)
    betas: list[float] = field(default_factory=list)
    angles_source: str = ""
    shots: int = 0
    seed: int = 0
    qasm: str = ""
    qasm_sha256: str = ""
    decisions: list[dict] = field(default_factory=list)   # mesures agrégées par décision
    metrics: dict = field(default_factory=dict)
    checks: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)


def _decision_ok_value(p: Problem, codes: np.ndarray):
    bits = ((codes[:, None] >> np.arange(p.n, dtype=np.int64)) & 1).astype(np.int8)
    return feasible_and_value(p, bits)


def calibrate(p: Problem, best_value: float, penalty: float | None
              ) -> tuple[Qubo | None, list[dict], tuple[float, float] | None]:
    table, chosen, lam = [], None, None
    combos = sorted(((a, b) for a in GRID_L1 for b in GRID_L2), key=lambda t: (t[0] + t[1], t[0]))
    for l1, l2 in combos:
        q = build_qubo(p, penalty=penalty, method="unbalanced", lambdas=(l1, l2))
        E = q.energy_vector()
        g = int(np.argmin(E))
        code = q.decode(np.array([g]))
        ok, val = _decision_ok_value(p, code)
        match = bool(ok[0]) and abs(float(val[0]) - best_value) <= 1e-6 * max(1.0, abs(best_value))
        table.append({"lambda1": l1, "lambda2": l2, "ground_state_feasible": bool(ok[0]),
                      "ground_state_value": float(val[0]), "matches_optimum": match})
        if match and chosen is None:
            chosen, lam = q, (l1, l2)
    return chosen, table, lam


def best_approximation(p: Problem, table: list[dict], penalty: float | None) -> tuple[Qubo | None, tuple | None]:
    """Réglage dont le minimum est la meilleure décision admissible possible (la plus proche de l'optimum)."""
    feas = [t for t in table if t["ground_state_feasible"]]
    if not feas:
        return None, None
    t = max(feas, key=lambda t: (t["ground_state_value"], -(t["lambda1"] + t["lambda2"])))
    lam = (t["lambda1"], t["lambda2"])
    return build_qubo(p, penalty=penalty, method="unbalanced", lambdas=lam), lam


def run(p: Problem, en: Enumeration, conf: QuantumConf, external_approved: bool) -> QuantumOutcome:
    out = QuantumOutcome(status="skipped", backend=conf.backend, layers=conf.layers, shots=conf.shots, seed=conf.seed)
    if not conf.enabled:
        out.reason = "calcul quantique désactivé dans la configuration"
        return out
    best_value = float(en.values[0])
    rank_of = {int(c): i + 1 for i, c in enumerate(en.codes)}

    # ---------------------------------------------------------------- formulation
    q: Qubo | None = None
    if conf.formulation in ("auto", "unbalanced"):
        q, out.calibration, out.lambdas = calibrate(p, best_value, conf.penalty)
        if q is not None:
            out.formulation = "unbalanced"
        else:
            slack_q = build_qubo(p, penalty=conf.penalty, method="slack")
            if conf.formulation == "auto" and (slack_q.nq <= conf.max_qubits or conf.backend == "ibm"):
                q, out.formulation = slack_q, "slack"
                out.notes.append("Aucun réglage de la pénalisation déséquilibrée ne reproduit exactement l'optimum : "
                                 "formulation à variables d'écart (exacte, plus de qubits).")
            else:
                q, out.lambdas = best_approximation(p, out.calibration, conf.penalty)
                if q is None:
                    out.reason = "aucune formulation compacte exploitable (minimum toujours inadmissible)"
                    return out
                out.formulation = "unbalanced-approx"
                out.notes.append(
                    f"Formulation approchée : la formulation exacte demanderait {slack_q.nq} qubits (limite "
                    f"{conf.max_qubits}). Le réglage retenu λ = {out.lambdas} est celui dont le minimum est la "
                    "meilleure décision admissible atteignable ; chaque mesure reste vérifiée classiquement.")
    if q is None:
        q = build_qubo(p, penalty=conf.penalty, method="slack")
        out.formulation = "slack"
    out.notes += q.notes
    out.qubits, out.penalty = q.nq, q.penalty
    out.slack_qubits = sum(s["slack_qubits"] for s in q.slack)
    if q.nq == 0:
        out.reason = "aucune variable libre (toutes les options sont imposées)"
        return out

    simulable = q.nq <= conf.max_qubits
    if conf.backend == "simulator" and not simulable:
        out.reason = (f"{q.nq} qubits dépassent la limite du simulateur local ({conf.max_qubits}) ; "
                      "utilisez le backend ibm ou réduisez le problème")
        return out
    if conf.backend == "ibm" and not external_approved:
        out.status, out.reason = "failed", "envoi vers IBM Quantum non approuvé (--approved-by requis)"
        return out

    h, J, offset = q.to_ising()
    E = None
    if simulable:
        E = q.energy_vector()
        Ei = ising_energy_vector(h, J, offset)
        out.checks["ising_equals_qubo_max_abs_diff"] = float(np.max(np.abs(Ei - E)))
        out.checks["ising_equals_qubo"] = bool(np.allclose(Ei, E, rtol=1e-9, atol=1e-9))
        g = int(np.argmin(E))
        ok, val = _decision_ok_value(p, q.decode(np.array([g])))
        out.checks["qubo_minimum_is_optimum"] = bool(ok[0]) and abs(float(val[0]) - best_value) <= 1e-6 * max(1, abs(best_value))
        out.checks["qubo_minimum_guaranteed"] = out.formulation == "slack" and q.exact_discretization

    # ---------------------------------------------------------------- angles
    if simulable:
        r = qaoa.optimize(E, conf.layers, conf.restarts, conf.cvar_alpha, conf.seed)
        out.gammas, out.betas = r.gammas, r.betas
        out.angles_source = f"optimisés localement (COBYLA, CVaR α={conf.cvar_alpha}, {r.evaluations} évaluations)"
        emin, escale, probs = r.energy_min, r.energy_scale, r.probs
    else:
        L = conf.layers
        out.gammas = [float((k + 0.5) / L * 0.8) for k in range(L)]
        out.betas = [float((1 - (k + 0.5) / L) * 0.8) for k in range(L)]
        out.angles_source = "rampe linéaire (problème trop grand pour optimiser les angles localement)"
        escale = float(np.sqrt(np.sum(h ** 2) + sum(v ** 2 for v in J.values()))) or 1.0
        probs = None
    gates = circ.qaoa_gates(h, J, out.gammas, out.betas, escale)
    out.qasm = circ.to_qasm2(q.nq, gates)
    out.qasm_sha256 = circ.qasm_sha256(out.qasm)
    out.metrics["circuit_gates"] = len(gates)
    out.metrics["circuit_two_qubit_gates"] = sum(1 for g in gates if g[0] == "rzz")

    if simulable and q.nq <= conf.gate_check_max_qubits:
        ref = np.abs(circ.simulate_gates(q.nq, gates)) ** 2
        diff = float(np.max(np.abs(ref - probs)))
        out.checks["circuit_matches_simulation_max_abs_diff"] = diff
        out.checks["circuit_matches_simulation"] = diff < 1e-9

    # ---------------------------------------------------------------- exécution
    try:
        if conf.backend == "simulator":
            counts = qaoa.sample(probs, conf.shots, conf.seed)
            out.backend_meta = {"backend": "simulateur local à vecteur d'état (numpy)"}
        else:
            counts, out.backend_meta = run_on_ibm(out.qasm, conf.shots, conf.ibm, conf.seed)
    except Exception as exc:  # noqa: BLE001
        out.status, out.reason = "failed", f"exécution quantique impossible : {exc}"
        return out

    # ---------------------------------------------------------------- lecture vérifiée
    states = np.array(sorted(counts), dtype=np.int64)
    cnt = np.array([counts[s] for s in states], dtype=np.int64)
    codes = q.decode(states)
    agg: dict[int, int] = {}
    for c, n_ in zip(codes, cnt):
        agg[int(c)] = agg.get(int(c), 0) + int(n_)
    uniq = np.array(sorted(agg), dtype=np.int64)
    ok, val = _decision_ok_value(p, uniq)
    total = int(cnt.sum())
    rows = []
    for c, f, v in zip(uniq, ok, val):
        rows.append({"code": int(c), "count": agg[int(c)], "frequency": agg[int(c)] / total, "feasible": bool(f),
                     "value": float(v), "exact_rank": rank_of.get(int(c)) if f else None})
    rows.sort(key=lambda r: (-r["count"], r["code"]))
    out.decisions = rows
    feas = [r for r in rows if r["feasible"]]
    best_obs = max(feas, key=lambda r: (r["value"], -r["code"])) if feas else None
    opt_codes = {int(c) for c, v in zip(en.codes, en.values) if abs(v - best_value) <= 1e-6 * max(1, abs(best_value))}
    opt_freq = sum(r["frequency"] for r in rows if r["code"] in opt_codes)
    top10 = {int(c) for c in en.codes[:10]}
    top10_freq = sum(r["frequency"] for r in rows if r["code"] in top10)
    m = out.metrics
    m.update({
        "shots_total": total,
        "distinct_states": len(states),
        "distinct_decisions": len(rows),
        "feasible_frequency": sum(r["frequency"] for r in feas),
        "optimum_observed": opt_freq > 0,
        "optimum_frequency": opt_freq,
        "top10_frequency": top10_freq,
        "best_observed_value": best_obs["value"] if best_obs else None,
        "best_observed_rank": best_obs["exact_rank"] if best_obs else None,
        "approximation_ratio": (best_obs["value"] / best_value) if best_obs and best_value > 0 else None,
    })
    if simulable:
        all_codes = q.decode(np.arange(1 << q.nq, dtype=np.int64))
        okall, _ = _decision_ok_value(p, all_codes)
        m["uniform_feasible_share"] = float(okall.mean())
        m["uniform_top10_share"] = float(np.isin(all_codes, list(top10)).mean())
        m["uniform_optimum_share"] = float(np.isin(all_codes, list(opt_codes)).mean())
        m["theoretical_optimum_probability"] = float(probs[np.isin(all_codes, list(opt_codes))].sum())
        m["top10_enrichment"] = (top10_freq / m["uniform_top10_share"]) if m["uniform_top10_share"] else None
    out.checks["counts_sum_equals_shots"] = total == conf.shots
    out.status = "ok"
    return out
