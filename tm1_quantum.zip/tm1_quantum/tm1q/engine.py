"""Orchestration : analyser (lecture seule) puis, après revue humaine, réécrire (approuvé, vérifié).

analyze  : TM1 (ou fichier) -> problème -> toutes les solutions / K meilleures prouvées -> probabilités
           -> calcul quantique -> contrôles -> rapport + résultat scellé (SHA-256 dans l'audit).
writeback: vérifie l'audit, le sceau du résultat, que les données TM1 n'ont pas changé, l'approbation,
           puis écrit atomiquement et réconcilie.
"""
from __future__ import annotations

import dataclasses
import getpass
import hashlib
import json
import logging
import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

from . import exact, insights, quantum, report, robustness, tm1io
from .audit import AuditLog
from .config import AppConf, DecisionConf
from .errors import (ConnectorError, GovernanceError, InfeasibleError, ValidationError, VerificationError)
from .lock import FlowLock
from .problem import Problem, build_problem, check_pure
from .secrets import get_secret, redact
from .verify import run_checks

log = logging.getLogger(__name__)


@dataclass
class RunOptions:
    approved_by: str | None = None
    ticket: str | None = None
    operator: str | None = None


class Evidence:
    def __init__(self, root: Path):
        self.root = root
        root.mkdir(parents=True, exist_ok=True)
        os.chmod(root, 0o750)

    def write(self, name: str, content: str) -> str:
        p = self.root / name
        p.write_text(content, encoding="utf-8")
        os.chmod(p, 0o640)
        return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _json(o) -> str:
    def conv(x):
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.floating,)):
            return float(x)
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, (set, frozenset)):
            return sorted(x)
        raise TypeError(type(x))
    return json.dumps(o, indent=2, ensure_ascii=False, default=conv, sort_keys=False)


class Engine:
    def __init__(self, conf: AppConf, conf_hash: str, tm1_factory: Callable | None = None):
        self.conf, self.conf_hash = conf, conf_hash
        if tm1_factory is None:
            from .tm1 import TM1Adapter
            tm1_factory = lambda: TM1Adapter(conf.tm1)  # noqa: E731
        self.tm1_factory = tm1_factory
        key = None
        if conf.runtime.audit_hmac_key_env:
            try:
                key = get_secret(conf.runtime.audit_hmac_key_env)
            except ConnectorError:
                if conf.runtime.environment == "prod":
                    raise
                log.warning("Audit non signé (pas de clé HMAC) : acceptable hors production uniquement")
        self.audit = AuditLog(conf.runtime.audit_log, key)

    # ================================================================ données
    def _load(self, dec: DecisionConf, input_csv: str | None) -> tuple[Problem, dict]:
        if input_csv:
            p = Path(input_csv)
            if not p.is_file():
                raise ValidationError(f"Fichier introuvable : {p}")
            raw = p.read_bytes()
            table = pd.read_csv(p, dtype=str, keep_default_na=False)
            caps = {}
            for r, rc in dec.resources.items():
                if rc.capacity is None:
                    raise ValidationError(f"Mode fichier : capacité {r} à fournir en valeur (capacity)")
                caps[r] = rc.capacity
            src = {"kind": "csv", "file": p.name, "sha256": hashlib.sha256(raw).hexdigest()}
        else:
            with self.tm1_factory() as tm1:
                table, caps = tm1io.read_problem_table(tm1, dec)
            src = {"kind": "tm1", "cube": dec.source.cube, "fixed": dec.source.fixed}
        return build_problem(dec, table, caps), src

    # ================================================================ analyse
    def analyze(self, name: str, input_csv: str | None = None, opts: RunOptions = RunOptions()) -> dict:
        dec = self.conf.decision(name)
        run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
        operator = opts.operator or getpass.getuser()
        ev = Evidence(Path(self.conf.runtime.work_dir) / dec.name / run_id)
        base = {"run_id": run_id, "decision": dec.name, "operator": operator, "config_sha256": self.conf_hash,
                "environment": self.conf.runtime.environment}
        with FlowLock(self.conf.runtime.lock_dir, dec.name, run_id):
            self.audit.append("analysis_started", **base, quantum_backend=dec.quantum.backend if dec.quantum.enabled else None)
            try:
                result = self._analyze(dec, input_csv, opts, ev, run_id, operator)
            except ConnectorError as exc:
                self.audit.append("analysis_failed", **base, error_type=type(exc).__name__, error=redact(str(exc))[:2000],
                                  issues=getattr(exc, "issues", [])[:20])
                ev.write("erreur.json", _json({"error_type": type(exc).__name__, "error": redact(str(exc)),
                                               "issues": getattr(exc, "issues", [])}))
                raise
            except Exception as exc:
                self.audit.append("analysis_failed", **base, error_type=type(exc).__name__, error=redact(str(exc))[:2000])
                raise ConnectorError(f"Erreur inattendue : {redact(str(exc))}") from exc
            sha = ev.write("result.json", _json(result))
            ev.write("rapport.html", report.render(result))
            self.audit.append("analysis_completed", **base, result_sha256=sha, verified=result["verified"],
                              problem_fingerprint=result["problem_fingerprint"], source=result["source"],
                              best_value=result["ranking"][0]["value"], best_options=result["ranking"][0]["options"],
                              qasm_sha256=result["quantum"].get("qasm_sha256"))
            if not result["verified"]:
                failed = [c["label"] + " : " + c["detail"] for c in result["checks"] if c["blocking"]]
                raise VerificationError("Contrôles bloquants en échec : résultats non publiables "
                                        f"(rapport : {ev.root / 'rapport.html'})", failed)
            result["_evidence_dir"] = str(ev.root)
            return result

    def _analyze(self, dec, input_csv, opts, ev, run_id, operator) -> dict:
        an = dec.analysis
        p, src = self._load(dec, input_csv)
        ev.write("probleme.json", _json(p.to_dict()))

        # ---------------------------------------------------------- exact
        if p.n <= an.exhaustive_max_options:
            en = exact.enumerate_all(p)
            cross = exact.top_k_milp(p, min(an.top_k, 10, max(1, en.feasible_count)))
        else:
            en = exact.top_k_milp(p, max(an.top_k, an.milp_candidates))
            cross = None
        if en.feasible_count == 0:
            raise InfeasibleError("Aucune décision ne respecte toutes les contraintes", _explain_infeasible(p))
        export_rows = min(en.feasible_count, an.export_all_max_rows)
        lines = ["rang,valeur,nb_options,options"]
        for i in range(export_rows):
            ids = p.ids_of(int(en.codes[i]))
            lines.append(f"{i + 1},{en.values[i]:.6f},{len(ids)},{'+'.join(ids)}")
        ev.write("toutes_les_solutions.csv", "\n".join(lines) + "\n")

        # ---------------------------------------------------------- probabilités
        rob = robustness.analyze(p, en.codes, en.values, an.top_k, an.scenarios, an.seed, an.max_candidates_robustness)
        rob2 = robustness.analyze(p, en.codes, en.values, an.top_k, an.scenarios, an.seed, an.max_candidates_robustness)

        # ---------------------------------------------------------- quantique
        external_ok = True
        if dec.quantum.enabled and dec.quantum.backend == "ibm":
            external_ok = bool(opts.approved_by) and (self.conf.runtime.environment != "prod" or bool(opts.ticket))
        qo = quantum.run(p, en, dec.quantum, external_ok)
        if qo.qasm:
            ev.write("circuit.qasm", qo.qasm)
        if qo.decisions:
            ql = ["frequence,mesures,admissible,rang_exact,valeur,options"]
            for d in qo.decisions:
                ql.append(f'{d["frequency"]:.6f},{d["count"]},{int(d["feasible"])},{d["exact_rank"] or ""},'
                          f'{d["value"]:.6f},{"+".join(p.ids_of(d["code"]))}')
            ev.write("mesures_quantiques.csv", "\n".join(ql) + "\n")

        # ---------------------------------------------------------- sensibilité
        sens = _sensitivity(p, en, float(en.values[0]))

        # ---------------------------------------------------------- assemblage
        k = min(an.top_k, en.feasible_count)
        qfreq = {d["code"]: d for d in qo.decisions}
        first_ids = set(p.ids_of(int(en.codes[0])))
        ranking = []
        for i in range(k):
            code, val = int(en.codes[i]), float(en.values[i])
            ids = p.ids_of(code)
            _, _, _, usage = check_pure(p, ids)
            qd = qfreq.get(code)
            ranking.append({
                "rank": i + 1,
                "tie": any(0 <= j < en.feasible_count and abs(val - float(en.values[j])) <= 1e-6 * max(1, abs(val))
                           for j in (i - 1, i + 1)),
                "code": code, "options": ids, "value": val,
                "gap_pct": 0.0 if i == 0 else (val - float(en.values[0])) / abs(float(en.values[0])) * 100
                if en.values[0] else None,
                "p_best": float(rob.p_best[i]), "ci95": float(rob.ci95[i]),
                "p5": float(rob.p5[i]), "p50": float(rob.p50[i]), "p95": float(rob.p95[i]),
                "p_beats_first": float(rob.p_beats_first[i]) if i < len(rob.p_beats_first) else None,
                "usage": {r: {"used": usage[r], "capacity": c, "pct": (usage[r] / c) if c else None}
                          for r, c in zip(p.resources, p.capacities)},
                "quantum_frequency": qd["frequency"] if qd else (0.0 if qo.status == "ok" else None),
                "diff_vs_first": {"added": [x for x in ids if x not in first_ids],
                                  "removed": [x for x in p.ids_of(int(en.codes[0])) if x not in set(ids)]},
            })
        order = np.argsort(-rob.p_best, kind="stable")[:5]
        by_prob = [{"rank": int(j) + 1, "p_best": float(rob.p_best[j]), "options": p.ids_of(int(en.codes[j])),
                    "value": float(en.values[j])} for j in order if rob.p_best[j] > 0]
        options = [{"id": o.id, "label": o.label, "value": o.value, "stdev": o.stdev,
                    "costs": dict(zip(p.resources, o.costs)), "in_first": o.id in first_ids,
                    "p_in_best": float(rob.option_in_best[i])} for i, o in enumerate(p.options)]
        qdict = {k_: v for k_, v in dataclasses.asdict(qo).items() if k_ not in ("qasm", "decisions")}
        qdict["top_decisions"] = [{**d, "options": p.ids_of(d["code"])} for d in qo.decisions[:20]]
        checks = run_checks(p, en, cross, rob, rob2, qo, an.top_k)
        result = {
            "run_id": run_id, "decision": dec.name, "owner": dec.owner, "description": dec.description,
            "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
            "environment": self.conf.runtime.environment, "operator": operator, "config_sha256": self.conf_hash,
            "source": src, "problem": p.to_dict(), "problem_fingerprint": p.fingerprint(),
            "analysis": an.model_dump(),
            "exact": {"method": en.method, "combinations_examined": en.combinations_examined,
                      "feasible_count": en.feasible_count, "proven_optimal": en.proven_optimal,
                      "complete": en.complete, "export_file": "toutes_les_solutions.csv", "exported_rows": export_rows},
            "ranking": ranking, "by_probability": by_prob, "options": options,
            "robustness": {"deterministic": rob.deterministic, "scenarios": rob.scenarios, "seed": rob.seed,
                           "candidates": rob.candidates, "truncated": rob.truncated, "fingerprint": rob.fingerprint},
            "sensitivity": sens, "quantum": qdict, "checks": checks,
            "verified": not any(c["blocking"] for c in checks),
        }
        result["insights"] = insights.build(result)
        return result

    # ================================================================ réécriture
    def writeback(self, name: str, run_id: str, ranks: int, opts: RunOptions) -> dict:
        dec = self.conf.decision(name)
        operator = opts.operator or getpass.getuser()
        base = {"run_id": run_id, "decision": dec.name, "operator": operator, "approved_by": opts.approved_by,
                "ticket": opts.ticket, "ranks": ranks, "environment": self.conf.runtime.environment}
        with FlowLock(self.conf.runtime.lock_dir, dec.name, f"writeback-{run_id}"):
            self.audit.append("writeback_started", **base)
            try:
                out = self._writeback(dec, run_id, ranks, opts, operator)
            except ConnectorError as exc:
                self.audit.append("writeback_failed", **base, error_type=type(exc).__name__, error=redact(str(exc))[:2000])
                raise
            self.audit.append("writeback_completed", **base, **out)
            return out

    def _writeback(self, dec, run_id, ranks, opts, operator) -> dict:
        if dec.writeback is None:
            raise GovernanceError("Aucune cible de réécriture configurée pour cette décision")
        if dec.governance.require_approval:
            if not opts.approved_by:
                raise GovernanceError("Approbation requise : --approved-by <nom>")
            if self.conf.runtime.environment == "prod":
                if not opts.ticket:
                    raise GovernanceError("Ticket de changement obligatoire en production (--ticket)")
                if opts.approved_by.strip().lower() == operator.strip().lower():
                    raise GovernanceError("Principe des quatre yeux : l'approbateur doit différer de l'opérateur")
        ok, n, msg = self.audit.verify()
        if not ok:
            raise GovernanceError(f"Journal d'audit altéré ({msg}) : réécriture refusée")
        sealed = None
        for line in self.audit.path.read_text(encoding="utf-8").splitlines():
            rec = json.loads(line)
            if rec.get("event") == "analysis_completed" and rec.get("run_id") == run_id and rec.get("decision") == dec.name:
                sealed = rec
        if sealed is None:
            raise GovernanceError(f"Analyse {run_id} absente du journal d'audit")
        path = Path(self.conf.runtime.work_dir) / dec.name / run_id / "result.json"
        if not path.is_file():
            raise GovernanceError(f"Résultat introuvable : {path}")
        raw = path.read_text(encoding="utf-8")
        if hashlib.sha256(raw.encode("utf-8")).hexdigest() != sealed["result_sha256"]:
            raise GovernanceError("Le fichier de résultat a été modifié depuis l'analyse : réécriture refusée")
        result = json.loads(raw)
        if not result.get("verified"):
            raise GovernanceError("Analyse non vérifiée : réécriture interdite")
        if result["source"]["kind"] != "tm1":
            raise GovernanceError("Analyse réalisée sur fichier : seule une analyse des données TM1 peut être réécrite")
        with self.tm1_factory() as tm1:
            table, caps = tm1io.read_problem_table(tm1, dec)
            fp = build_problem(dec, table, caps).fingerprint()
            if fp != result["problem_fingerprint"]:
                raise GovernanceError("Les données TM1 ont changé depuis l'analyse : relancez l'analyse avant de réécrire")
            wb = dec.writeback
            leaves = {d: tm1.leaf_elements(d) for d in
                      [wb.rank_dimension, wb.option_dimension, wb.measure_dimension, *wb.fixed]}
            data, scope = tm1io.build_writeback(dec, result, ranks, leaves)
            self.audit.append("writeback_authorized", run_id=run_id, decision=dec.name, approved_by=opts.approved_by,
                              ticket=opts.ticket, cells=len(data),
                              options_rank1=result["ranking"][0]["options"])
            out = tm1io.write_verified(tm1, wb.cube, data, scope, self.conf.tm1.use_sandbox, run_id)
        return out


# ---------------------------------------------------------------- utilitaires
def _best(p: Problem, method: str) -> float | None:
    en = exact.enumerate_all(p) if method == "exhaustive" else exact.top_k_milp(p, 1)
    return float(en.values[0]) if en.feasible_count else None


def _sensitivity(p: Problem, en, best: float) -> list[dict]:
    out = []
    for r, name in enumerate(p.resources):
        vals = {}
        for f in (0.9, 1.1):
            caps = list(p.capacities)
            caps[r] = caps[r] * f
            vals[f] = _best(dataclasses.replace(p, capacities=caps), en.method)
        out.append({"resource": name, "label": p.resource_labels[r], "capacity": p.capacities[r],
                    "minus10": vals[0.9], "plus10": vals[1.1],
                    "delta_minus_pct": None if vals[0.9] is None or not best else (vals[0.9] - best) / abs(best) * 100,
                    "delta_plus_pct": None if vals[1.1] is None or not best else (vals[1.1] - best) / abs(best) * 100})
    return out


def _explain_infeasible(p: Problem) -> list[str]:
    msgs = []
    sel = set(p.mandatory)
    ok, viol, _, _ = check_pure(p, sel)
    if not ok:
        msgs.append("Les options obligatoires, à elles seules, violent : " + "; ".join(viol))
    if p.min_selected:
        msgs.append(f"Vérifiez la règle « au moins {p.min_selected} options » au regard des capacités.")
    return msgs or ["Les contraintes combinées (groupes, dépendances, capacités) s'excluent mutuellement."]
