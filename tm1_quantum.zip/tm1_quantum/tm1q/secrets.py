"""Résolution des secrets et masquage dans les journaux.

Sources acceptées, dans l'ordre :
  1. VAR_FILE : chemin d'un fichier (secret Kubernetes / Docker, coffre monté) ;
  2. VAR      : variable d'environnement (injectée par Vault, Azure Key Vault, CyberArk...).
Les secrets ne sont jamais écrits dans la config, les logs, l'audit ni les preuves.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

from .errors import SecretError

_REGISTERED: set[str] = set()


def get_secret(env_name: str) -> str:
    file_var = os.environ.get(f"{env_name}_FILE")
    if file_var:
        p = Path(file_var)
        if not p.is_file():
            raise SecretError(f"{env_name}_FILE pointe vers un fichier absent")
        value = p.read_text(encoding="utf-8").strip()
    else:
        value = os.environ.get(env_name, "")
    if not value:
        raise SecretError(f"Secret manquant : définissez {env_name} ou {env_name}_FILE")
    if len(value) >= 4:
        _REGISTERED.add(value)
    return value


def redact(text: str) -> str:
    for s in _REGISTERED:
        text = text.replace(s, "***")
    return text


class RedactingFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.msg = redact(str(record.getMessage()))
        record.args = ()
        return True
