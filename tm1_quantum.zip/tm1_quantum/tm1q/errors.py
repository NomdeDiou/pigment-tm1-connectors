"""Exceptions typées et codes de sortie stables."""


class ConnectorError(Exception):
    exit_code = 1


class ConfigError(ConnectorError):
    exit_code = 2


class SecretError(ConnectorError):
    exit_code = 3


class ValidationError(ConnectorError):
    """Données d'entrée incohérentes : aucun calcul n'est publié."""
    exit_code = 4

    def __init__(self, message: str, issues: list[str] | None = None):
        super().__init__(message)
        self.issues = issues or []


class GovernanceError(ConnectorError):
    exit_code = 5


class LoadError(ConnectorError):
    exit_code = 6


class ReconciliationError(ConnectorError):
    exit_code = 7


class LockError(ConnectorError):
    exit_code = 8


class RollbackError(ConnectorError):
    exit_code = 9


class VerificationError(ConnectorError):
    """Un contrôle de vérification a échoué : résultats non publiables."""
    exit_code = 11

    def __init__(self, message: str, issues: list[str] | None = None):
        super().__init__(message)
        self.issues = issues or []


class InfeasibleError(ConnectorError):
    """Aucune solution ne respecte toutes les contraintes."""
    exit_code = 12

    def __init__(self, message: str, issues: list[str] | None = None):
        super().__init__(message)
        self.issues = issues or []
