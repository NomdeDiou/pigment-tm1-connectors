"""Probabilités métier par simulation de Monte-Carlo.

Hypothèse (affichée dans le rapport) : la valeur de chaque option suit une loi normale
indépendante, de moyenne « valeur » et d'écart-type « stdev » ; synergies et coûts sont
certains. Pour chaque scénario tiré, on cherche la meilleure décision admissible.

On en déduit, pour chaque décision :
  * P(meilleure) : part des scénarios où elle est la meilleure, avec intervalle de confiance à 95 % ;
  * la fourchette de valeur P5 / P50 / P95 ;
  * P(fait mieux que la n°1) ;
et pour chaque option : la probabilité qu'elle fasse partie de la meilleure décision.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .problem import Problem


@dataclass
class Robustness:
    deterministic: bool
    scenarios: int
    seed: int
    candidates: int                  # décisions mises en concurrence
    truncated: bool                  # True si seules les meilleures décisions ont été mises en concurrence
    p_best: np.ndarray               # par candidate (même ordre que les codes fournis)
    ci95: np.ndarray
    p5: np.ndarray                   # pour les top_k
    p50: np.ndarray
    p95: np.ndarray
    p_beats_first: np.ndarray        # pour les top_k
    option_in_best: np.ndarray       # par option
    fingerprint: str


def _bits(codes: np.ndarray, n: int) -> np.ndarray:
    return ((codes[:, None] >> np.arange(n, dtype=np.int64)) & 1).astype(np.float64)


def analyze(p: Problem, codes: np.ndarray, values: np.ndarray, top_k: int, scenarios: int, seed: int,
            max_candidates: int) -> Robustness:
    m = int(min(len(codes), max_candidates))
    k = int(min(top_k, m))
    codes, values = codes[:m], values[:m]
    B = _bits(codes, p.n)
    syn = values - B @ p.v                     # part déterministe (synergies)
    if not np.any(p.sd > 0):
        pb = np.zeros(m)
        pb[0] = 1.0
        vals = values[:k]
        return Robustness(True, 0, seed, m, m < len(codes), pb, np.zeros(m), vals, vals, vals,
                          np.zeros(k), B[0].copy(), _fp(pb, vals))
    rng = np.random.default_rng(seed)
    V = rng.standard_normal((scenarios, p.n)) * p.sd + p.v          # scénarios × options
    wins = np.zeros(m, dtype=np.int64)
    in_best = np.zeros(p.n)
    chunk = max(1, int(4_000_000 // max(m, 1)))
    for s in range(0, scenarios, chunk):
        sc = V[s:s + chunk]
        tot = B @ sc.T + syn[:, None]                                # candidates × scénarios
        w = np.argmax(tot, axis=0)                                   # 1re en cas d'égalité : ordre déterministe
        wins += np.bincount(w, minlength=m)
        in_best += B[w].sum(axis=0)
    pb = wins / scenarios
    ci = 1.96 * np.sqrt(pb * (1 - pb) / scenarios)
    T = B[:k] @ V.T + syn[:k, None]                                  # top_k × scénarios
    p5, p50, p95 = np.percentile(T, [5, 50, 95], axis=1)
    beats = (T > T[0]).mean(axis=1)
    return Robustness(False, scenarios, seed, m, m < len(codes), pb, ci, p5, p50, p95, beats,
                      in_best / scenarios, _fp(pb, p50))


def _fp(a, b) -> str:
    import hashlib
    return hashlib.sha256(np.round(np.concatenate([a, b]), 9).tobytes()).hexdigest()
