"""Contrôles de vérification. Chaque contrôle est daté dans le résultat, avec son statut :
  ok        : vérifié ;
  attention : non bloquant, à lire (ex. optimalité non prouvée faute de temps) ;
  echec     : bloquant — les résultats ne sont pas publiables ni réécrits dans TM1.
"""
from __future__ import annotations

import numpy as np

from .exact import Enumeration
from .problem import Problem, check_pure
from .quantum import QuantumOutcome
from .robustness import Robustness


def _c(cid, label, status, detail, blocking=True):
    return {"id": cid, "label": label, "status": status, "detail": detail, "blocking": blocking and status == "echec"}


def run_checks(p: Problem, en: Enumeration, cross: Enumeration | None, rob: Robustness, rob_again: Robustness | None,
               qo: QuantumOutcome, top_k: int) -> list[dict]:
    out = []
    # 1. complétude
    if en.method == "exhaustive":
        ok = en.combinations_examined == 2 ** p.n
        out.append(_c("enumeration_complete", "Toutes les combinaisons ont été examinées",
                      "ok" if ok else "echec", f"{en.combinations_examined:,} combinaisons sur 2^{p.n}".replace(",", " ")))
    else:
        out.append(_c("enumeration_complete", "Toutes les combinaisons ont été examinées", "attention",
                      f"{p.n} options : énumération complète impossible (2^{p.n}) ; les {en.feasible_count} meilleures "
                      "solutions ont été obtenues par programmation linéaire en nombres entiers", blocking=False))
    # 2. optimalité
    out.append(_c("optimality_proven", "Optimalité prouvée",
                  "ok" if en.proven_optimal else "attention",
                  "par énumération exhaustive" if en.method == "exhaustive" else
                  ("par le solveur MILP (écart d'optimalité nul)" if en.proven_optimal
                   else "limite de temps atteinte : meilleures solutions trouvées, optimalité non prouvée"),
                  blocking=False))
    # 3. vérificateur indépendant (Python pur) sur les solutions publiées et observées
    to_check = [(int(c), float(v)) for c, v in zip(en.codes[:max(top_k, 50)], en.values[:max(top_k, 50)])]
    bad = []
    for code, v in to_check:
        ok, viol, val, _ = check_pure(p, p.ids_of(code))
        if not ok or abs(val - v) > 1e-6 * max(1.0, abs(v)):
            bad.append(f"{p.ids_of(code)} : {viol or f'valeur {val} ≠ {v}'}")
    for d in qo.decisions:
        ok, _, val, _ = check_pure(p, p.ids_of(d["code"]))
        if ok != d["feasible"] or (ok and abs(val - d["value"]) > 1e-6 * max(1.0, abs(val))):
            bad.append(f"mesure quantique {p.ids_of(d['code'])} mal évaluée")
    out.append(_c("independent_check", "Recalcul indépendant (Python pur) des solutions publiées",
                  "ok" if not bad else "echec",
                  f"{len(to_check)} solutions classées et {len(qo.decisions)} décisions mesurées recalculées"
                  + (f" ; erreurs : {bad[:5]}" if bad else "")))
    # 4. accord entre méthodes exactes
    if cross is not None:
        k = min(len(cross.values), len(en.values))
        agree = k > 0 and np.allclose(cross.values[:k], en.values[:k], rtol=1e-9, atol=1e-6)
        out.append(_c("methods_agree", "Énumération et solveur MILP donnent le même classement",
                      "ok" if agree else "echec", f"{k} premiers rangs comparés"))
    # 5. probabilités
    sp = float(rob.p_best.sum()) if not rob.deterministic else 1.0
    out.append(_c("probabilities_sum", "Les probabilités « meilleure décision » totalisent 100 %",
                  "ok" if abs(sp - 1) < 1e-9 else "echec", f"somme = {sp:.12f}"))
    if rob_again is not None:
        same = rob_again.fingerprint == rob.fingerprint
        out.append(_c("reproducible", "Probabilités reproductibles (même graine, même résultat)",
                      "ok" if same else "echec", f"graine {rob.seed}, {rob.scenarios} scénarios"))
    if rob.truncated:
        out.append(_c("candidates_truncated", "Mise en concurrence de toutes les solutions", "attention",
                      f"les probabilités sont calculées parmi les {rob.candidates} meilleures solutions", blocking=False))
    # 6. quantique
    if qo.status == "ok":
        c = qo.checks
        if "ising_equals_qubo" in c:
            out.append(_c("ising_equals_qubo", "Hamiltonien d'Ising identique au QUBO sur tous les états",
                          "ok" if c["ising_equals_qubo"] else "echec",
                          f"écart maximal {c['ising_equals_qubo_max_abs_diff']:.2e} sur 2^{qo.qubits} états"))
        if "qubo_minimum_is_optimum" in c:
            if qo.formulation == "unbalanced-approx":
                st, det = "attention", ("formulation approchée (taille) : son minimum n'est pas la meilleure décision ; "
                                        "les mesures restent vérifiées une à une")
            elif c["qubo_minimum_is_optimum"]:
                st, det = "ok", ("garanti par construction et vérifié" if c.get("qubo_minimum_guaranteed")
                                 else f"vérifié sur tous les états (calibration λ = {qo.lambdas})")
            else:
                st, det = "attention", ("le minimum de la formulation ne correspond pas à l'optimum "
                                        "(discrétisation des coûts) : les mesures restent vérifiées une à une")
            out.append(_c("qubo_minimum", "Le minimum de la formulation quantique est la meilleure décision",
                          st, det, blocking=False))
        if "circuit_matches_simulation" in c:
            out.append(_c("circuit_matches", "Le circuit exporté réalise exactement le calcul simulé",
                          "ok" if c["circuit_matches_simulation"] else "echec",
                          f"simulation porte par porte, écart maximal {c['circuit_matches_simulation_max_abs_diff']:.2e}"))
        else:
            out.append(_c("circuit_matches", "Le circuit exporté réalise exactement le calcul simulé", "attention",
                          "contrôle porte par porte non effectué (taille du circuit)", blocking=False))
        out.append(_c("shots", "Toutes les mesures quantiques sont comptabilisées",
                      "ok" if c.get("counts_sum_equals_shots") else "echec",
                      f"{qo.metrics.get('shots_total')} mesures pour {qo.shots} demandées"))
    elif qo.status == "failed":
        out.append(_c("quantum_run", "Calcul quantique", "attention", qo.reason, blocking=False))
    return out
