"""Verrou exclusif par flux : deux exécutions concurrentes du même flux sont impossibles."""
from __future__ import annotations

import json
import os
import socket
from datetime import datetime, timezone
from pathlib import Path

from .errors import LockError


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


class FlowLock:
    def __init__(self, lock_dir: str | Path, flow_name: str, run_id: str):
        self.path = Path(lock_dir) / f"{flow_name}.lock"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.run_id = run_id

    def __enter__(self):
        payload = json.dumps({"run_id": self.run_id, "pid": os.getpid(), "host": socket.gethostname(),
                              "since": datetime.now(timezone.utc).isoformat()})
        for attempt in (1, 2):
            try:
                fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o640)
                with os.fdopen(fd, "w") as fh:
                    fh.write(payload)
                return self
            except FileExistsError:
                holder = self._read()
                same_host = holder.get("host") == socket.gethostname()
                if attempt == 1 and same_host and not _pid_alive(int(holder.get("pid", 0))):
                    self.path.unlink(missing_ok=True)  # verrou orphelin d'un processus mort
                    continue
                raise LockError(f"Flux déjà en cours d'exécution : {holder}. "
                                f"Si c'est un verrou orphelin sur un autre hôte, supprimez {self.path} "
                                "après vérification.")
        raise LockError("Impossible d'acquérir le verrou")

    def _read(self) -> dict:
        try:
            return json.loads(self.path.read_text())
        except Exception:
            return {}

    def __exit__(self, *exc):
        if self._read().get("run_id") == self.run_id:
            self.path.unlink(missing_ok=True)
        return False
