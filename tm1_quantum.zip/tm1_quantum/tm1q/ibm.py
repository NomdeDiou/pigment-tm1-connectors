"""Exécution du circuit sur IBM Quantum (Qiskit Runtime, primitive Sampler).

Envoyé hors de l'entreprise : uniquement le circuit OpenQASM (angles, indices de qubits).
Aucune donnée métier lisible. Activation explicite requise (quantum.allow_external: true),
jeton lu dans une variable d'environnement, approbation obligatoire en production.

NOTE : ce module n'a pas pu être exécuté contre IBM Quantum lors du développement
(Qiskit indisponible dans l'environnement de construction). Le circuit qu'il soumet,
lui, est vérifié : il est simulé porte par porte et comparé au simulateur rapide.
À valider sur votre compte IBM Quantum avant usage en production.
"""
from __future__ import annotations

from .config import IBMConf
from .errors import LoadError
from .secrets import get_secret


def run_on_ibm(qasm: str, shots: int, conf: IBMConf, seed: int) -> tuple[dict[int, int], dict]:
    try:
        from qiskit import qasm2
        from qiskit.transpiler.preset_passmanagers import generate_preset_pass_manager
        from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2
    except ImportError as exc:
        raise LoadError("Qiskit non installé : pip install qiskit qiskit-ibm-runtime") from exc

    circuit = qasm2.loads(qasm, custom_instructions=qasm2.LEGACY_CUSTOM_INSTRUCTIONS)
    service = QiskitRuntimeService(channel=conf.channel, token=get_secret(conf.token_env), instance=conf.instance)
    backend = (service.backend(conf.backend_name) if conf.backend_name
               else service.least_busy(operational=True, simulator=False, min_num_qubits=circuit.num_qubits))
    pm = generate_preset_pass_manager(optimization_level=conf.optimization_level, backend=backend,
                                      seed_transpiler=seed)
    isa = pm.run(circuit)
    job = SamplerV2(mode=backend).run([isa], shots=shots)
    result = job.result()
    creg = circuit.cregs[0].name
    raw = getattr(result[0].data, creg).get_counts()
    # chaîne Qiskit : qubit 0 à droite -> int(bitstring, 2) donne bit i = qubit i (même convention que le simulateur)
    counts = {int(bits.replace(" ", ""), 2): int(c) for bits, c in raw.items()}
    meta = {"backend": backend.name, "job_id": job.job_id(), "transpiled_depth": isa.depth(),
            "transpiled_two_qubit_gates": int(sum(v for k, v in isa.count_ops().items() if k in ("cx", "cz", "ecr")))}
    return counts, meta
