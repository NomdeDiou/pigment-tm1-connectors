"""Connecteur d'aide à la décision TM1 / Planning Analytics <-> calcul quantique.

Lit un problème de décision dans TM1 (ex. quels projets financer sous contraintes),
calcule TOUTES les solutions admissibles (ou les K meilleures, avec preuve d'optimalité),
les classe, estime pour chacune la probabilité d'être le meilleur choix compte tenu des
incertitudes, fait résoudre le même problème par un algorithme quantique (QAOA, simulé
localement ou exécuté sur IBM Quantum), vérifie tout de façon indépendante, explique le
résultat en français dans un rapport lisible, puis — après approbation humaine — réécrit
la décision retenue dans TM1, avec relecture et réconciliation.
"""

__version__ = "1.0.0"
