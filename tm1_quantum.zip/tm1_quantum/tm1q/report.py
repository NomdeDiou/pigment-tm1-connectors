"""Rapport HTML autonome (aucune ressource externe, aucun script), en français, imprimable.

Toutes les données affichées sont échappées : libellés venant de TM1 ou d'un CSV ne peuvent
pas injecter de code dans le rapport.
"""
from __future__ import annotations

from html import escape as e

from .insights import money, num, pct

CSS = """
:root{--bg:#fbfaf7;--fg:#1d2024;--muted:#5d6670;--line:#e3e0d8;--card:#fff;--accent:#1f5f8b;--ok:#2e7d4f;
--warn:#a46a00;--bad:#b3261e;--bar:#1f5f8b;--q:#6b4fa3}
@media (prefers-color-scheme:dark){:root{--bg:#15171a;--fg:#e8e6e1;--muted:#a3abb4;--line:#2c3036;--card:#1d2024;
--accent:#7fb6dc;--ok:#6cc08f;--warn:#e0b050;--bad:#f08a80;--bar:#7fb6dc;--q:#b49be6}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);
font:15px/1.55 -apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif}
main{max-width:1080px;margin:0 auto;padding:32px 20px 64px}
h1{font-size:26px;margin:0 0 4px;letter-spacing:-.01em}h2{font-size:19px;margin:40px 0 12px;
padding-bottom:6px;border-bottom:1px solid var(--line)}h3{font-size:15px;margin:0 0 4px}
.meta{color:var(--muted);font-size:13px}.card{background:var(--card);border:1px solid var(--line);
border-radius:10px;padding:18px 20px;margin:12px 0}.lead{border-left:4px solid var(--accent)}
.lead p.reco{font-size:18px;font-weight:600;margin:4px 0 8px}.badge{display:inline-block;padding:2px 10px;
border-radius:99px;font-size:12px;font-weight:600;border:1px solid currentColor;margin-right:6px}
.ok{color:var(--ok)}.warn{color:var(--warn)}.bad{color:var(--bad)}.q{color:var(--q)}
.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}
.tile{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
.tile b{display:block;font-size:22px}.tile span{color:var(--muted);font-size:13px}
.msg{border-left:4px solid var(--line)}.msg.attention{border-left-color:var(--warn)}
.card>p:first-child,.card>h3:first-child{margin-top:0}.msg.alternative{border-left-color:var(--accent)}.msg.quantum{border-left-color:var(--q)}.msg p{margin:2px 0 0}
.tw{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:14px}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top}
th{font-size:12px;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);font-weight:600}
td.n{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}
.bar{height:8px;background:var(--line);border-radius:4px;min-width:90px;margin-top:4px}
.bar i{display:block;height:8px;background:var(--bar);border-radius:4px}
.small{font-size:13px;color:var(--muted)}code{font-size:12.5px;word-break:break-all}
ul.diff{margin:0;padding-left:18px}footer{margin-top:48px;color:var(--muted);font-size:12px}
@media print{body{background:#fff}.card,.tile{break-inside:avoid}}
"""


def _bar(p: float | None) -> str:
    w = 0 if p is None else max(0.0, min(1.0, p)) * 100
    return f'<div class="bar" aria-hidden="true"><i style="width:{w:.1f}%"></i></div>'


def render(result: dict) -> str:
    cur = result["problem"]["currency"]
    ins = result["insights"]
    rk = result["ranking"]
    rob = result["robustness"]
    ex = result["exact"]
    q = result["quantum"]
    label = {o["id"]: o["label"] for o in result["options"]}
    res = result["problem"]["resources"]
    checks = result["checks"]
    n_fail = sum(1 for c in checks if c["status"] == "echec")
    n_warn = sum(1 for c in checks if c["status"] == "attention")
    h = []
    a = h.append
    a(f'<!doctype html><html lang="fr"><head><meta charset="utf-8">'
      f'<meta name="viewport" content="width=device-width,initial-scale=1">'
      f'<title>Aide à la décision — {e(result["decision"])}</title><style>{CSS}</style></head><body><main>')
    a(f'<h1>{e(result["description"] or result["decision"])}</h1>')
    a(f'<div class="meta">Analyse {e(result["run_id"])} · {e(result["generated_at"])} · responsable '
      f'{e(result["owner"])} · environnement {e(result["environment"])} · source {e(result["source"]["kind"])}</div>')

    # ---------------------------------------------------------------- en bref
    vbadge = ('<span class="badge bad">Contrôles en échec : résultats non publiables</span>' if n_fail else
              '<span class="badge ok">Tous les contrôles bloquants sont passés</span>')
    if n_warn:
        vbadge += f'<span class="badge warn">{n_warn} point(s) d\'attention</span>'
    a('<div class="card lead"><h3>En bref</h3>')
    a(f'<p class="reco">{e(ins["recommendation"])}</p>')
    a(f'<p>Confiance <b>{e(ins["confidence"])}</b> : {e(ins["confidence_text"])}.</p>{vbadge}</div>')

    a('<div class="tiles">')
    a(f'<div class="tile"><b>{num(ex["combinations_examined"]) if ex["method"] == "exhaustive" else "MILP"}</b>'
      f'<span>{"combinaisons examinées, toutes" if ex["method"] == "exhaustive" else "solveur exact (trop de combinaisons pour tout énumérer)"}</span></div>')
    a(f'<div class="tile"><b>{num(ex["feasible_count"])}</b><span>'
      f'{"décisions respectent toutes les contraintes" if ex["complete"] else "meilleures décisions prouvées"}</span></div>')
    a(f'<div class="tile"><b>{money(rk[0]["value"], cur)}</b><span>valeur attendue de la n°1</span></div>')
    if not rob["deterministic"]:
        a(f'<div class="tile"><b>{pct(rk[0]["p_best"])}</b><span>probabilité que la n°1 soit le meilleur choix</span></div>')
    a('</div>')

    if ins["messages"]:
        a('<h2>À retenir</h2>')
        for m in ins["messages"]:
            a(f'<div class="card msg {e(m["kind"])}"><h3>{e(m["title"])}</h3><p>{e(m["text"])}</p></div>')

    # ---------------------------------------------------------------- classement
    a(f'<h2>Les {len(rk)} meilleures décisions</h2>')
    a('<p class="small">Classées par valeur attendue. « Meilleur choix » : part des scénarios simulés où la décision '
      'est la meilleure de toutes les décisions admissibles. Fourchette : 90 % des scénarios tombent entre P5 et P95.</p>')
    a('<div class="tw"><table><thead><tr><th>Rang</th><th>Options retenues</th><th>Valeur attendue</th>'
      '<th>Écart / n°1</th><th>Meilleur choix</th><th>Fourchette P5 – P95</th><th>Ressources</th>'
      '<th>Mesures quantiques</th></tr></thead><tbody>')
    for s in rk:
        usage = "<br>".join(f'{e(r["label"])} {pct(s["usage"][r["name"]]["pct"], 0)}' for r in res)
        qf = "—" if s.get("quantum_frequency") is None else pct(s["quantum_frequency"], 2)
        pb = "—" if rob["deterministic"] else f'{pct(s["p_best"])} <span class="small">± {pct(s["ci95"])}</span>{_bar(s["p_best"])}'
        rng = "—" if rob["deterministic"] else f'{money(s["p5"], cur)} – {money(s["p95"], cur)}'
        gap = "—" if s["rank"] == 1 else f'{num(s["gap_pct"], 2)} %'
        a(f'<tr><td class="n">{s["rank"]}{" <span class=small>ex æquo</span>" if s["tie"] else ""}</td>'
          f'<td>{e(", ".join(label[o] for o in s["options"]))}</td><td class="n">{money(s["value"], cur)}</td>'
          f'<td class="n">{gap}</td><td>{pb}</td><td class="n">{rng}</td><td class="small">{usage}</td>'
          f'<td class="n">{qf}</td></tr>')
    a('</tbody></table></div>')

    if len(rk) > 1:
        a('<h2>Ce qui distingue chaque alternative de la n°1</h2><div class="card"><ul class="diff">')
        for s in rk[1:]:
            parts = []
            if s["diff_vs_first"]["added"]:
                parts.append("ajoute " + ", ".join(label[o] for o in s["diff_vs_first"]["added"]))
            if s["diff_vs_first"]["removed"]:
                parts.append("retire " + ", ".join(label[o] for o in s["diff_vs_first"]["removed"]))
            beat = "" if rob["deterministic"] else f' ; fait mieux que la n°1 dans {pct(s["p_beats_first"])} des scénarios'
            delta = money(s["value"] - rk[0]["value"], cur).replace("-", "−")
            a(f'<li><b>n°{s["rank"]}</b> : {e(" ; ".join(parts))} (écart {delta}){beat}</li>')
        a('</ul></div>')

    if not rob["deterministic"] and result["by_probability"]:
        a('<h2>Classement par probabilité d\'être le meilleur choix</h2><div class="tw"><table><thead><tr>'
          '<th>Probabilité</th><th>Rang (valeur)</th><th>Options retenues</th><th>Valeur attendue</th></tr></thead><tbody>')
        for s in result["by_probability"]:
            a(f'<tr><td>{pct(s["p_best"])}{_bar(s["p_best"])}</td><td class="n">{s["rank"]}</td>'
              f'<td>{e(", ".join(label[o] for o in s["options"]))}</td><td class="n">{money(s["value"], cur)}</td></tr>')
        a('</tbody></table></div>')

    # ---------------------------------------------------------------- options
    a('<h2>Les options une par une</h2><div class="tw"><table><thead><tr><th>Option</th><th>Valeur</th>'
      '<th>Incertitude (σ)</th>' + "".join(f'<th>{e(r["label"])}</th>' for r in res) +
      '<th>Dans la n°1</th><th>Présente dans la meilleure décision</th></tr></thead><tbody>')
    for o in result["options"]:
        rules = []
        if o["id"] in result["problem"]["rules"]["mandatory"]:
            rules.append("obligatoire")
        if o["id"] in result["problem"]["rules"]["forbidden"]:
            rules.append("interdite")
        tag = f' <span class="small">({", ".join(rules)})</span>' if rules else ""
        pin = "—" if rob["deterministic"] else f'{pct(o["p_in_best"])}{_bar(o["p_in_best"])}'
        a(f'<tr><td>{e(o["label"])}{tag}</td><td class="n">{money(o["value"], cur)}</td>'
          f'<td class="n">{money(o["stdev"], cur)}</td>'
          + "".join(f'<td class="n">{num(o["costs"][r["name"]], 0)}</td>' for r in res)
          + f'<td>{"oui" if o["in_first"] else ""}</td><td>{pin}</td></tr>')
    a('</tbody></table></div>')
    caps = " · ".join(f'{e(r["label"])} : {num(r["capacity"], 0)}' for r in res)
    a(f'<p class="small">Capacités : {caps}. Toutes les solutions admissibles sont exportées dans '
      f'<code>{e(ex.get("export_file") or "—")}</code> ({num(ex.get("exported_rows") or 0)} lignes).</p>')

    # ---------------------------------------------------------------- quantique
    a('<h2>Le calcul quantique</h2>')
    if q["status"] != "ok":
        a(f'<div class="card"><p>Non exécuté : {e(q["reason"])}.</p></div>')
    else:
        m = q["metrics"]
        a('<div class="card"><p>Le même problème a été traduit en <b>énergie à minimiser</b> (Hamiltonien d\'Ising) : '
          'les meilleures décisions correspondent aux énergies les plus basses. L\'algorithme <b>QAOA</b> prépare un état '
          'quantique où ces décisions ont plus de chances d\'être mesurées, puis on mesure de nombreuses fois. '
          'Chaque mesure est ensuite <b>vérifiée classiquement</b> : une proposition du calcul quantique n\'est jamais '
          'acceptée sans contrôle.</p>')
        a(f'<p class="small">Machine : {e(str(q["backend_meta"].get("backend", q["backend"])))} · formulation '
          f'{e(q["formulation"])}{" (λ = " + e(str(tuple(q["lambdas"]))) + ")" if q["lambdas"] else ""} · '
          f'{q["qubits"]} qubits ({q["slack_qubits"]} d\'écart) · {q["layers"]} couches · {num(q["shots"])} mesures · '
          f'{num(m["circuit_two_qubit_gates"])} portes à deux qubits · angles {e(q["angles_source"])}.</p>')
        a('<p class="small"><b>Attention à la lecture :</b> la fréquence quantique dit à quel point l\'algorithme '
          '« trouve » une décision ; ce n\'est pas une probabilité de réussite métier. La probabilité d\'être le '
          'meilleur choix figure dans le classement ci-dessus.</p></div>')
        a('<div class="tiles">')
        a(f'<div class="tile"><b>{pct(m["feasible_frequency"])}</b><span>des mesures respectent les contraintes '
          f'(hasard : {pct(m.get("uniform_feasible_share"))})</span></div>')
        a(f'<div class="tile"><b>{pct(m["optimum_frequency"], 2)}</b><span>des mesures donnent la meilleure décision '
          f'(hasard : {pct(m.get("uniform_optimum_share"), 2)})</span></div>')
        a(f'<div class="tile"><b>{num(m["top10_enrichment"], 1) + " ×" if m.get("top10_enrichment") else "—"}</b>'
          f'<span>plus souvent qu\'au hasard pour les 10 meilleures</span></div>')
        a(f'<div class="tile"><b>{"n°" + str(m["best_observed_rank"]) if m["best_observed_rank"] else "—"}</b>'
          f'<span>meilleure décision mesurée</span></div></div>')
        a('<div class="tw"><table><thead><tr><th>Fréquence</th><th>Décision mesurée</th><th>Admissible</th>'
          '<th>Rang exact</th><th>Valeur</th></tr></thead><tbody>')
        a(f'<p class="small" style="margin-top:20px">Les 10 décisions les plus souvent mesurées '
          f'(sur {num(m["distinct_decisions"])} ; liste complète dans <code>mesures_quantiques.csv</code>) :</p>')
        for d in q["top_decisions"][:10]:
            a(f'<tr><td class="n">{pct(d["frequency"], 2)}</td><td>{e(", ".join(label[o] for o in d["options"]) or "aucune option")}</td>'
              f'<td>{"oui" if d["feasible"] else "<span class=bad>non</span>"}</td>'
              f'<td class="n">{d["exact_rank"] or "—"}</td><td class="n">{money(d["value"], cur) if d["feasible"] else "—"}</td></tr>')
        a('</tbody></table></div>')
        a(f'<p class="small">Circuit conservé : <code>circuit.qasm</code> (OpenQASM 2.0, SHA-256 {e(q["qasm_sha256"])}). '
          'C\'est la seule donnée qui quitterait l\'entreprise vers une machine externe : des angles et des numéros de '
          'qubits, sans libellé ni montant.</p>')
        for note in q["notes"]:
            a(f'<p class="small">{e(note)}</p>')

    # ---------------------------------------------------------------- vérifications
    a('<h2>Vérifications</h2><div class="tw"><table><thead><tr><th></th><th>Contrôle</th><th>Détail</th></tr></thead><tbody>')
    sym = {"ok": '<span class="ok">✔</span>', "attention": '<span class="warn">⚠</span>', "echec": '<span class="bad">✖</span>'}
    for c in checks:
        a(f'<tr><td>{sym[c["status"]]}</td><td>{e(c["label"])}</td><td class="small">{e(c["detail"])}</td></tr>')
    a('</tbody></table></div>')

    # ---------------------------------------------------------------- hypothèses
    a('<h2>Hypothèses et limites</h2><div class="card"><ul>')
    a('<li>La valeur d\'une décision est la somme des valeurs des options retenues, plus les synergies déclarées.</li>')
    if not rob["deterministic"]:
        a(f'<li>Incertitudes : chaque valeur suit une loi normale indépendante (moyenne et écart-type fournis) ; '
          f'{num(rob["scenarios"])} scénarios, graine {rob["seed"]}. Les corrélations entre options ne sont pas modélisées.</li>')
        if rob["truncated"]:
            a(f'<li>Les probabilités sont calculées parmi les {num(rob["candidates"])} meilleures décisions.</li>')
    a('<li>Coûts et capacités sont considérés comme certains.</li>')
    a('<li>Le calcul quantique ne remplace pas le calcul exact : aujourd\'hui, il est mesuré contre lui. '
      'Son intérêt est de préparer l\'organisation et de comparer, à chaque analyse, ce qu\'il apporte.</li>')
    a('<li>Ce rapport éclaire une décision ; il ne la prend pas. Les critères non chiffrés restent à apprécier.</li>')
    a('</ul></div>')

    a('<h2>Prochaine étape</h2><div class="card">')
    if n_fail:
        a('<p>Des contrôles bloquants ont échoué : la réécriture dans TM1 est impossible pour cette analyse.</p>')
    elif result["source"]["kind"] != "tm1":
        a('<p>Analyse réalisée sur un fichier : elle sert à simuler. Relancez-la sur les données TM1 pour pouvoir '
          'réécrire la décision.</p>')
    else:
        a(f'<p>Après revue, la décision retenue peut être réécrite dans TM1 par une personne habilitée :</p>'
          f'<p><code>python -m tm1q -c &lt;config&gt; writeback {e(result["decision"])} --run-id {e(result["run_id"])} '
          f'--ranks 1 --approved-by &lt;nom&gt; --ticket &lt;réf&gt;</code></p>'
          '<p class="small">La réécriture refuse de s\'exécuter si les données TM1 ont changé depuis cette analyse, '
          'si ce rapport a été modifié ou si le journal d\'audit a été altéré.</p>')
    a('</div>')
    a(f'<footer>Empreinte du problème {e(result["problem_fingerprint"])} · configuration {e(result["config_sha256"])} · '
      f'opérateur {e(result["operator"])}</footer></main></body></html>')
    return "".join(h)
