"""QAOA (Quantum Approximate Optimization Algorithm) : optimisation des angles et échantillonnage.

Simulateur à vecteur d'état exact (numpy) : l'opérateur de coût est diagonal, on l'applique
en une multiplication ; le mélangeur RX est appliqué qubit par qubit. Les angles sont
optimisés sur la CVaR (moyenne des α % meilleurs résultats), plus efficace que l'énergie
moyenne pour faire ressortir les bonnes solutions. Tout est déterministe (graines fixées).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import minimize


@dataclass
class QaoaRun:
    layers: int
    gammas: list[float]
    betas: list[float]
    energy_min: float
    energy_scale: float
    cvar: float
    evaluations: int
    restarts: list[dict] = field(default_factory=list)
    probs: np.ndarray | None = None            # distribution exacte du simulateur (non échantillonnée)


def _evolve(es: np.ndarray, gammas, betas, n: int) -> np.ndarray:
    state = np.full(es.shape, 1 / np.sqrt(es.size), dtype=np.complex128)
    for g, b in zip(gammas, betas):
        state *= np.exp(-1j * g * es)
        c, s = np.cos(b), -1j * np.sin(b)
        for q in range(n):
            v = state.reshape(-1, 2, 1 << q)
            a0, a1 = v[:, 0, :].copy(), v[:, 1, :]
            v[:, 0, :] = c * a0 + s * a1
            v[:, 1, :] = s * a0 + c * a1
    return state


def _cvar(probs: np.ndarray, es_sorted: np.ndarray, order: np.ndarray, alpha: float) -> float:
    p = probs[order]
    cum = np.cumsum(p)
    k = int(np.searchsorted(cum, alpha))
    k = min(k, len(p) - 1)
    mass_before = cum[k - 1] if k > 0 else 0.0
    tot = float(np.dot(p[:k], es_sorted[:k]) + (alpha - mass_before) * es_sorted[k])
    return tot / alpha


def evolve_probs(energies: np.ndarray, gammas, betas, energy_min: float, energy_scale: float) -> np.ndarray:
    n = int(np.log2(energies.size))
    es = (energies - energy_min) / energy_scale
    return np.abs(_evolve(es, gammas, betas, n)) ** 2


def energy_scale_of(energies: np.ndarray) -> float:
    s = float(np.std(energies))
    return s if s > 0 else 1.0


def optimize(energies: np.ndarray, layers: int, restarts: int, alpha: float, seed: int) -> QaoaRun:
    n = int(np.log2(energies.size))
    emin = float(energies.min())
    scale = energy_scale_of(energies)
    es = (energies - emin) / scale
    order = np.argsort(es, kind="stable")
    es_sorted = es[order]
    rng = np.random.default_rng(seed)
    evals = 0

    def f(theta):
        nonlocal evals
        evals += 1
        st = _evolve(es, theta[:layers], theta[layers:], n)
        return _cvar(np.abs(st) ** 2, es_sorted, order, alpha)

    # départ 1 : rampe linéaire (heuristique connue, proche d'un recuit adiabatique) ; puis départs aléatoires
    starts = [np.concatenate([(np.arange(layers) + 0.5) / layers * 0.8,
                              (1 - (np.arange(layers) + 0.5) / layers) * 0.8])]
    for _ in range(max(0, restarts - 1)):
        starts.append(np.concatenate([rng.uniform(0, 2 * np.pi, layers), rng.uniform(0, np.pi / 2, layers)]))
    # budget adapté à la taille : le coût d'une évaluation double à chaque qubit
    per = 150 if n <= 14 else 80 if n <= 17 else 40
    if n > 17:
        starts = starts[:2]
    best, hist = None, []
    for x0 in starts:
        res = minimize(f, x0, method="COBYLA", options={"maxiter": per * layers, "rhobeg": 0.3})
        hist.append({"start": [float(v) for v in x0], "cvar": float(res.fun), "angles": [float(v) for v in res.x]})
        if best is None or res.fun < best.fun:
            best = res
    g, b = list(map(float, best.x[:layers])), list(map(float, best.x[layers:]))
    probs = np.abs(_evolve(es, g, b, n)) ** 2
    return QaoaRun(layers, g, b, emin, scale, float(best.fun), evals, hist, probs)


def sample(probs: np.ndarray, shots: int, seed: int) -> dict[int, int]:
    """Mesures simulées : tirage multinomial reproductible (graine)."""
    rng = np.random.default_rng(seed)
    p = probs / probs.sum()
    counts = rng.multinomial(shots, p)
    nz = np.nonzero(counts)[0]
    return {int(i): int(counts[i]) for i in nz}
