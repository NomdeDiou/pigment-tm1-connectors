"""Ligne de commande.

  python -m tm1q -c config/decision.yaml list
  python -m tm1q -c config/decision.yaml validate-config
  python -m tm1q -c config/decision.yaml analyze portefeuille_2027 [--input examples/projets_demo.csv]
  python -m tm1q -c config/decision.yaml writeback portefeuille_2027 --run-id <id> --ranks 1 \\
         --approved-by j.martin --ticket CHG-1234
  python -m tm1q -c config/decision.yaml verify-audit

Codes de sortie : 0 succès ; 2 config ; 3 secret ; 4 données ; 5 gouvernance ; 6 chargement ;
7 réconciliation (état restauré) ; 8 verrou ; 9 restauration échouée (CRITIQUE) ;
10 audit altéré ; 11 vérification en échec ; 12 aucune solution admissible.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys

from .audit import AuditLog
from .config import load_config
from .engine import Engine, RunOptions
from .errors import ConnectorError
from .insights import money, num, pct
from .secrets import RedactingFilter, get_secret


def _setup_logging(level: str):
    h = logging.StreamHandler(sys.stderr)
    h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    h.addFilter(RedactingFilter())
    logging.basicConfig(level=level, handlers=[h], force=True)


def _summary(r: dict) -> str:
    cur = r["problem"]["currency"]
    label = {o["id"]: o["label"] for o in r["options"]}
    lines = [f"\n{r['insights']['recommendation']}",
             f"Confiance {r['insights']['confidence']} : {r['insights']['confidence_text']}.", ""]
    det = r["robustness"]["deterministic"]
    lines.append(f"{'Rang':>4}  {'Valeur':>12}  {'Meilleur choix':>14}  Options")
    for s in r["ranking"][:10]:
        pb = "—" if det else pct(s["p_best"])
        lines.append(f"{s['rank']:>4}  {money(s['value'], cur):>12}  {pb:>14}  "
                     + ", ".join(label[o] for o in s["options"]))
    ex = r["exact"]
    lines.append("")
    if ex["method"] == "exhaustive":
        lines.append(f"{ex['combinations_examined']:,} combinaisons examinées ; ".replace(",", " ")
                     + f"{ex['feasible_count']:,} admissibles.".replace(",", " "))
    else:
        lines.append(f"{ex['feasible_count']} meilleures décisions prouvées par MILP.")
    q = r["quantum"]
    if q["status"] == "ok":
        m = q["metrics"]
        lines.append(f"Quantique : {q['qubits']} qubits, optimum observé dans {pct(m['optimum_frequency'], 2)} "
                     f"des mesures, top 10 ×{num(m['top10_enrichment'], 1)} vs hasard." if m.get("top10_enrichment")
                     else f"Quantique : {q['qubits']} qubits, meilleure décision mesurée n°{m['best_observed_rank']}.")
    else:
        lines.append(f"Quantique : {q['reason']}")
    fails = [c for c in r["checks"] if c["status"] != "ok"]
    lines.append(f"Vérifications : {len(r['checks']) - len(fails)}/{len(r['checks'])} ok"
                 + (f" ({len(fails)} à lire)" if fails else ""))
    lines.append(f"Rapport : {r.get('_evidence_dir', '')}/rapport.html")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="tm1q", description="Aide à la décision TM1 <-> calcul quantique")
    ap.add_argument("-c", "--config", default="config/decision.yaml")
    ap.add_argument("--log-level", default="WARNING")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    sub.add_parser("validate-config")
    sub.add_parser("verify-audit")
    a = sub.add_parser("analyze", help="calculer, vérifier et produire le rapport (aucune écriture TM1)")
    a.add_argument("decision")
    a.add_argument("--input", help="fichier CSV au lieu de TM1 (simulation)")
    a.add_argument("--approved-by", help="requis pour envoyer le circuit vers IBM Quantum")
    a.add_argument("--ticket")
    a.add_argument("--operator")
    a.add_argument("--json", action="store_true", help="afficher le résultat complet en JSON")
    w = sub.add_parser("writeback", help="réécrire dans TM1 une analyse vérifiée, après approbation")
    w.add_argument("decision")
    w.add_argument("--run-id", required=True)
    w.add_argument("--ranks", type=int, default=1)
    w.add_argument("--approved-by")
    w.add_argument("--ticket")
    w.add_argument("--operator")
    args = ap.parse_args(argv)
    _setup_logging(args.log_level)
    try:
        conf, h = load_config(args.config)
        if args.cmd == "list":
            for d in conf.decisions:
                print(f"{d.name:32s} owner={d.owner:20s} quantique={d.quantum.backend if d.quantum.enabled else 'non'}")
            return 0
        if args.cmd == "validate-config":
            print(json.dumps({"ok": True, "config_sha256": h, "decisions": [d.name for d in conf.decisions]}, indent=2))
            return 0
        if args.cmd == "verify-audit":
            key = None
            if conf.runtime.audit_hmac_key_env:
                try:
                    key = get_secret(conf.runtime.audit_hmac_key_env)
                except ConnectorError:
                    pass
            ok, n, msg = AuditLog(conf.runtime.audit_log, key).verify()
            print(json.dumps({"ok": ok, "records": n, "message": msg}, ensure_ascii=False))
            return 0 if ok else 10
        eng = Engine(conf, h)
        opts = RunOptions(args.approved_by, args.ticket, args.operator)
        if args.cmd == "analyze":
            r = eng.analyze(args.decision, args.input, opts)
            print(json.dumps(r, indent=2, ensure_ascii=False, default=str) if args.json else _summary(r))
            return 0
        out = eng.writeback(args.decision, args.run_id, args.ranks, opts)
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0
    except ConnectorError as exc:
        log = logging.getLogger("tm1q")
        print(f"{type(exc).__name__} : {exc}", file=sys.stderr)
        for i in getattr(exc, "issues", []):
            print(f"  - {i}", file=sys.stderr)
        log.debug("détail", exc_info=True)
        return exc.exit_code


if __name__ == "__main__":
    sys.exit(main())
