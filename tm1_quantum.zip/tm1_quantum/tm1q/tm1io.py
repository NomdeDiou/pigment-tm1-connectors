"""Lecture du problème dans TM1 et réécriture vérifiée de la décision.

Lecture : un cube « options × mesures » (+ dimensions fixées) donne valeur, écart-type et coûts.
Écriture : un cube « rang × option × mesure » (+ dimensions fixées) reçoit, pour chaque rang
retenu, 1 sur les options sélectionnées et les indicateurs sur un élément de synthèse.
L'écriture est atomique (sandbox, sinon sauvegarde + restauration), relue et réconciliée.
"""
from __future__ import annotations

import logging

import pandas as pd

from .config import DecisionConf
from .errors import ConfigError, LoadError, ReconciliationError, RollbackError, ValidationError

log = logging.getLogger(__name__)
METRICS = {"expected_value", "p_best_pct", "p5", "p50", "p95", "gap_pct", "quantum_frequency_pct", "rank_value"}


def _norm(s: str) -> str:
    return str(s).lower().replace(" ", "")


def _check_dims(dims: list[str], expected: set[str], cube: str):
    missing, extra = set(dims) - expected, expected - set(dims)
    if missing or extra:
        raise ConfigError(f"Cube {cube} : dimensions non couvertes {sorted(missing)}, inconnues {sorted(extra)} "
                          "(chaque dimension doit être fixée ou décrite)")


# ---------------------------------------------------------------- lecture
def read_problem_table(tm1, dec: DecisionConf) -> tuple[pd.DataFrame, dict[str, float]]:
    s = dec.source
    dims = tm1.cube_dimensions(s.cube)
    _check_dims(dims, set(s.fixed) | {s.options_dimension, s.measures_dimension}, s.cube)
    res_measure = {r: (rc.measure or r) for r, rc in dec.resources.items()}
    measures = [s.value_measure] + ([s.stdev_measure] if s.stdev_measure else []) + list(res_measure.values())
    scope = {d: [e] for d, e in s.fixed.items()}
    scope[s.measures_dimension] = measures
    if s.options:
        scope[s.options_dimension] = list(s.options)
    df = tm1.read(s.cube, scope)
    if df is None or df.empty:
        raise ValidationError("Aucune donnée lue dans TM1 pour ce périmètre", [str(scope)])
    piv = df.pivot_table(index=s.options_dimension, columns=s.measures_dimension, values="Value",
                         aggfunc="sum").reindex(columns=measures)
    if s.options:
        lk = {_norm(i): i for i in piv.index}
        piv = piv.reindex([lk.get(_norm(o), o) for o in s.options])
    table = pd.DataFrame({
        "id": [str(i) for i in piv.index],
        "label": [s.labels.get(str(i), str(i)) for i in piv.index],
        "value": piv[s.value_measure].fillna(0.0).to_numpy(),
        "stdev": (piv[s.stdev_measure].fillna(0.0).to_numpy() if s.stdev_measure else 0.0),
    })
    for r, m in res_measure.items():
        table[r] = piv[m].fillna(0.0).to_numpy()
    caps = {}
    for r, rc in dec.resources.items():
        if rc.capacity is not None:
            caps[r] = float(rc.capacity)
            continue
        ref = rc.capacity_from
        cdims = tm1.cube_dimensions(ref.cube)
        _check_dims(cdims, set(ref.coordinates), ref.cube)
        cell = tm1.read(ref.cube, {d: [e] for d, e in ref.coordinates.items()})
        if cell is None or cell.empty:
            raise ValidationError(f"Capacité {r} : cellule TM1 vide", [str(ref.coordinates)])
        caps[r] = float(cell["Value"].sum())
    return table, caps


# ---------------------------------------------------------------- écriture
def _canon(df: pd.DataFrame, keys: list[str]) -> dict[tuple, float]:
    if df is None or df.empty:
        return {}
    return {tuple(str(r[k]) for k in keys): float(r["Value"]) for _, r in df.iterrows() if float(r["Value"]) != 0}


def _diff(expected: dict, actual: dict, tol: float = 1e-6) -> list[str]:
    out = []
    for k, v in expected.items():
        a = actual.get(k)
        if a is None or abs(a - v) > tol * max(1.0, abs(v)):
            out.append(f"{k}: attendu {v}, lu {a}")
    for k in actual.keys() - expected.keys():
        out.append(f"{k}: inattendu {actual[k]}")
    return out


def build_writeback(dec: DecisionConf, result: dict, ranks: int, leaves: dict[str, list[str]]) -> tuple[pd.DataFrame, dict]:
    wb = dec.writeback
    if wb is None:
        raise ConfigError("Aucune section writeback pour cette décision")
    if ranks < 1 or ranks > min(len(wb.rank_elements), len(result["ranking"])):
        raise ValidationError(f"Nombre de rangs à écrire invalide : {ranks}", [])
    unknown_metrics = set(wb.metric_measures) - METRICS
    if unknown_metrics:
        raise ConfigError(f"Indicateurs inconnus : {sorted(unknown_metrics)} (autorisés : {sorted(METRICS)})")
    option_ids = [o["id"] for o in result["options"]]
    opt_elems = option_ids + ([wb.metrics_option] if wb.metrics_option and wb.metric_measures else [])
    measures = [wb.selected_measure] + list(wb.metric_measures.values())
    issues = []

    def exists(dim, elems):
        lk = {_norm(e): e for e in leaves[dim]}
        exact = []
        for e in elems:
            if _norm(e) not in lk:
                issues.append(f"{dim} : élément {e} inexistant ou non-feuille")
            exact.append(lk.get(_norm(e), e))
        return exact

    rank_el = exists(wb.rank_dimension, wb.rank_elements[:ranks])
    opt_el = exists(wb.option_dimension, opt_elems)
    meas_el = exists(wb.measure_dimension, measures)
    fixed = {d: exists(d, [e])[0] for d, e in wb.fixed.items()}
    if issues:
        raise ValidationError("Cible de réécriture incohérente avec TM1", issues)
    opt_map = dict(zip(opt_elems, opt_el))
    meas_map = dict(zip(measures, meas_el))
    rows = []
    for r in range(ranks):
        sol = result["ranking"][r]
        for oid in sol["options"]:
            rows.append({**fixed, wb.rank_dimension: rank_el[r], wb.option_dimension: opt_map[oid],
                         wb.measure_dimension: meas_map[wb.selected_measure], "Value": 1.0})
        if wb.metrics_option:
            metric_values = {
                "expected_value": sol["value"], "p_best_pct": 100 * sol["p_best"], "p5": sol["p5"], "p50": sol["p50"],
                "p95": sol["p95"], "gap_pct": sol["gap_pct"], "rank_value": sol["rank"],
                "quantum_frequency_pct": 100 * (sol.get("quantum_frequency") or 0.0)}
            for metric, meas in wb.metric_measures.items():
                v = metric_values[metric]
                if v:
                    rows.append({**fixed, wb.rank_dimension: rank_el[r], wb.option_dimension: opt_map[wb.metrics_option],
                                 wb.measure_dimension: meas_map[meas], "Value": float(v)})
    scope = {**{d: [e] for d, e in fixed.items()}, wb.rank_dimension: rank_el,
             wb.option_dimension: opt_el, wb.measure_dimension: meas_el}
    return pd.DataFrame(rows), scope


def write_verified(tm1, cube: str, data: pd.DataFrame, scope: dict, use_sandbox: bool, run_id: str) -> dict:
    dims = tm1.cube_dimensions(cube)
    _check_dims(dims, set(scope), cube)
    expected = _canon(data, dims)
    before_df = tm1.read(cube, scope)
    before = _canon(before_df, dims)

    def restore(reason: str):
        try:
            tm1.clear(cube, scope)
            if before:
                tm1.write(cube, before_df, dims)
            left = _diff(before, _canon(tm1.read(cube, scope), dims))
        except Exception as exc:  # noqa: BLE001
            raise RollbackError(f"{reason} ; RESTAURATION ÉCHOUÉE : {exc}") from exc
        if left:
            raise RollbackError(f"{reason} ; restauration incomplète : {left[:5]}")
        raise ReconciliationError(f"{reason} ; état antérieur restauré et vérifié")

    mode = "sandbox" if use_sandbox and tm1.sandboxes_enabled() else "snapshot"
    if mode == "sandbox":
        name = f"tm1q_{run_id}"[:60]
        with tm1.sandbox(name):
            tm1.clear(cube, scope, sandbox=name)
            if len(data):
                tm1.write(cube, data, dims, sandbox=name)
            d = _diff(expected, _canon(tm1.read(cube, scope, sandbox=name), dims))
            if d:
                raise ReconciliationError(f"Écart en sandbox, rien publié : {d[:5]}")
            tm1.publish(name)
    else:
        try:
            tm1.clear(cube, scope)
            if len(data):
                tm1.write(cube, data, dims)
        except Exception as exc:  # noqa: BLE001
            restore(f"échec d'écriture : {exc}")
    d = _diff(expected, _canon(tm1.read(cube, scope), dims))
    if d:
        restore(f"écart après écriture : {d[:5]}")
    return {"mode": mode, "cells_written": len(expected), "cells_before": len(before), "reconciled": True}




