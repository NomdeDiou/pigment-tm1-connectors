"""Configuration déclarative, versionnée, validée. Aucun secret : seulement des noms de variables."""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator

from .errors import ConfigError


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class RuntimeConf(_Strict):
    environment: Literal["dev", "test", "prod"] = "dev"
    work_dir: str = "./runs"
    audit_log: str = "./audit/audit.jsonl"
    audit_hmac_key_env: str | None = "CONNECTOR_AUDIT_HMAC_KEY"
    lock_dir: str = "./locks"


class TM1Conf(_Strict):
    connection: dict = Field(default_factory=dict)     # paramètres non secrets de TM1py.TM1Service
    secret_env: dict[str, str] = Field(default_factory=dict)
    verify_tls: bool | str = True
    use_sandbox: bool = True

    @model_validator(mode="after")
    def _safe(self):
        leaked = {"password", "api_key", "apikey", "token", "secret"} & {k.lower() for k in self.connection}
        if leaked:
            raise ValueError(f"Secret en clair interdit dans tm1.connection : {sorted(leaked)}")
        url = self.connection.get("base_url")
        if url is not None and not str(url).startswith("https://"):
            raise ValueError("tm1.connection.base_url doit être en HTTPS")
        if self.verify_tls is False or self.connection.get("ssl") is False:
            raise ValueError("TLS obligatoire : verify_tls/ssl false interdits")
        return self


class CellRef(_Strict):
    cube: str
    coordinates: dict[str, str]


class ResourceConf(_Strict):
    capacity: float | None = None          # valeur fixe...
    capacity_from: CellRef | None = None   # ...ou lue dans une cellule TM1
    measure: str | None = None             # élément de mesure TM1 portant le coût par option
    unit: float = 1.0                      # granularité pour la formulation quantique (ex. 100 000 €)
    label: str | None = None

    @model_validator(mode="after")
    def _one_source(self):
        if (self.capacity is None) == (self.capacity_from is None):
            raise ValueError("ressource : fournir capacity OU capacity_from")
        if self.unit <= 0:
            raise ValueError("unit doit être > 0")
        return self


class SourceConf(_Strict):
    cube: str
    options_dimension: str
    measures_dimension: str
    fixed: dict[str, str] = Field(default_factory=dict)   # toutes les autres dimensions : un élément
    options: list[str] | None = None                       # None = toutes les options avec une valeur
    value_measure: str
    stdev_measure: str | None = None                        # incertitude (écart-type) de la valeur
    label_attribute: str | None = None                      # non utilisé en lecture cellule ; libellés via labels
    labels: dict[str, str] = Field(default_factory=dict)


class RulesConf(_Strict):
    mandatory: list[str] = Field(default_factory=list)            # doivent être retenues
    forbidden: list[str] = Field(default_factory=list)            # ne doivent pas l'être
    exclusive_groups: list[list[str]] = Field(default_factory=list)  # au plus une par groupe
    requires: dict[str, list[str]] = Field(default_factory=dict)  # A requiert B (et C...)
    min_selected: int | None = None
    max_selected: int | None = None


class Synergy(_Strict):
    a: str
    b: str
    value: float          # gain (ou perte si négatif) si a ET b sont retenues


class AnalysisConf(_Strict):
    top_k: int = 10
    exhaustive_max_options: int = 20            # 2^20 ≈ 1 million de combinaisons
    export_all_max_rows: int = 200_000
    milp_candidates: int = 100                  # au-delà du seuil exhaustif : K meilleures prouvées
    scenarios: int = 5000                       # Monte-Carlo
    max_candidates_robustness: int = 20_000
    seed: int = 20261026
    tie_tolerance_pct: float = 0.5              # écart jugé « quasi équivalent »

    @model_validator(mode="after")
    def _bounds(self):
        if not 1 <= self.top_k <= 100:
            raise ValueError("top_k entre 1 et 100")
        if self.exhaustive_max_options > 24:
            raise ValueError("exhaustive_max_options ≤ 24 (2^24 combinaisons)")
        if self.scenarios < 100:
            raise ValueError("scenarios ≥ 100")
        return self


class IBMConf(_Strict):
    channel: str = "ibm_quantum_platform"
    instance: str | None = None
    backend_name: str | None = None             # None = machine la moins chargée
    token_env: str = "IBM_QUANTUM_TOKEN"
    optimization_level: int = 1


class QuantumConf(_Strict):
    enabled: bool = True
    backend: Literal["simulator", "ibm"] = "simulator"
    layers: int = 3                             # profondeur QAOA (p)
    shots: int = 4096
    restarts: int = 4
    cvar_alpha: float = 0.2                     # optimisation CVaR (favorise les bonnes solutions)
    max_qubits: int = 20                        # limite du simulateur local
    penalty: float | None = None                # None = pénalité calculée garantissant l'exactitude
    # auto : pénalisation déséquilibrée calibrée (peu de qubits), repli sur « slack » si la calibration échoue
    formulation: Literal["auto", "unbalanced", "slack"] = "auto"
    gate_check_max_qubits: int = 16             # contrôle porte par porte du circuit jusqu'à cette taille
    seed: int = 7
    allow_external: bool = False                # autorise l'envoi du circuit hors de l'entreprise
    ibm: IBMConf = IBMConf()

    @model_validator(mode="after")
    def _b(self):
        if not 1 <= self.layers <= 10:
            raise ValueError("layers entre 1 et 10")
        if self.max_qubits > 24:
            raise ValueError("max_qubits ≤ 24 pour le simulateur local")
        if not 0 < self.cvar_alpha <= 1:
            raise ValueError("cvar_alpha dans ]0, 1]")
        if self.backend == "ibm" and not self.allow_external:
            raise ValueError("backend ibm : allow_external doit être explicitement true (sortie de données)")
        return self


class WritebackConf(_Strict):
    cube: str
    rank_dimension: str
    rank_elements: list[str]                    # ex. [Rang 01, Rang 02, ...]
    option_dimension: str
    measure_dimension: str
    selected_measure: str                       # 1 = option retenue dans cette solution
    fixed: dict[str, str] = Field(default_factory=dict)
    metrics_option: str | None = None           # élément feuille de la dimension option portant les indicateurs
    metric_measures: dict[str, str] = Field(default_factory=dict)  # indicateur -> élément de mesure


class GovernanceConf(_Strict):
    require_approval: bool = True
    protected_members: dict[str, list[str]] = Field(default_factory=dict)


class DecisionConf(_Strict):
    name: str
    owner: str
    description: str = ""
    currency: str = "€"
    source: SourceConf
    resources: dict[str, ResourceConf]
    rules: RulesConf = RulesConf()
    synergies: list[Synergy] = Field(default_factory=list)
    analysis: AnalysisConf = AnalysisConf()
    quantum: QuantumConf = QuantumConf()
    writeback: WritebackConf | None = None
    governance: GovernanceConf = GovernanceConf()

    @model_validator(mode="after")
    def _checks(self):
        if not self.name.replace("_", "").replace("-", "").isalnum():
            raise ValueError("nom de décision : lettres, chiffres, _ et -")
        if not self.resources:
            raise ValueError("au moins une ressource (contrainte de capacité) est requise")
        if self.writeback:
            for d, prot in self.governance.protected_members.items():
                v = self.writeback.fixed.get(d)
                if v and v.lower() in {p.lower() for p in prot}:
                    raise ValueError(f"writeback.fixed {d}={v} est un membre protégé")
        return self


class AppConf(_Strict):
    runtime: RuntimeConf = RuntimeConf()
    tm1: TM1Conf = TM1Conf()
    decisions: list[DecisionConf]

    def decision(self, name: str) -> DecisionConf:
        for d in self.decisions:
            if d.name == name:
                return d
        raise ConfigError(f"Décision inconnue : {name}. Déclarées : {[d.name for d in self.decisions]}")


def load_config(path: str | Path) -> tuple[AppConf, str]:
    p = Path(path)
    if not p.is_file():
        raise ConfigError(f"Configuration introuvable : {p}")
    raw = p.read_bytes()
    try:
        conf = AppConf.model_validate(yaml.safe_load(raw))
    except Exception as exc:
        raise ConfigError(f"Configuration invalide ({p}) :\n{exc}") from exc
    names = [d.name for d in conf.decisions]
    if len(names) != len(set(names)):
        raise ConfigError("Noms de décision en double")
    return conf, hashlib.sha256(raw).hexdigest()
