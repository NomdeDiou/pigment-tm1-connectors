"""Circuit QAOA : représentation portable, export OpenQASM 2.0 et simulateur porte par porte.

Le circuit est la SEULE chose envoyée à une machine quantique externe : des angles et des
indices de qubits, aucun libellé ni montant lisible. Il est conservé dans les preuves.
Le simulateur porte par porte sert à prouver que le circuit exporté réalise exactement
l'évolution calculée par le simulateur rapide (contrôle « circuit = calcul »).
"""
from __future__ import annotations

import hashlib

import numpy as np

Gate = tuple  # ("h", q) | ("rz", theta, q) | ("rzz", theta, i, j) | ("rx", theta, q)


def qaoa_gates(h: np.ndarray, J: dict, gammas, betas, energy_scale: float) -> list[Gate]:
    """exp(-iγ H/R) avec H = Σ h z + Σ J zz, puis mélangeur exp(-iβ Σ X).

    RZ(θ) = exp(-iθZ/2) => θ = 2γh/R ; RZZ(θ) = exp(-iθZZ/2) => θ = 2γJ/R ; RX(2β) = exp(-iβX).
    """
    n = len(h)
    gates: list[Gate] = [("h", q) for q in range(n)]
    for g, bt in zip(gammas, betas):
        for q in range(n):
            if h[q] != 0:
                gates.append(("rz", 2 * g * h[q] / energy_scale, q))
        for (i, j), c in sorted(J.items()):
            gates.append(("rzz", 2 * g * c / energy_scale, i, j))
        for q in range(n):
            gates.append(("rx", 2 * bt, q))
    return gates


def to_qasm2(n: int, gates: list[Gate]) -> str:
    lines = ["OPENQASM 2.0;", 'include "qelib1.inc";', f"qreg q[{n}];", f"creg c[{n}];"]
    for g in gates:
        if g[0] == "h":
            lines.append(f"h q[{g[1]}];")
        elif g[0] in ("rz", "rx"):
            lines.append(f"{g[0]}({g[1]:.17g}) q[{g[2]}];")
        elif g[0] == "rzz":
            lines.append(f"rzz({g[1]:.17g}) q[{g[2]}],q[{g[3]}];")
    lines.append("measure q -> c;")
    return "\n".join(lines) + "\n"


def qasm_sha256(qasm: str) -> str:
    return hashlib.sha256(qasm.encode()).hexdigest()


def simulate_gates(n: int, gates: list[Gate]) -> np.ndarray:
    """Simulation porte par porte (référence lente, indépendante du simulateur rapide)."""
    state = np.zeros(1 << n, dtype=np.complex128)
    state[0] = 1.0
    idx = np.arange(1 << n, dtype=np.int64)
    for g in gates:
        kind = g[0]
        if kind in ("h", "rx"):
            q = g[1] if kind == "h" else g[2]
            if kind == "h":
                m = np.array([[1, 1], [1, -1]], dtype=np.complex128) / np.sqrt(2)
            else:
                t = g[1] / 2
                m = np.array([[np.cos(t), -1j * np.sin(t)], [-1j * np.sin(t), np.cos(t)]])
            s = state.reshape(-1, 2, 1 << q)
            a, b = s[:, 0, :].copy(), s[:, 1, :].copy()
            s[:, 0, :] = m[0, 0] * a + m[0, 1] * b
            s[:, 1, :] = m[1, 0] * a + m[1, 1] * b
            state = s.reshape(-1)
        elif kind == "rz":
            t, q = g[1], g[2]
            z = 1 - 2 * ((idx >> q) & 1)
            state = state * np.exp(-1j * t / 2 * z)
        elif kind == "rzz":
            t, i, j = g[1], g[2], g[3]
            zz = (1 - 2 * ((idx >> i) & 1)) * (1 - 2 * ((idx >> j) & 1))
            state = state * np.exp(-1j * t / 2 * zz)
    return state
