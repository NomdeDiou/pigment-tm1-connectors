"""Formulation quantique : problème -> QUBO -> Hamiltonien d'Ising.

QUBO = minimiser E(x) = const + Σ L_i x_i + Σ_{i<j} Q_ij x_i x_j sur des bits x.
  * objectif : -valeur / échelle (on minimise l'opposé de la valeur) ;
  * contraintes d'inégalité : variables d'écart binaires (« slack ») + pénalité P·(Σ a_i x_i + s - b)² ;
  * groupes exclusifs, dépendances : pénalités quadratiques ;
  * options obligatoires / interdites : substituées par leur valeur (aucun qubit consommé).
La pénalité automatique P > 2 × (amplitude de l'objectif) garantit que tout état violant
une contrainte a une énergie supérieure à celle de toute solution admissible : le minimum
du QUBO EST la meilleure solution (vérifié à l'exécution par énumération).

Les coûts sont discrétisés en « unités » (ex. 100 k€) de façon conservatrice (coûts arrondis
au-dessus, capacités au-dessous) : une solution admissible pour le QUBO l'est toujours dans
la réalité. Si la discrétisation n'est pas exacte, le rapport le signale.
"""
from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field

import numpy as np

from .problem import Problem

CHUNK = 1 << 18


class _Affine:
    """Expression affine en variables binaires : Σ coef·x_var + constante."""
    __slots__ = ("terms", "const")

    def __init__(self, terms=None, const=0.0):
        self.terms: dict[int, float] = dict(terms or {})
        self.const = float(const)


class _Builder:
    def __init__(self):
        self.n = 0
        self.lin: dict[int, float] = defaultdict(float)
        self.quad: dict[tuple[int, int], float] = defaultdict(float)
        self.const = 0.0

    def new_var(self) -> int:
        self.n += 1
        return self.n - 1

    def add_product(self, a: _Affine, b: _Affine, w: float):
        """Ajoute w·a·b (x² = x pour un bit)."""
        self.const += w * a.const * b.const
        for i, c in a.terms.items():
            self.lin[i] += w * c * b.const
        for j, c in b.terms.items():
            self.lin[j] += w * c * a.const
        for i, ci in a.terms.items():
            for j, cj in b.terms.items():
                if i == j:
                    self.lin[i] += w * ci * cj
                else:
                    self.quad[(min(i, j), max(i, j))] += w * ci * cj

    def add_affine(self, a: _Affine, w: float):
        self.add_product(a, _Affine({}, 1.0), w)


@dataclass
class Qubo:
    nq: int
    lin: np.ndarray
    quad: dict[tuple[int, int], float]
    const: float
    free_options: list[int]          # qubit k (k < len) -> indice d'option
    fixed_code: int                  # bits des options obligatoires
    scale: float                     # valeur = -énergie × scale pour une solution admissible
    penalty: float
    exact_discretization: bool
    infeasible_by_construction: bool
    notes: list[str] = field(default_factory=list)
    slack: list[dict] = field(default_factory=list)

    # -------------------------------------------------------------- évaluation
    def energy_vector(self) -> np.ndarray:
        total = 1 << self.nq
        out = np.empty(total, dtype=np.float64)
        shifts = np.arange(self.nq, dtype=np.int64)
        for s in range(0, total, CHUNK):
            idx = np.arange(s, min(s + CHUNK, total), dtype=np.int64)
            b = ((idx[:, None] >> shifts) & 1).astype(np.float64)
            e = self.const + b @ self.lin
            for (i, j), q in self.quad.items():
                e += q * b[:, i] * b[:, j]
            out[s:s + len(idx)] = e
        return out

    def decode(self, states: np.ndarray) -> np.ndarray:
        """États (entiers sur nq bits) -> codes de décision (bits d'options)."""
        states = np.asarray(states, dtype=np.int64)
        codes = np.full(states.shape, self.fixed_code, dtype=np.int64)
        for k, opt in enumerate(self.free_options):
            codes |= ((states >> k) & 1) << opt
        return codes

    # -------------------------------------------------------------- Ising
    def to_ising(self) -> tuple[np.ndarray, dict[tuple[int, int], float], float]:
        """x = (1 - z)/2, z ∈ {+1, -1} ; qubit mesuré 0 <=> z = +1 <=> x = 0."""
        h = -self.lin / 2.0
        offset = self.const + self.lin.sum() / 2.0
        J: dict[tuple[int, int], float] = {}
        for (i, j), q in self.quad.items():
            if q == 0:
                continue
            J[(i, j)] = q / 4.0
            h[i] -= q / 4.0
            h[j] -= q / 4.0
            offset += q / 4.0
        return h, J, offset


def ising_energy_vector(h: np.ndarray, J: dict, offset: float) -> np.ndarray:
    n = len(h)
    total = 1 << n
    out = np.empty(total)
    shifts = np.arange(n, dtype=np.int64)
    for s in range(0, total, CHUNK):
        idx = np.arange(s, min(s + CHUNK, total), dtype=np.int64)
        z = 1.0 - 2.0 * ((idx[:, None] >> shifts) & 1)
        e = offset + z @ h
        for (i, j), c in J.items():
            e += c * z[:, i] * z[:, j]
        out[s:s + len(idx)] = e
    return out


def _slack_bits(builder: _Builder, upper: int) -> list[tuple[int, int]]:
    """Encodage borné de s ∈ [0, upper] : coefficients 1, 2, 4, ..., reste."""
    if upper <= 0:
        return []
    k = int(math.floor(math.log2(upper))) + 1
    coefs = [1 << t for t in range(k - 1)] + [upper - ((1 << (k - 1)) - 1)]
    return [(builder.new_var(), c) for c in coefs]


def build_qubo(p: Problem, penalty: float | None = None, method: str = "slack",
               lambdas: tuple[float, float] = (1.0, 1.0)) -> Qubo:
    """method = "slack"      : variables d'écart, minimum du QUBO = optimum garanti (plus de qubits) ;
       method = "unbalanced" : pénalisation déséquilibrée -λ1·h + λ2·h² (h = marge normalisée),
                               sans qubit d'écart, coûts exacts ; minimum vérifié et calibré à part."""
    b = _Builder()
    notes: list[str] = []
    fixed = {p.index[m]: 1 for m in p.mandatory}
    fixed.update({p.index[f]: 0 for f in p.forbidden})
    free = [i for i in range(p.n) if i not in fixed]
    var_of = {i: b.new_var() for i in free}

    def X(i: int) -> _Affine:
        return _Affine({}, fixed[i]) if i in fixed else _Affine({var_of[i]: 1.0})

    vals = list(np.abs(p.v)) + [abs(s) for _, _, s in p.syn]
    scale = max(vals) if vals and max(vals) > 0 else 1.0
    amplitude = sum(vals) / scale
    P = penalty if penalty is not None else 2.0 * amplitude + 1.0

    # objectif
    for i in range(p.n):
        b.add_affine(X(i), -p.v[i] / scale)
    for i, j, s in p.syn:
        b.add_product(X(i), X(j), -s / scale)

    exact = True
    infeasible = False
    slack_info = []

    def constraint(name: str, coefs: dict[int, float], rhs: float, sense: str):
        """Σ coef_i x_i (≤ ou ≥) rhs, coefficients ≥ 0 (entiers en mode slack)."""
        nonlocal infeasible
        c0 = sum(c for i, c in coefs.items() if fixed.get(i) == 1)
        free_sum = sum(c for i, c in coefs.items() if i not in fixed)
        if method == "unbalanced":
            if (sense == "<=" and c0 + free_sum <= rhs + 1e-12) or (sense == ">=" and c0 >= rhs - 1e-12):
                return
            if (sense == "<=" and c0 > rhs + 1e-12) or (sense == ">=" and c0 + free_sum < rhs - 1e-12):
                infeasible = True
            norm = max(1.0, abs(rhs)) if sense == ">=" else (abs(rhs) if rhs > 0 else 1.0)
            sign = 1.0 if sense == "<=" else -1.0          # h = marge ≥ 0 souhaitée
            h = _Affine({var_of[i]: -sign * c / norm for i, c in coefs.items() if i not in fixed and c},
                        sign * (rhs - c0) / norm)
            b.add_affine(h, -lambdas[0])
            b.add_product(h, h, lambdas[1])
            slack_info.append({"constraint": name, "sense": sense, "rhs": rhs, "slack_qubits": 0,
                               "lambda1": lambdas[0], "lambda2": lambdas[1]})
            return
        if sense == "<=":
            if c0 + free_sum <= rhs:
                return                                   # jamais contraignante : aucun qubit
            if c0 > rhs:
                infeasible = True
            room = max(0, rhs - c0)
            bits = _slack_bits(b, room)
            expr = _Affine({var_of[i]: c for i, c in coefs.items() if i not in fixed and c}, c0 - rhs)
            for v, c in bits:
                expr.terms[v] = expr.terms.get(v, 0) + c
        else:
            if c0 >= rhs:
                return
            if c0 + free_sum < rhs:
                infeasible = True
            room = max(0, c0 + free_sum - rhs)
            bits = _slack_bits(b, room)
            expr = _Affine({var_of[i]: c for i, c in coefs.items() if i not in fixed and c}, c0 - rhs)
            for v, c in bits:
                expr.terms[v] = expr.terms.get(v, 0) - c
        slack_info.append({"constraint": name, "sense": sense, "rhs": rhs, "slack_qubits": len(bits)})
        b.add_product(expr, expr, P)

    for r, name in enumerate(p.resources):
        if method == "unbalanced":                      # coûts exacts, aucune discrétisation
            constraint(f"capacité {name}", {i: float(p.C[r, i]) for i in range(p.n) if p.C[r, i]},
                       float(p.cap[r]), "<=")
            continue
        unit = p.units[r]
        coefs = {}
        for i in range(p.n):
            raw = p.C[r, i] / unit
            c = math.ceil(raw - 1e-9)
            if abs(raw - round(raw)) > 1e-9:
                exact = False
            if c:
                coefs[i] = c
        cap_raw = p.cap[r] / unit
        rhs = math.floor(cap_raw + 1e-9)
        if abs(cap_raw - round(cap_raw)) > 1e-9:
            exact = False
        constraint(f"capacité {name}", coefs, rhs, "<=")
    if p.max_selected is not None:
        constraint("nombre max d'options", {i: 1 for i in range(p.n)}, p.max_selected, "<=")
    if p.min_selected is not None:
        constraint("nombre min d'options", {i: 1 for i in range(p.n)}, p.min_selected, ">=")
    for g in p.exclusive_groups:
        idx = [p.index[x] for x in g]
        for a in range(len(idx)):
            for c in range(a + 1, len(idx)):
                b.add_product(X(idx[a]), X(idx[c]), P)
    for a, needs in p.requires.items():
        for nb in needs:
            one_minus = X(p.index[nb])
            one_minus = _Affine({k: -v for k, v in one_minus.terms.items()}, 1.0 - one_minus.const)
            b.add_product(X(p.index[a]), one_minus, P)

    if method == "unbalanced":
        notes.append("Formulation par pénalisation déséquilibrée (sans qubit d'écart) : son minimum n'est pas "
                     "garanti par construction ; il est vérifié par énumération et calibré.")
    if not exact:
        notes.append("Discrétisation approximative des coûts : la formulation quantique est conservatrice "
                      "(elle peut écarter des solutions admissibles très proches des limites de capacité).")
    lin = np.zeros(b.n)
    for i, c in b.lin.items():
        lin[i] = c
    quad = {k: v for k, v in b.quad.items() if abs(v) > 1e-15}
    return Qubo(nq=b.n, lin=lin, quad=quad, const=b.const, free_options=free,
                fixed_code=sum(1 << i for i, v in fixed.items() if v == 1), scale=scale, penalty=P,
                exact_discretization=exact, infeasible_by_construction=infeasible, notes=notes, slack=slack_info)
