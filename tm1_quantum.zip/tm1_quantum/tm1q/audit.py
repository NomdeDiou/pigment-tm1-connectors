"""Journal d'audit append-only, chaîné et (optionnellement) signé par HMAC.

Chaque enregistrement contient l'empreinte du précédent : toute modification,
suppression ou insertion a posteriori casse la chaîne et est détectée par
`verify()`. Avec une clé HMAC (gardée hors du serveur d'exécution idéalement),
un attaquant ne peut pas non plus réécrire toute la chaîne.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
from datetime import datetime, timezone
from pathlib import Path

GENESIS = "0" * 64


def _canon(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str).encode()


class AuditLog:
    def __init__(self, path: str | Path, hmac_key: str | None = None):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._key = hmac_key.encode() if hmac_key else None

    def _digest(self, body: dict) -> str:
        if self._key:
            return hmac.new(self._key, _canon(body), hashlib.sha256).hexdigest()
        return hashlib.sha256(_canon(body)).hexdigest()

    def _last_hash(self) -> tuple[str, int]:
        if not self.path.exists() or self.path.stat().st_size == 0:
            return GENESIS, 0
        last, n = None, 0
        with self.path.open("r", encoding="utf-8") as fh:
            for line in fh:
                if line.strip():
                    last, n = line, n + 1
        rec = json.loads(last)
        return rec["hash"], rec["seq"]

    def append(self, event: str, **fields) -> dict:
        prev, seq = self._last_hash()
        body = {
            "seq": seq + 1,
            "ts": datetime.now(timezone.utc).isoformat(),
            "event": event,
            "prev_hash": prev,
            "signed": self._key is not None,
            **fields,
        }
        rec = {**body, "hash": self._digest(body)}
        line = json.dumps(rec, ensure_ascii=False, default=str) + "\n"
        # écriture append + fsync : l'événement est durable avant de continuer
        fd = os.open(self.path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o640)
        try:
            os.write(fd, line.encode("utf-8"))
            os.fsync(fd)
        finally:
            os.close(fd)
        return rec

    def verify(self) -> tuple[bool, int, str]:
        """Retourne (intègre, nb d'enregistrements vérifiés, message)."""
        if not self.path.exists():
            return True, 0, "journal vide"
        prev, expected_seq = GENESIS, 1
        with self.path.open("r", encoding="utf-8") as fh:
            for lineno, line in enumerate(fh, 1):
                if not line.strip():
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    return False, lineno - 1, f"ligne {lineno} illisible"
                h = rec.pop("hash", None)
                if rec.get("seq") != expected_seq:
                    return False, lineno - 1, f"ligne {lineno} : séquence {rec.get('seq')} ≠ {expected_seq}"
                if rec.get("prev_hash") != prev:
                    return False, lineno - 1, f"ligne {lineno} : chaînage rompu"
                if rec.get("signed") and not self._key:
                    return False, lineno - 1, "journal signé : clé HMAC requise pour vérifier"
                if not hmac.compare_digest(self._digest(rec), h or ""):
                    return False, lineno - 1, f"ligne {lineno} : empreinte invalide (altération)"
                prev, expected_seq = h, expected_seq + 1
        return True, expected_seq - 1, "intègre"
