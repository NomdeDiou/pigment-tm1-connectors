"""Lecture humaine des résultats : recommandation, niveau de confiance, alternatives, points d'attention.

Règle d'écriture : chaque phrase s'appuie sur un chiffre calculé et vérifié ; aucune
affirmation n'est produite sans la donnée qui la justifie. Le ton reste factuel et
laisse la décision à l'humain.
"""
from __future__ import annotations


def money(v: float | None, cur: str = "€") -> str:
    if v is None:
        return "—"
    a = abs(v)
    if a >= 1e9:
        s = f"{v / 1e9:,.2f} Md{cur}"
    elif a >= 1e6:
        s = f"{v / 1e6:,.2f} M{cur}"
    elif a >= 1e4:
        s = f"{v / 1e3:,.0f} k{cur}"
    else:
        s = f"{v:,.0f} {cur}"
    return s.replace(",", " ").replace(".", ",")


def pct(p: float | None, digits: int = 1) -> str:
    if p is None:
        return "—"
    return f"{100 * p:.{digits}f} %".replace(".", ",")


def num(v: float, digits: int = 0) -> str:
    return f"{v:,.{digits}f}".replace(",", " ").replace(".", ",")


def _names(labels: list[str]) -> str:
    if not labels:
        return "aucune"
    return labels[0] if len(labels) == 1 else ", ".join(labels[:-1]) + " et " + labels[-1]


def build(result: dict) -> dict:
    cur = result["problem"]["currency"]
    rk = result["ranking"]
    rob = result["robustness"]
    first = rk[0]
    label = {o["id"]: o["label"] for o in result["options"]}
    msgs: list[dict] = []

    # ------------------------------------------------ confiance
    if rob["deterministic"]:
        confidence, conf_text = "certaine", ("aucune incertitude n'a été renseignée sur les valeurs : "
                                             "le classement est exact et définitif pour ces hypothèses")
    else:
        pb = first["p_best"]
        confidence = "élevée" if pb >= 0.6 else "moyenne" if pb >= 0.35 else "faible"
        conf_text = (f"compte tenu des incertitudes renseignées, cette décision est la meilleure dans "
                     f"{pct(pb)} des {num(rob['scenarios'])} scénarios simulés (± {pct(first['ci95'])})")
        if confidence != "élevée" and result["by_probability"] and result["by_probability"][0]["rank"] == 1:
            conf_text += (" ; aucune décision ne s'impose nettement, mais c'est celle qui a le plus de chances "
                          "d'être la meilleure")

    reco = (f"Retenir {_names([label[o] for o in first['options']])}, pour une valeur attendue de "
            f"{money(first['value'], cur)}.")

    # ------------------------------------------------ quasi-égalités
    tol = result["analysis"]["tie_tolerance_pct"] / 100
    near = [s for s in rk[1:] if s["gap_pct"] is not None and abs(s["gap_pct"]) / 100 <= tol]
    if near:
        msgs.append({"kind": "attention", "title": "Décisions quasi équivalentes",
                     "text": f"{len(near)} autre(s) décision(s) sont à moins de {num(100 * tol, 1)} % de la n°1 "
                             f"(n°{', n°'.join(str(s['rank']) for s in near)}). Les chiffres ne suffisent pas à "
                             "trancher : des critères non modélisés (calendrier, risque d'exécution, stratégie) "
                             "doivent départager."})

    # ------------------------------------------------ alternative plus robuste
    if not rob["deterministic"]:
        best_p = max(rk, key=lambda s: s["p_best"])
        if best_p["rank"] != 1 and best_p["p_best"] > first["p_best"] + 0.05:
            msgs.append({"kind": "alternative", "title": f"La n°{best_p['rank']} est plus souvent gagnante",
                         "text": f"Elle rapporte en moyenne {pct(abs(best_p['gap_pct']) / 100)} de moins "
                                 f"({money(best_p['value'], cur)}), mais elle est la meilleure dans "
                                 f"{pct(best_p['p_best'])} des scénarios contre {pct(first['p_best'])} pour la n°1. "
                                 "À privilégier si la prudence compte davantage que l'espérance de gain."})
        if first["p5"] is not None and len(rk) > 1:
            safer = max(rk, key=lambda s: s["p5"])
            if safer["rank"] != 1 and safer["p5"] > first["p5"] * 1.02:
                msgs.append({"kind": "alternative", "title": f"La n°{safer['rank']} protège mieux dans le pire cas",
                             "text": f"Dans les 5 % de scénarios les plus défavorables, elle vaut au moins "
                                     f"{money(safer['p5'], cur)} contre {money(first['p5'], cur)} pour la n°1."})

    # ------------------------------------------------ options robustes / fragiles
    if not rob["deterministic"]:
        mand = set(result["problem"]["rules"]["mandatory"])
        sure = [o for o in result["options"] if o["p_in_best"] >= 0.9 and o["id"] not in mand]
        shaky = [o for o in result["options"] if o["in_first"] and o["p_in_best"] < 0.6]
        if sure:
            msgs.append({"kind": "info", "title": "Choix solides",
                         "text": f"{_names([o['label'] for o in sure])} "
                                 f"{'fait' if len(sure) == 1 else 'font'} partie de la meilleure décision dans au moins "
                                 "90 % des scénarios : ce choix dépend très peu des incertitudes."})
        if shaky:
            msgs.append({"kind": "attention", "title": "Choix à challenger",
                         "text": " ; ".join(f"{o['label']} n'est retenu que dans {pct(o['p_in_best'])} des scénarios"
                                           for o in shaky) + ". Affiner leurs estimations réduirait l'incertitude."})

    # ------------------------------------------------ décisions jamais gagnantes
    if not rob["deterministic"]:
        sets = [(s_["rank"], set(s_["options"])) for s_ in rk]
        never = [s_ for s_ in rk[1:] if s_["p_best"] == 0]
        for s_ in never:
            sup = next((r for r, o in sets if r < s_["rank"] and set(s_["options"]) < o), None)
            why = ""
            if sup:
                extra = [label[x] for x in sorted(dict(sets)[sup] - set(s_["options"]))]
                why = f" : c'est la n°{sup} sans {_names(extra)}, qui rapporte toujours davantage"
            msgs.append({"kind": "info", "title": f"La n°{s_['rank']} n'est jamais le meilleur choix",
                         "text": f"Elle ne l'est dans aucun des {num(rob['scenarios'])} scénarios{why}. "
                                 "Elle peut être écartée."})

    # ------------------------------------------------ contraintes et sensibilité
    for s in result["sensitivity"]:
        used = first["usage"][s["resource"]]
        if used["pct"] is not None and used["pct"] >= 0.97:
            gain = s["delta_plus_pct"]
            msgs.append({"kind": "info", "title": f"{s['label']} est la ressource limitante",
                         "text": f"La n°1 en consomme {pct(used['pct'])}. "
                                 + (f"Avec 10 % de {s['label']} en plus, la meilleure décision vaudrait "
                                    f"{money(s['plus10'], cur)} ({'+' if gain >= 0 else ''}{num(gain, 1)} %)."
                                    if s["plus10"] is not None else "")})
        elif s["plus10"] is not None and s["delta_plus_pct"] == 0 and s["delta_minus_pct"] == 0:
            msgs.append({"kind": "info", "title": f"{s['label']} n'est pas contraignante",
                         "text": "Une variation de ± 10 % de cette capacité ne change pas la meilleure valeur."})

    # ------------------------------------------------ quantique
    q = result["quantum"]
    if q["status"] == "ok":
        m = q["metrics"]
        txt = (f"Sur {num(m['shots_total'])} mesures, le circuit quantique a proposé {num(m['distinct_decisions'])} "
               f"décisions différentes, dont {pct(m['feasible_frequency'])} respectent toutes les contraintes. ")
        if m["optimum_observed"]:
            txt += f"La meilleure décision a été observée ({pct(m['optimum_frequency'], 2)} des mesures). "
        else:
            txt += (f"La meilleure décision n'a pas été observée ; la meilleure décision mesurée est la "
                    f"n°{m['best_observed_rank']}. ")
        if m.get("top10_enrichment"):
            txt += (f"Les 10 meilleures décisions sortent {num(m['top10_enrichment'], 1)} fois plus souvent "
                    "qu'au hasard.")
        msgs.append({"kind": "quantum", "title": "Ce qu'apporte le calcul quantique", "text": txt})

    return {"recommendation": reco, "confidence": confidence, "confidence_text": conf_text, "messages": msgs}
