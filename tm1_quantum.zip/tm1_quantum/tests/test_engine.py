"""Parcours complet, sécurité et gouvernance (TM1 simulé en mémoire)."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tests.fakes import FakeTM1  # noqa: E402
from tm1q import cli  # noqa: E402
from tm1q.audit import AuditLog  # noqa: E402
from tm1q.config import AppConf, load_config  # noqa: E402
from tm1q.engine import Engine, RunOptions  # noqa: E402
from tm1q.errors import (ConfigError, GovernanceError, InfeasibleError, LockError,  # noqa: E402
                         ReconciliationError, VerificationError)
from tm1q.lock import FlowLock  # noqa: E402

DEMO = pd.read_csv(ROOT / "examples" / "projets_demo.csv")
HMAC = "cle-hmac-de-test-0123456789"


def make_tm1() -> FakeTM1:
    t = FakeTM1()
    t.cube("Projets", ["Version", "Projet", "Mesure Projet"])
    t.leaves["Version"] = ["Budget 2027", "Proposition", "Actual"]
    t.leaves["Projet"] = list(DEMO["id"]) + ["Synthèse"]
    t.leaves["Mesure Projet"] = ["VAN", "VAN Ecart-type", "Capex", "ETP"]
    for r in DEMO.itertuples():
        for m, v in (("VAN", r.value), ("VAN Ecart-type", r.stdev), ("Capex", r.Capex), ("ETP", r.ETP)):
            t.data["Projets"][("Budget 2027", r.id, m)] = float(v)
    t.cube("Décisions", ["Version", "Rang", "Projet", "Mesure Décision"])
    t.leaves["Rang"] = ["Rang 01", "Rang 02", "Rang 03"]
    t.leaves["Mesure Décision"] = ["Retenu", "Valeur attendue", "Probabilité"]
    t.data["Décisions"][("Proposition", "Rang 01", "P03", "Retenu")] = 1.0      # ancienne proposition, à remplacer
    return t


def conf_dict(tmp: str, env="dev", **dec_over) -> dict:
    dec = {
        "name": "portefeuille", "owner": "dfi", "description": "Portefeuille de test",
        "source": {"cube": "Projets", "options_dimension": "Projet", "measures_dimension": "Mesure Projet",
                   "fixed": {"Version": "Budget 2027"}, "value_measure": "VAN", "stdev_measure": "VAN Ecart-type",
                   "labels": dict(zip(DEMO["id"], DEMO["label"]))},
        "resources": {"Capex": {"measure": "Capex", "capacity": 7_000_000, "unit": 200_000}, "ETP": {"capacity": 24}},
        "rules": {"mandatory": ["P01"], "exclusive_groups": [["P03", "P04"]], "requires": {"P06": ["P02"]}},
        "synergies": [{"a": "P02", "b": "P06", "value": 400000}, {"a": "P07", "b": "P08", "value": 300000},
                      {"a": "P04", "b": "P05", "value": 200000}, {"a": "P03", "b": "P10", "value": -400000}],
        "analysis": {"scenarios": 2000},
        "quantum": {"shots": 2048, "restarts": 2},
        "writeback": {"cube": "Décisions", "rank_dimension": "Rang", "rank_elements": ["Rang 01", "Rang 02", "Rang 03"],
                      "option_dimension": "Projet", "measure_dimension": "Mesure Décision", "selected_measure": "Retenu",
                      "fixed": {"Version": "Proposition"}, "metrics_option": "Synthèse",
                      "metric_measures": {"expected_value": "Valeur attendue", "p_best_pct": "Probabilité"}},
        "governance": {"protected_members": {"Version": ["Budget 2027", "Actual"]}},
    }
    dec.update(dec_over)
    return {"runtime": {"environment": env, "work_dir": f"{tmp}/runs", "audit_log": f"{tmp}/audit.jsonl",
                        "lock_dir": f"{tmp}/locks", "audit_hmac_key_env": "TEST_HMAC"},
            "decisions": [dec]}


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        os.environ["TEST_HMAC"] = HMAC
        self.tm1 = make_tm1()

    def engine(self, env="dev", **over) -> Engine:
        return Engine(AppConf.model_validate(conf_dict(self.tmp, env, **over)), "h", tm1_factory=lambda: self.tm1)

    def analyze(self, eng=None, **kw):
        return (eng or self.engine()).analyze("portefeuille", **kw)


class TestAnalysis(Base):
    def test_full_analysis_from_tm1_is_verified(self):
        r = self.analyze()
        self.assertTrue(r["verified"])
        self.assertTrue(all(c["status"] == "ok" for c in r["checks"]), [c for c in r["checks"] if c["status"] != "ok"])
        self.assertEqual(r["exact"]["combinations_examined"], 1024)
        self.assertEqual(r["exact"]["feasible_count"], 143)
        self.assertEqual(r["ranking"][0]["options"], ["P01", "P02", "P05", "P06", "P08", "P10"])
        self.assertAlmostEqual(r["ranking"][0]["value"], 11_000_000)
        self.assertEqual(r["source"]["kind"], "tm1")
        self.assertEqual(r["quantum"]["status"], "ok")
        self.assertEqual(r["quantum"]["qubits"], 9)
        d = Path(r["_evidence_dir"])
        for f in ("result.json", "rapport.html", "probleme.json", "toutes_les_solutions.csv", "circuit.qasm",
                  "mesures_quantiques.csv"):
            self.assertTrue((d / f).exists(), f)
        self.assertEqual(len((d / "toutes_les_solutions.csv").read_text().splitlines()), 144)

    def test_csv_and_tm1_sources_give_the_same_problem(self):
        a = self.analyze()
        b = self.analyze(input_csv=str(ROOT / "examples" / "projets_demo.csv"))
        self.assertEqual(a["problem_fingerprint"], b["problem_fingerprint"])
        self.assertEqual(a["ranking"][0]["options"], b["ranking"][0]["options"])

    def test_milp_mode_beyond_exhaustive_threshold(self):
        r = self.analyze(self.engine(analysis={"exhaustive_max_options": 6, "scenarios": 1000, "milp_candidates": 15}))
        self.assertEqual(r["exact"]["method"], "milp")
        self.assertTrue(r["exact"]["proven_optimal"])
        self.assertAlmostEqual(r["ranking"][0]["value"], 11_000_000)
        self.assertTrue(r["verified"])

    def test_infeasible_problem_is_explained(self):
        eng = self.engine(resources={"Capex": {"measure": "Capex", "capacity": 100_000}, "ETP": {"capacity": 24}})
        with self.assertRaises(InfeasibleError) as cm:
            self.analyze(eng)
        self.assertTrue(any("obligatoires" in i for i in cm.exception.issues))

    def test_failed_check_blocks_and_report_still_written(self):
        import tm1q.engine as E
        orig = E.run_checks

        def broken(*a, **k):
            out = orig(*a, **k)
            out.append({"id": "x", "label": "contrôle simulé", "status": "echec", "detail": "test", "blocking": True})
            return out
        E.run_checks = broken
        try:
            with self.assertRaises(VerificationError):
                self.analyze()
        finally:
            E.run_checks = orig
        reports = list(Path(self.tmp, "runs").rglob("rapport.html"))
        self.assertEqual(len(reports), 1)
        self.assertIn("résultats non publiables", reports[0].read_text())

    def test_report_escapes_labels(self):
        self.tm1.leaves["Projet"].append("<script>")
        r = self.analyze(self.engine(source={**conf_dict(self.tmp)["decisions"][0]["source"],
                                             "labels": {"P02": "<script>alert(1)</script>"}}))
        html = Path(r["_evidence_dir"], "rapport.html").read_text()
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;", html)

    def test_quantum_external_requires_explicit_opt_in_and_approval(self):
        with self.assertRaises(Exception):
            AppConf.model_validate(conf_dict(self.tmp, quantum={"backend": "ibm"}))
        eng = self.engine(quantum={"backend": "ibm", "allow_external": True})
        r = self.analyze(eng)                                   # pas d'approbation : rien ne part
        self.assertEqual(r["quantum"]["status"], "failed")
        self.assertIn("non approuvé", r["quantum"]["reason"])


class TestGovernance(Base):
    def test_writeback_end_to_end_with_sandbox(self):
        r = self.analyze()
        out = self.engine().writeback("portefeuille", r["run_id"], 2, RunOptions("boss", None, "alice"))
        self.assertEqual(out["mode"], "sandbox")
        self.assertTrue(out["reconciled"])
        d = self.tm1.data["Décisions"]
        sel1 = sorted(k[2] for k, v in d.items() if k[1] == "Rang 01" and k[3] == "Retenu")
        self.assertEqual(sel1, ["P01", "P02", "P05", "P06", "P08", "P10"])
        self.assertNotIn(("Proposition", "Rang 01", "P03", "Retenu"), d, "ancienne proposition effacée")
        self.assertAlmostEqual(d[("Proposition", "Rang 01", "Synthèse", "Valeur attendue")], 11_000_000)
        self.assertTrue(all(k[0] == "Proposition" for k in d), "aucune écriture hors périmètre")

    def test_writeback_refused_if_tm1_data_changed(self):
        r = self.analyze()
        self.tm1.data["Projets"][("Budget 2027", "P02", "VAN")] = 2_500_000.0
        with self.assertRaises(GovernanceError) as cm:
            self.engine().writeback("portefeuille", r["run_id"], 1, RunOptions("boss", None, "alice"))
        self.assertIn("changé", str(cm.exception))

    def test_writeback_refused_if_result_tampered(self):
        r = self.analyze()
        f = Path(r["_evidence_dir"], "result.json")
        f.write_text(f.read_text().replace('"P10"', '"P09"', 1))
        with self.assertRaises(GovernanceError) as cm:
            self.engine().writeback("portefeuille", r["run_id"], 1, RunOptions("boss", None, "alice"))
        self.assertIn("modifié", str(cm.exception))

    def test_writeback_refused_if_audit_tampered(self):
        r = self.analyze()
        log = Path(self.tmp, "audit.jsonl")
        lines = log.read_text().splitlines()
        lines[0] = lines[0].replace('"operator": "', '"operator": "x', 1)
        log.write_text("\n".join(lines) + "\n")
        with self.assertRaises(GovernanceError) as cm:
            self.engine().writeback("portefeuille", r["run_id"], 1, RunOptions("boss", None, "alice"))
        self.assertIn("altéré", str(cm.exception))

    def test_writeback_refused_for_csv_analysis(self):
        r = self.analyze(input_csv=str(ROOT / "examples" / "projets_demo.csv"))
        with self.assertRaises(GovernanceError):
            self.engine().writeback("portefeuille", r["run_id"], 1, RunOptions("boss", None, "alice"))

    def test_approval_ticket_and_four_eyes(self):
        r = self.analyze()
        with self.assertRaises(GovernanceError):
            self.engine().writeback("portefeuille", r["run_id"], 1, RunOptions(None, None, "alice"))
        prod = self.engine("prod")
        r = self.analyze(prod)
        with self.assertRaises(GovernanceError):
            prod.writeback("portefeuille", r["run_id"], 1, RunOptions("boss", None, "alice"))
        with self.assertRaises(GovernanceError):
            prod.writeback("portefeuille", r["run_id"], 1, RunOptions("alice", "CHG-1", "alice"))
        self.assertTrue(prod.writeback("portefeuille", r["run_id"], 1, RunOptions("boss", "CHG-1", "alice"))["reconciled"])

    def test_corrupted_write_is_rolled_back(self):
        r = self.analyze()
        self.tm1.sandboxes_ok = False
        before = dict(self.tm1.data["Décisions"])
        self.tm1.corrupt_next_write = True
        with self.assertRaises(ReconciliationError):
            self.engine().writeback("portefeuille", r["run_id"], 1, RunOptions("boss", None, "alice"))
        self.assertEqual(self.tm1.data["Décisions"], before)

    def test_protected_target_rejected_by_config(self):
        bad = conf_dict(self.tmp)
        bad["decisions"][0]["writeback"]["fixed"] = {"Version": "Budget 2027"}
        with self.assertRaises(Exception):
            AppConf.model_validate(bad)

    def test_audit_chain_is_intact_and_signed(self):
        r = self.analyze()
        self.engine().writeback("portefeuille", r["run_id"], 1, RunOptions("boss", None, "alice"))
        log = AuditLog(Path(self.tmp, "audit.jsonl"), HMAC)
        ok, n, msg = log.verify()
        self.assertTrue(ok, msg)
        events = [json.loads(line)["event"] for line in log.path.read_text().splitlines()]
        for ev in ("analysis_started", "analysis_completed", "writeback_authorized", "writeback_completed"):
            self.assertIn(ev, events)
        self.assertNotIn(HMAC, log.path.read_text())
        self.assertFalse(AuditLog(log.path, "mauvaise-cle").verify()[0])

    def test_concurrent_analysis_blocked(self):
        with FlowLock(f"{self.tmp}/locks", "portefeuille", "autre"):
            with self.assertRaises(LockError):
                self.analyze()

    def test_prod_requires_signed_audit(self):
        del os.environ["TEST_HMAC"]
        with self.assertRaises(Exception):
            self.engine("prod")


class TestConfigAndCli(unittest.TestCase):
    def test_example_config_valid(self):
        conf, h = load_config(ROOT / "config" / "decision.example.yaml")
        self.assertEqual(conf.decisions[0].name, "portefeuille_2027")
        self.assertEqual(len(h), 64)

    def test_secrets_and_plain_http_rejected(self):
        tmp = tempfile.mkdtemp()
        base = conf_dict(tmp)
        for tm1 in ({"connection": {"base_url": "https://x", "password": "p"}},
                    {"connection": {"base_url": "http://x"}}, {"verify_tls": False}):
            p = Path(tmp, "c.yaml")
            import yaml
            p.write_text(yaml.safe_dump({**base, "tm1": tm1}, allow_unicode=True))
            with self.assertRaises(ConfigError):
                load_config(p)

    def test_cli_analyze_on_demo_file(self):
        tmp = tempfile.mkdtemp()
        os.environ["TEST_HMAC"] = HMAC
        import yaml
        c = conf_dict(tmp)
        p = Path(tmp, "c.yaml")
        p.write_text(yaml.safe_dump(c, allow_unicode=True))
        code = cli.main(["-c", str(p), "analyze", "portefeuille", "--input", str(ROOT / "examples" / "projets_demo.csv")])
        self.assertEqual(code, 0)
        self.assertEqual(cli.main(["-c", str(p), "verify-audit"]), 0)
        self.assertEqual(cli.main(["-c", str(p), "analyze", "inconnue"]), 2)


if __name__ == "__main__":
    unittest.main()
