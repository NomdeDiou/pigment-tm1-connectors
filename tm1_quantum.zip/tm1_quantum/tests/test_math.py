"""Exactitude mathématique : solveurs, formulation quantique, circuit, probabilités.

Chaque propriété est testée sur des problèmes aléatoires (graines fixées) et comparée à une
référence indépendante (Python pur, force brute).
"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tm1q import circuit, exact, qaoa, robustness  # noqa: E402
from tm1q import qubo as Q  # noqa: E402
from tm1q.config import DecisionConf  # noqa: E402
from tm1q.errors import ValidationError  # noqa: E402
from tm1q.problem import build_problem, check_pure  # noqa: E402
from tm1q.quantum import calibrate  # noqa: E402

BASE = {"name": "t", "owner": "o",
        "source": {"cube": "C", "options_dimension": "P", "measures_dimension": "M", "value_measure": "V"}}


def random_problem(seed: int, n: int, integer_costs=True, rules=True):
    rng = np.random.default_rng(seed)
    ids = [f"X{i:02d}" for i in range(n)]
    cost = rng.integers(1, 10, n) * (1 if integer_costs else 1.37)
    table = pd.DataFrame({"id": ids, "value": rng.integers(1, 20, n) * 1000.0,
                          "stdev": rng.integers(0, 6, n) * 1000.0, "R1": cost, "R2": rng.integers(0, 5, n)})
    conf = dict(BASE, resources={"R1": {"capacity": float(cost.sum() // 2)}, "R2": {"capacity": 8.0}})
    if rules:
        conf["rules"] = {"mandatory": [ids[0]], "exclusive_groups": [[ids[1], ids[2]]],
                         "requires": {ids[3]: [ids[4]]}, "max_selected": max(2, n - 2)}
        conf["synergies"] = [{"a": ids[n - 1], "b": ids[n - 2], "value": 4000.0}, {"a": ids[1], "b": ids[n - 3], "value": -3000.0}]
    dec = DecisionConf.model_validate(conf)
    return build_problem(dec, table, {"R1": float(cost.sum() // 2), "R2": 8.0})


class TestExact(unittest.TestCase):
    def test_enumeration_matches_brute_force(self):
        for seed in range(6):
            p = random_problem(seed, 9)
            en = exact.enumerate_all(p)
            brute = sorted(((check_pure(p, p.ids_of(c))[2], c) for c in range(1 << p.n)
                            if check_pure(p, p.ids_of(c))[0]), key=lambda t: (-round(t[0], 9), t[1]))
            self.assertEqual(en.feasible_count, len(brute))
            self.assertEqual([int(c) for c in en.codes], [c for _, c in brute])
            np.testing.assert_allclose(en.values, [v for v, _ in brute])

    def test_milp_top_k_matches_enumeration(self):
        for seed in range(6):
            p = random_problem(seed, 12)
            en = exact.enumerate_all(p)
            k = min(8, en.feasible_count)
            m = exact.top_k_milp(p, k)
            self.assertTrue(m.proven_optimal)
            np.testing.assert_allclose(m.values, en.values[:k], rtol=1e-9)

    def test_milp_when_fewer_solutions_than_k(self):
        p = random_problem(1, 6)
        en = exact.enumerate_all(p)
        m = exact.top_k_milp(p, en.feasible_count + 5)
        self.assertEqual(m.feasible_count, en.feasible_count)


class TestQuantumFormulation(unittest.TestCase):
    def test_slack_qubo_minimum_is_optimum_and_ising_matches(self):
        for seed in range(5):
            p = random_problem(seed, 7)
            en = exact.enumerate_all(p)
            q = Q.build_qubo(p, method="slack")
            self.assertTrue(q.exact_discretization)
            E = q.energy_vector()
            g = int(np.argmin(E))
            code = int(q.decode(np.array([g]))[0])
            ok, viol, val, _ = check_pure(p, p.ids_of(code))
            self.assertTrue(ok, viol)
            self.assertAlmostEqual(val, en.values[0], places=6)
            self.assertAlmostEqual(-E[g] * q.scale, en.values[0], delta=1e-6 * en.values[0])
            h, J, off = q.to_ising()
            np.testing.assert_allclose(Q.ising_energy_vector(h, J, off), E, atol=1e-9)

    def test_every_feasible_decision_has_its_exact_energy(self):
        """Pour toute décision admissible, min sur les écarts de l'énergie = -valeur/échelle."""
        p = random_problem(3, 6)
        en = exact.enumerate_all(p)
        q = Q.build_qubo(p, method="slack")
        E = q.energy_vector()
        codes = q.decode(np.arange(E.size))
        for c, v in zip(en.codes, en.values):
            self.assertAlmostEqual(E[codes == c].min(), -v / q.scale, places=9)

    def test_calibrated_unbalanced_ground_state_is_optimum(self):
        for seed in range(5):
            p = random_problem(seed, 8)
            en = exact.enumerate_all(p)
            q, table, lam = calibrate(p, float(en.values[0]), None)
            self.assertTrue(table)
            if q is None:
                continue
            self.assertEqual(q.nq, p.n - 1, "aucun qubit d'écart, option obligatoire substituée")
            E = q.energy_vector()
            ok, viol, val, _ = check_pure(p, p.ids_of(int(q.decode(np.array([int(np.argmin(E))]))[0])))
            self.assertTrue(ok)
            self.assertAlmostEqual(val, en.values[0], places=6)

    def test_fallbacks_when_exact_calibration_fails(self):
        """Seed 3 : aucun réglage λ exact. Avec assez de qubits -> formulation exacte à écarts ;
        sinon -> formulation approchée, signalée, et mesures toujours vérifiées."""
        from tm1q.config import QuantumConf
        from tm1q.quantum import run
        p = random_problem(3, 10)
        en = exact.enumerate_all(p)
        self.assertIsNone(calibrate(p, float(en.values[0]), None)[0])
        big = run(p, en, QuantumConf(max_qubits=24, shots=512, restarts=1, layers=1), True)
        self.assertEqual(big.formulation, "slack")
        self.assertTrue(big.checks["qubo_minimum_is_optimum"])
        small = run(p, en, QuantumConf(max_qubits=12, shots=512, restarts=1, layers=1), True)
        self.assertEqual(small.formulation, "unbalanced-approx")
        self.assertEqual(small.status, "ok")
        self.assertTrue(any("approchée" in n for n in small.notes))
        for d in small.decisions:
            ok, _, val, _ = check_pure(p, p.ids_of(d["code"]))
            self.assertEqual(ok, d["feasible"])

    def test_non_integer_costs_flagged(self):
        p = random_problem(2, 6, integer_costs=False)
        self.assertFalse(Q.build_qubo(p, method="slack").exact_discretization)


class TestCircuit(unittest.TestCase):
    def test_gate_level_circuit_equals_fast_simulator(self):
        rng = np.random.default_rng(0)
        for n in (3, 5, 7):
            h = rng.normal(size=n)
            J = {(i, j): float(rng.normal()) for i in range(n) for j in range(i + 1, n) if rng.random() < 0.6}
            E = Q.ising_energy_vector(h, J, 0.4)
            g, b = list(rng.uniform(0, 2, 2)), list(rng.uniform(0, 1, 2))
            scale = qaoa.energy_scale_of(E)
            fast = qaoa.evolve_probs(E, g, b, float(E.min()), scale)
            gates = circuit.qaoa_gates(h, J, g, b, scale)
            ref = np.abs(circuit.simulate_gates(n, gates)) ** 2
            np.testing.assert_allclose(ref, fast, atol=1e-12)

    def test_qasm_export(self):
        gates = circuit.qaoa_gates(np.array([1.0, 0.0]), {(0, 1): 0.5}, [0.3], [0.2], 1.0)
        qasm = circuit.to_qasm2(2, gates)
        self.assertIn('include "qelib1.inc";', qasm)
        self.assertEqual(qasm.count("h q["), 2)
        self.assertEqual(qasm.count("rzz("), 1)
        self.assertEqual(qasm.count("rz("), 1, "pas de rotation pour h = 0")
        self.assertTrue(qasm.strip().endswith("measure q -> c;"))

    def test_bit_order_convention(self):
        """Un champ h fort pousse le qubit vers z = -1, c.-à-d. x = 1 (bit à 1) : même convention partout."""
        E = Q.ising_energy_vector(np.array([5.0, 0.0]), {}, 0.0)
        self.assertEqual(int(np.argmin(E)), 0b01)

    def test_sampling_is_reproducible_and_complete(self):
        probs = np.array([0.5, 0.25, 0.125, 0.125])
        a, b = qaoa.sample(probs, 1000, 3), qaoa.sample(probs, 1000, 3)
        self.assertEqual(a, b)
        self.assertEqual(sum(a.values()), 1000)


class TestRobustness(unittest.TestCase):
    def test_probabilities_sum_to_one_and_reproducible(self):
        p = random_problem(4, 9)
        en = exact.enumerate_all(p)
        r1 = robustness.analyze(p, en.codes, en.values, 5, 2000, 11, 10_000)
        r2 = robustness.analyze(p, en.codes, en.values, 5, 2000, 11, 10_000)
        self.assertAlmostEqual(r1.p_best.sum(), 1.0, places=12)
        self.assertEqual(r1.fingerprint, r2.fingerprint)
        self.assertTrue(np.all(r1.p5 <= r1.p50) and np.all(r1.p50 <= r1.p95))
        self.assertAlmostEqual(r1.option_in_best[p.index[p.ids[0]]], 1.0, msg="option obligatoire toujours présente")

    def test_deterministic_when_no_uncertainty(self):
        p = random_problem(5, 6)
        p2 = build_problem(DecisionConf.model_validate(dict(BASE, resources={"R1": {"capacity": 30}, "R2": {"capacity": 8}})),
                           pd.DataFrame({"id": p.ids, "value": p.v, "stdev": 0.0, "R1": p.C[0], "R2": p.C[1]}),
                           {"R1": 30, "R2": 8})
        en = exact.enumerate_all(p2)
        r = robustness.analyze(p2, en.codes, en.values, 5, 1000, 1, 1000)
        self.assertTrue(r.deterministic)
        self.assertEqual(r.p_best[0], 1.0)


class TestValidation(unittest.TestCase):
    def test_bad_inputs_are_rejected_with_reasons(self):
        dec = DecisionConf.model_validate(dict(BASE, resources={"R1": {"capacity": 10}},
                                               rules={"mandatory": ["A", "Z"], "forbidden": ["A"]}))
        t = pd.DataFrame({"id": ["A", "A", "B"], "value": ["1", "x", "3"], "R1": [1, -2, 1]})
        with self.assertRaises(ValidationError) as cm:
            build_problem(dec, t, {"R1": 10})
        txt = " | ".join(cm.exception.issues)
        for expected in ("double", "non numérique", "négatif", "absentes", "obligatoires et interdites"):
            self.assertIn(expected, txt)


if __name__ == "__main__":
    unittest.main()
