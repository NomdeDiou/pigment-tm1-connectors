"""TM1 simulé en mémoire (même contrat que tm1q.tm1.TM1Adapter)."""
from __future__ import annotations

import copy
from contextlib import contextmanager

import pandas as pd


class FakeTM1:
    def __init__(self):
        self.dims: dict[str, list[str]] = {}
        self.leaves: dict[str, list[str]] = {}
        self.data: dict[str, dict[tuple, float]] = {}
        self.sb: dict[str, dict] = {}
        self.sandboxes_ok = True
        self.corrupt_next_write = False
        self.published = []

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def cube(self, name, dims):
        self.dims[name] = list(dims)
        self.data[name] = {}

    def _st(self, cube, sandbox):
        return self.sb[sandbox][cube] if sandbox else self.data[cube]

    def cube_dimensions(self, cube):
        return list(self.dims[cube])

    def leaf_elements(self, d):
        return list(self.leaves[d])

    def sandboxes_enabled(self):
        return self.sandboxes_ok

    def _in(self, cube, k, members):
        low = {d: {e.lower() for e in v} for d, v in members.items()}
        return all(k[i].lower() in low[d] for i, d in enumerate(self.dims[cube]) if d in low)

    def read(self, cube, members, sandbox=None, mdx=None):
        rows = [(*k, v) for k, v in self._st(cube, sandbox).items() if v != 0 and self._in(cube, k, members)]
        return pd.DataFrame(rows, columns=self.dims[cube] + ["Value"])

    def clear(self, cube, members, sandbox=None):
        st = self._st(cube, sandbox)
        for k in [k for k in st if self._in(cube, k, members)]:
            del st[k]

    def write(self, cube, df, dimensions, sandbox=None):
        st = self._st(cube, sandbox)
        rows = list(df[dimensions + ["Value"]].itertuples(index=False))
        if self.corrupt_next_write:
            self.corrupt_next_write = False
            rows = rows[:-1]
        order = [dimensions.index(d) for d in self.dims[cube]]
        for r in rows:
            key = tuple(str(r[i]) for i in order)
            if float(r[-1]) == 0:
                st.pop(key, None)
            else:
                st[key] = float(r[-1])

    @contextmanager
    def sandbox(self, name):
        self.sb[name] = copy.deepcopy(self.data)
        try:
            yield name
        finally:
            self.sb.pop(name, None)

    def publish(self, name):
        self.data = copy.deepcopy(self.sb[name])
        self.published.append(name)
