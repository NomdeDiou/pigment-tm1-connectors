"""Contre-vérification par une implémentation indépendante.

Ce test recalcule le jeu de démonstration avec du Python standard uniquement (itertools,
random, csv) : aucune fonction du connecteur n'est utilisée pour le calcul. Il compare
ensuite au résultat du connecteur :
  * nombre de solutions admissibles et classement complet (exact) ;
  * probabilités « meilleur choix » (Monte-Carlo avec un autre générateur aléatoire) :
    l'écart doit rester dans la marge statistique (4 écarts-types).
"""
from __future__ import annotations

import csv
import itertools
import math
import random
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# ------------------------------------------------------------------ données et règles, réécrites à la main
with open(ROOT / "examples" / "projets_demo.csv", encoding="utf-8") as fh:
    ROWS = list(csv.DictReader(fh))
IDS = [r["id"] for r in ROWS]
VAL = {r["id"]: float(r["value"]) for r in ROWS}
SD = {r["id"]: float(r["stdev"]) for r in ROWS}
CAPEX = {r["id"]: float(r["Capex"]) for r in ROWS}
ETP = {r["id"]: float(r["ETP"]) for r in ROWS}
SYN = {frozenset(("P02", "P06")): 400000, frozenset(("P07", "P08")): 300000,
       frozenset(("P04", "P05")): 200000, frozenset(("P03", "P10")): -400000}


def admissible(s: frozenset) -> bool:
    return (sum(CAPEX[i] for i in s) <= 7_000_000 and sum(ETP[i] for i in s) <= 24 and "P01" in s
            and not {"P03", "P04"} <= s and ("P06" not in s or "P02" in s))


def value(s: frozenset, vals=VAL) -> float:
    return sum(vals[i] for i in s) + sum(v for pair, v in SYN.items() if pair <= s)


ALL = [frozenset(c) for k in range(len(IDS) + 1) for c in itertools.combinations(IDS, k)]
FEASIBLE = sorted((s for s in ALL if admissible(s)), key=lambda s: -value(s))


class TestIndependent(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import os
        import tempfile

        from tm1q.config import AppConf
        from tm1q.engine import Engine
        from tests.test_engine import conf_dict
        os.environ.setdefault("TEST_HMAC", "cle-hmac-de-test-0123456789")
        tmp = tempfile.mkdtemp()
        c = conf_dict(tmp)
        c["decisions"][0]["analysis"] = {"scenarios": 20000, "top_k": 10}
        c["decisions"][0]["quantum"] = {"enabled": False}
        cls.r = Engine(AppConf.model_validate(c), "h", tm1_factory=None).analyze(
            "portefeuille", input_csv=str(ROOT / "examples" / "projets_demo.csv"))

    def test_same_number_of_admissible_decisions(self):
        self.assertEqual(len(ALL), 1024)
        self.assertEqual(self.r["exact"]["feasible_count"], len(FEASIBLE))

    def test_same_ranking_values(self):
        for i, sol in enumerate(self.r["ranking"]):
            self.assertAlmostEqual(sol["value"], value(FEASIBLE[i]), places=6)
            self.assertTrue(admissible(frozenset(sol["options"])))
            self.assertAlmostEqual(sol["value"], value(frozenset(sol["options"])), places=6)

    def test_probabilities_agree_within_statistical_margin(self):
        rng = random.Random(987654321)                     # autre générateur, autre graine
        n = 20000
        wins: dict[frozenset, int] = {}
        for _ in range(n):
            vals = {i: rng.gauss(VAL[i], SD[i]) for i in IDS}
            best = max(FEASIBLE, key=lambda s: value(s, vals))
            wins[best] = wins.get(best, 0) + 1
        for sol in self.r["ranking"]:
            p_conn = sol["p_best"]
            p_ind = wins.get(frozenset(sol["options"]), 0) / n
            sigma = math.sqrt(max(p_ind * (1 - p_ind), 1e-6) / n) * math.sqrt(2)
            self.assertLess(abs(p_conn - p_ind), 4 * sigma + 1e-9,
                            f"rang {sol['rank']} : connecteur {p_conn:.4f} vs indépendant {p_ind:.4f}")


if __name__ == "__main__":
    unittest.main()
