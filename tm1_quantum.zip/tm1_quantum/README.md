# Connecteur d'aide à la décision TM1 ⇄ calcul quantique

Ce connecteur lit un problème de décision dans IBM Planning Analytics (TM1), par exemple : *quels projets financer avec une enveloppe de Capex et d'ETP limitée ?*

Il fait ensuite cinq choses :

1. **Il calcule toutes les solutions possibles**, les classe, et prouve laquelle est la meilleure.
2. Pour chacune, il **estime la probabilité qu'elle soit le meilleur choix** compte tenu des incertitudes.
3. Il **fait résoudre le même problème par un algorithme quantique** (QAOA), sur un simulateur local ou sur une machine IBM Quantum.
4. Il **vérifie tout de façon indépendante**, puis explique le résultat en français dans un rapport lisible par un comité.
5. **Après approbation humaine**, il réécrit la décision retenue dans TM1, avec relecture et réconciliation.

Un exemple de rapport est fourni : [`examples/rapport_demo.html`](examples/rapport_demo.html).

## Ce qu'il faut savoir avant tout

- **Le calcul exact fait foi.** Jusqu'à 20 options, chaque combinaison est examinée (2²⁰ ≈ 1 million). Au-delà, un solveur exact (MILP) prouve les K meilleures solutions, dans l'ordre.
- **Le calcul quantique ne remplace pas le calcul exact aujourd'hui.** Il est mesuré contre lui à chaque analyse. Le rapport dit honnêtement ce qu'il a trouvé : fréquence de l'optimum, gain par rapport au hasard, meilleure décision mesurée. Son intérêt est de préparer l'organisation et de suivre les progrès du matériel.
- **Deux probabilités différentes, à ne pas confondre** :
  - *Probabilité d'être le meilleur choix* : c'est la probabilité métier. Elle vient d'une simulation de Monte-Carlo sur les incertitudes des valeurs.
  - *Fréquence quantique* : elle dit à quel point l'algorithme quantique « trouve » une décision. Ce n'est pas une chance de réussite.
- **L'outil éclaire une décision, il ne la prend pas.** La réécriture dans TM1 exige une approbation nominative.

## Démarrage en 2 minutes (sans TM1)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m tm1q -c config/decision.example.yaml analyze portefeuille_2027 --input examples/projets_demo.csv
python -m unittest discover -s tests -t .          # 39 tests
```

Le résumé s'affiche dans le terminal. Le rapport complet est dans `runs/portefeuille_2027/<id>/rapport.html`.

## Comment ça marche

```
TM1 (cube options × mesures)
   │  lecture : valeur, écart-type, coûts par ressource ; capacités (config ou cellule TM1)
   ▼
Problème validé ──► empreinte SHA-256
   │
   ├─► Calcul exact ── toutes les combinaisons (≤ 20 options) ou K meilleures prouvées (MILP)
   │                   + contre-vérification par une seconde méthode
   ├─► Probabilités ── Monte-Carlo : P(meilleur choix) ± IC 95 %, fourchette P5–P95,
   │                   probabilité que chaque option fasse partie de la meilleure décision
   ├─► Sensibilité ─── capacités ± 10 % : quelle ressource limite, combien vaudrait une rallonge
   ├─► Quantique ───── QUBO → Ising → circuit QAOA (OpenQASM 2.0) → mesures → vérification
   └─► Contrôles ───── 10 contrôles automatiques ; un échec bloquant interdit toute publication
   ▼
Rapport HTML + résultat scellé (SHA-256 inscrit au journal d'audit)
   │  revue humaine
   ▼
writeback : approbation + données TM1 inchangées + sceau intact → écriture atomique → relecture
```

### La partie quantique, en clair

- Le problème est traduit en **énergie à minimiser** (QUBO, puis Hamiltonien d'Ising). Les meilleures décisions ont les énergies les plus basses.
- **Formulation compacte par défaut** (« pénalisation déséquilibrée », Montañez‑Barrera et al.). Un qubit par option libre, sans qubit supplémentaire pour les contraintes, et les coûts exacts. Ses coefficients sont **calibrés** pour que le minimum soit exactement la meilleure décision, et c'est vérifié sur tous les états.
- Si aucun réglage exact n'existe (cela arrive avec plusieurs ressources saturées), le connecteur choisit dans cet ordre :
  1. la **formulation garantie à variables d'écart**, exacte par construction mais plus gourmande en qubits ;
  2. sinon, une **formulation approchée**, signalée dans le rapport.
- **QAOA** : les angles sont optimisés sur la CVaR, et toutes les graines sont fixées, donc les résultats sont reproductibles.
- **Toutes les mesures sont décodées et vérifiées classiquement.** Une proposition quantique n'est jamais acceptée sans contrôle.
- Le **circuit exporté** est la seule chose qui partirait vers une machine externe : des angles et des numéros de qubits, sans libellé ni montant. Sa conformité est prouvée en le simulant porte par porte et en le comparant au calcul.

## Ce qui est vérifié à chaque analyse

| Contrôle | Bloquant |
|---|---|
| Toutes les combinaisons examinées (ou méthode MILP signalée) | oui |
| Optimalité prouvée | signalé |
| Recalcul en Python pur, indépendant, des solutions publiées et de chaque décision mesurée | oui |
| Énumération et MILP donnent le même classement | oui |
| Les probabilités totalisent 100 % | oui |
| Les probabilités sont reproductibles (même graine, même résultat) | oui |
| Ising = QUBO sur tous les états | oui |
| Le minimum de la formulation quantique est la meilleure décision | signalé |
| Le circuit exporté réalise exactement le calcul simulé (porte par porte) | oui |
| Toutes les mesures quantiques sont comptabilisées | oui |

Les tests ajoutent une **contre-vérification indépendante** (`tests/test_independent.py`). C'est une seconde implémentation en Python standard, sans aucun code du connecteur, avec un autre générateur aléatoire. Elle retrouve le même nombre de solutions, le même classement et les mêmes probabilités, à la marge statistique près.

## Sécurité

- Aucun secret dans la configuration : les champs sensibles sont rejetés à la validation. Les secrets viennent de variables d'environnement ou de fichiers montés (`VAR_FILE`), et sont masqués dans les logs.
- HTTPS et vérification TLS obligatoires vers TM1.
- **Sortie de données vers IBM Quantum** : désactivée par défaut. Il faut à la fois `allow_external: true` dans la configuration et `--approved-by` à l'exécution (plus `--ticket` en production). Seul le circuit est envoyé.
- Le rapport échappe toutes les données affichées : un libellé TM1 malveillant ne peut pas y injecter de code.
- Les preuves sont écrites en droits restreints (`rw-r-----`).

## Gouvernance

- Décisions déclarées en YAML versionné, avec un propriétaire.
- `analyze` est en **lecture seule** sur TM1.
- `writeback` réécrit une analyse vérifiée. **Il refuse** dans les cas suivants :
  - le journal d'audit a été altéré (chaîne HMAC) ;
  - le résultat a été modifié depuis l'analyse (sceau SHA‑256) ;
  - les données TM1 ont changé depuis l'analyse (empreinte du problème) ;
  - l'analyse portait sur un fichier et non sur TM1 ;
  - l'approbation manque (et, en production, le ticket ou les quatre yeux) ;
  - la cible écrirait sur un membre protégé (par exemple `Budget 2027` ou `Actual`).
- L'écriture est atomique : sandbox TM1, sinon sauvegarde puis restauration automatique vérifiée. Elle est relue et réconciliée. L'effacement de l'ancienne proposition ne demande **aucun droit administrateur**.
- Un verrou empêche deux analyses simultanées de la même décision.

```bash
python -m tm1q -c config/decision.yaml analyze portefeuille_2027
# revue du rapport, puis par une personne habilitée :
python -m tm1q -c config/decision.yaml writeback portefeuille_2027 --run-id <id> --ranks 3 \
       --operator a.dupont --approved-by j.martin --ticket CHG-1234
python -m tm1q -c config/decision.yaml verify-audit
```

## Préparer TM1

**Cube source** (exemple `Projets`) :
- dimensions : `Projet` × `Mesure Projet` × les dimensions fixées (`Version`, `Scénario`…) ;
- mesures : valeur attendue (`VAN`), écart-type facultatif, et une mesure de coût par ressource.

**Cube cible** (exemple `Décisions Portefeuille`) :
- dimensions : `Rang` × `Projet` × `Mesure Décision` × les dimensions fixées (`Version: Proposition`) ;
- l'option `Retenu` vaut 1 pour les projets retenus ;
- les indicateurs (valeur attendue, probabilité, P5, P95…) sont écrits sur un élément feuille `Synthèse` de la dimension `Projet`.

Les capacités sont soit fixées dans la configuration, soit lues dans une cellule TM1 (`capacity_from`).

## Exécuter sur IBM Quantum

```bash
pip install qiskit qiskit-ibm-runtime
export IBM_QUANTUM_TOKEN=...
# config : quantum.backend: ibm, quantum.allow_external: true
python -m tm1q -c config/decision.yaml analyze portefeuille_2027 --approved-by j.martin --ticket CHG-1235
```

Les angles sont optimisés localement, puis le circuit est exécuté sur la machine choisie (ou la moins chargée). **Ce module n'a pas pu être testé contre IBM Quantum** : Qiskit était indisponible dans l'environnement de développement. Le circuit qu'il soumet est, lui, vérifié porte par porte. À valider sur votre compte avant usage réel. Les machines actuelles sont bruitées : attendez-vous à des fréquences moins nettes qu'en simulation. La vérification classique de chaque mesure reste valable.

## Performances observées (simulateur local, 2 cœurs)

| Options | Combinaisons examinées | Solutions admissibles | Qubits | Durée totale |
|---|---|---|---|---|
| 10 | 1 024 | 143 | 9 | 4 s |
| 16 | 65 536 | 5 079 | 15 | 14 s |
| 20 | 1 048 576 | 61 226 | 19 | 2 min 30 |

Au-delà de 20 options : classement exact par MILP (K meilleures prouvées). Le calcul quantique passe alors par IBM Quantum, ou il est ignoré, avec une explication.

## Hypothèses et limites

- Valeur d'une décision = somme des valeurs des options + synergies déclarées entre paires.
- Incertitudes : lois normales indépendantes ; pas de corrélation entre options. Coûts et capacités sont certains.
- Au-delà de 20 000 décisions admissibles, les probabilités sont calculées parmi les 20 000 meilleures (signalé).
- Le classement principal est fait sur la valeur attendue. Le rapport signale explicitement quand une alternative est plus souvent gagnante, ou plus sûre dans le pire cas.

## Codes de sortie

`0` succès · `2` configuration · `3` secret · `4` données · `5` gouvernance · `6` chargement · `7` écart, état restauré · `8` verrou · `9` restauration échouée (**critique**) · `10` audit altéré · `11` vérification en échec · `12` aucune solution admissible.
